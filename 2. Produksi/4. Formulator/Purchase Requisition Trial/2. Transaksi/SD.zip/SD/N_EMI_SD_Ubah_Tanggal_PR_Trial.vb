﻿Public Class N_EMI_SD_Ubah_Tanggal_PR_Trial

    Dim arrIndex, arrNoPenawaran, arrSatuanPenawaran, arrHargaPenawaran As New ArrayList
    Dim no_formula, no_inquiry, kode_customer, kode_barang As String

    Public kodeSupplier As String
    Public kodeBarang As String
    Public rowDgv As Integer
    Public cellDgv As Integer
    Public EstTiba As Integer

    Private Sub SD_Formulator_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        kosong()
    End Sub

    Private Sub kosong()

    End Sub
    Private Sub Btn_Simpan_Click(sender As Object, e As EventArgs) Handles Btn_Simpan.Click
        N_EMI_Transaksi_Purchase_Requisition_Trial.Dgv_DataBarang.Rows(rowDgv).Cells(cellDgv).Value = Format(DTP_Delivery.Value, "dd MMM yyyy")

        Me.Close()
    End Sub

    Private Sub DTP_Delivery_ValueChanged(sender As Object, e As EventArgs) Handles DTP_Delivery.ValueChanged
        Dim Diff As Integer = DateDiff(DateInterval.Day, tgl_skg, DTP_Delivery.Value)


        If Diff < EstTiba Then
            Dim Msg As String = MessageBox.Show("Tanggal Dibutuhkan Kurang dari Estimasi Tiba,  Tetap Lanjutkan ? ", Base_Language.Lang_Global_Perhatian, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Msg = vbNo Then
                DTP_Delivery.Value = DateAdd(DateInterval.Day, EstTiba + 1, tgl_skg)
            End If
        End If

    End Sub
End Class