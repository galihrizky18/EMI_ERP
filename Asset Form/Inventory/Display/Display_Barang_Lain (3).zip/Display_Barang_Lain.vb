﻿Public Class Display_Barang_Lain
    Dim arrcarib, arrcari2b, arrkatb, arrtanggalb, arrpilihblnb, arrbln1b, arrbln2b, arrdb, arrStatus As New ArrayList
    Dim arrcaribsf, arrcari2bsf, arrP1, arrP2, arrP3, arrP4 As New ArrayList
    Dim arrSO, arrGroup_Jenis, arrArea, arrRow, arrLevel, arrPosition, arrBay As New ArrayList
    Dim arrBL As New ArrayList

    Dim LvGudang As String
    Dim LvJenis As String
    Dim LvKodeBrg As String
    Dim LvNama As String
    Dim LvStokTersedia As String
    Dim LvSatuan As String

    Dim CellGudang As Integer = 0
    Dim CellJenis As Integer = 1
    Dim CellKodeBrg As Integer = 2
    Dim CellNama As Integer = 3
    Dim CellStokTersedia As Integer = 4
    Dim CellSatuan As Integer = 5

    Public Sub Get_Isi_Listview(ByVal No_Index As Integer)
        LvGudang = Dgv_BarangPerlokasi.Rows(No_Index).Cells(CellGudang).Value
        LvJenis = Dgv_BarangPerlokasi.Rows(No_Index).Cells(CellJenis).Value

        LvKodeBrg = Dgv_BarangPerlokasi.Rows(No_Index).Cells(CellKodeBrg).Value
        LvNama = Dgv_BarangPerlokasi.Rows(No_Index).Cells(CellNama).Value
        LvStokTersedia = Dgv_BarangPerlokasi.Rows(No_Index).Cells(CellStokTersedia).Value
        LvSatuan = Dgv_BarangPerlokasi.Rows(No_Index).Cells(CellSatuan).Value
    End Sub


    Private Sub carib(ByVal semua As String, ByVal stockmin As String, ByVal cetak As String)
        If semua = "T" Then
            If CheckBox1.Checked = True Then
                If ComboBox1b.SelectedIndex = -1 Then
                    MessageBox.Show("Parameter 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    ComboBox1b.Focus() : Exit Sub
                ElseIf TextBox7b.Text.Trim.Length = 0 Then
                    MessageBox.Show("Value 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    TextBox7b.Focus() : Exit Sub
                End If
            End If

            If CheckBox2.Checked = True Then
                If ComboBox7b.SelectedIndex = -1 Then
                    MessageBox.Show("Parameter 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    ComboBox7b.Focus() : Exit Sub
                ElseIf TextBox6b.Text.Trim.Length = 0 Then
                    MessageBox.Show("Value 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    TextBox6b.Focus() : Exit Sub
                End If
            End If
        End If

        Try

            OpenConn()

            arrSO.Clear() : arrBL.Clear()
            SQL = "select Kode_Stock_Owner, flag_hide_stock, "
            SQL = SQL & "ISNULL((select top(1) 'Y' from role_button a where a.kode_perusahaan = x.kode_perusahaan and "
            SQL = SQL & "a.userid = '" & UserID & "' and buttonname = 'LIHAT_STOCK' ), 'T') AS boleh_lihat_stock  "
            SQL = SQL & "from stock_owner x where x.kode_perusahaan = '" & KodePerusahaan & "' and  x.kode_kota = '" & ComboKota.SelectedItem & "' "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read

                    If Dr("flag_hide_stock") = "Y" Then
                        If Dr("boleh_lihat_stock") = "Y" Then
                            arrBL.Add(True)
                        Else
                            arrBL.Add(False)
                        End If
                    Else
                        arrBL.Add(True)
                    End If
                    arrSO.Add(Dr("kode_stock_owner"))
                Loop
            End Using


            Dim no As Integer = 0
            Dim SF As String = ""

            SQL = "Select x.kode_stock_owner, x.kode_barang, x.Nama, x.satuan, x.good_stock, "
            SQL = SQL & "x.harga_beli, x.harga_jual, "
            SQL = SQL & "x.stock_minimum, x.Lemari, x.kode_supplier, "
            SQL = SQL & "x.bad_stock, x.kode_kategori, "

            For i As Integer = 1 To arrSO.Count - 1
                SQL = SQL & "isnull(("
                SQL = SQL & "select a.good_stock from barang_lain a where a.kode_perusahaan = x.kode_perusahaan and "
                SQL = SQL & "a.kode_barang = x.kode_barang and a.kode_stock_owner = '" & arrSO.Item(i) & "' "
                SQL = SQL & "), 0) as Stock_" & Replace(arrSO.Item(i), " ", "") & ", "
            Next

            SQL = SQL & "x.aktif from barang_lain x where "
            SQL = SQL & "x.kode_perusahaan = '" & KodePerusahaan & "' and x.kode_stock_owner = '" & arrSO.Item(0) & "' "

            If semua = "T" Then
                If CheckBox1.Checked = True Then
                    SQL = SQL & " and " & arrcarib.Item(ComboBox1b.SelectedIndex) & " " & ComboBox1.Text & " '" & ComboBox3.Text & TextBox7b.Text & ComboBox4.Text & "' "
                    SF = SF & " and " & arrcaribsf.Item(ComboBox1b.SelectedIndex) & " " & ComboBox1.Text & " '" & arrP1.Item(ComboBox3.SelectedIndex) & TextBox7b.Text & arrP2.Item(ComboBox4.SelectedIndex) & "' "
                End If

                If CheckBox2.Checked = True Then
                    SQL = SQL & " and " & arrcari2b.Item(ComboBox7b.SelectedIndex) & " " & ComboBox2.Text & " '" & ComboBox5.Text & TextBox6b.Text & ComboBox6.Text & "' "
                    SF = SF & " and " & arrcari2bsf.Item(ComboBox7b.SelectedIndex) & " " & ComboBox2.Text & " '" & arrP3.Item(ComboBox5.SelectedIndex) & TextBox6b.Text & arrP4.Item(ComboBox6.SelectedIndex) & "' "
                End If
            End If

            SQL = SQL & "order by x.nama"
            If cetak = "T" Then
                Using Dr = OpenTrans(SQL)
                    Do While Dr.Read
                        no = no + 1
                    Loop
                End Using
            End If

            CloseConn()

        Catch ex As Exception
            CloseConn2()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub Kosongb(ByVal seluruh As String)
        ComboBox10b.Items.Clear()
        ComboBox10b.Items.Add("--Semua--") : ComboBox10b.Items.Add("Y") : ComboBox10b.Items.Add("T")
        ComboBox10b.SelectedIndex = 1

        ComboBox1b.Enabled = True : ComboBox7b.Enabled = False
        TextBox7b.Enabled = True : TextBox6b.Enabled = False

        ComboBox1b.SelectedIndex = -1 : ComboBox7b.SelectedIndex = -1
        TextBox7b.Text = "" : TextBox6b.Text = ""

        ComboBox3.Items.Clear() : arrP1.Clear()
        ComboBox3.Items.Add("") : ComboBox3.Items.Add("%") : arrP1.Add("") : arrP1.Add("*") : ComboBox3.SelectedIndex = 1
        ComboBox4.Items.Clear() : arrP2.Clear()
        ComboBox4.Items.Add("") : ComboBox4.Items.Add("%") : arrP2.Add("") : arrP2.Add("*") : ComboBox4.SelectedIndex = 1

        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("like") : ComboBox1.Items.Add("=") : ComboBox1.SelectedIndex = 0

        ComboBox5.Items.Clear() : arrP3.Clear()
        ComboBox5.Items.Add("") : ComboBox5.Items.Add("%") : arrP3.Add("") : arrP3.Add("*") : ComboBox5.SelectedIndex = 0
        ComboBox6.Items.Clear() : arrP4.Clear()
        ComboBox6.Items.Add("") : ComboBox6.Items.Add("%") : arrP4.Add("") : arrP4.Add("*") : ComboBox6.SelectedIndex = 1

        ComboBox2.Items.Clear()
        ComboBox2.Items.Add("like") : ComboBox2.Items.Add("=") : ComboBox2.SelectedIndex = 0





        ComboBox1.Enabled = False : ComboBox2.Enabled = False
        ComboBox3.Enabled = False : ComboBox4.Enabled = False
        ComboBox5.Enabled = False : ComboBox6.Enabled = False
        'ComboBox3.SelectedIndex = 1 : ComboBox4.SelectedIndex = 1

        CheckBox1.Checked = False : CheckBox2.Checked = False ' ListView1b.Columns(5).Width = 0

        ComboBox1b.Items.Clear() : arrcarib.Clear() : arrcaribsf.Clear()
        ' ComboBox1b.Items.Add("Lokasi") : arrcarib.Add("x.kode_stock_owner") : arrcaribsf.Add("{barang.kode_stock_owner}")
        ComboBox1b.Items.Add("Kode Barang") : arrcarib.Add("Kode_Barang") ': arrcaribsf.Add("{barang.Kode_Barang}")
        ComboBox1b.Items.Add("Nama") : arrcarib.Add("Nama") ': arrcaribsf.Add("{barang.Nama}")
        ComboBox1b.Items.Add("Satuan Kecil") : arrcarib.Add("Satuan_Kecil") ': arrcaribsf.Add("{barang.Satuan}")
        ComboBox1b.Items.Add("Satuan Besar") : arrcarib.Add("Satuan_Besar") ': arrcaribsf.Add("{barang.Satuan}")
        'ComboBox1b.Items.Add("Harga Beli") : arrcarib.Add("x.Harga_Beli") : arrcaribsf.Add("{barang.Harga_Beli}")
        'ComboBox1b.Items.Add("Harga Jual") : arrcarib.Add("x.Harga_Jual") : arrcaribsf.Add("{barang.Harga_Jual}")
        'ComboBox1b.Items.Add("Stock") : arrcarib.Add("x.Good_Stock") : arrcaribsf.Add("{barang.Good_Stock}")
        'ComboBox1b.Items.Add("Stock Minimum") : arrcarib.Add("x.Stock_Minimum") : arrcaribsf.Add("{barang.Stock_Minimum}")
        'ComboBox1b.Items.Add("Lemari") : arrcarib.Add("Lemari") 
        'ComboBox1b.Items.Add("Kategori") : arrcarib.Add("x.kode_kategori") : arrcaribsf.Add("{barang.kode_kategori}")

        ComboBox7b.Items.Clear() : arrcari2b.Clear() : arrcari2bsf.Clear()
        'ComboBox7b.Items.Add("Lokasi") : arrcari2b.Add("x.kode_stock_owner") : arrcari2bsf.Add("{barang.kode_stock_owner}")
        ComboBox7b.Items.Add("Kode Barang") : arrcari2b.Add("Kode_Barang") ': arrcaribsf.Add("{barang.Kode_Barang}")
        ComboBox7b.Items.Add("Nama") : arrcari2b.Add("Nama") ': arrcaribsf.Add("{barang.Nama}")
        ComboBox7b.Items.Add("Satuan Kecil") : arrcari2b.Add("Satuan_Kecil") ': arrcaribsf.Add("{barang.Satuan}")
        ComboBox7b.Items.Add("Satuan Besar") : arrcari2b.Add("Satuan_Besar") ': arrcaribsf.Add("{barang.Satuan}")
        'ComboBox7b.Items.Add("Harga Beli") : arrcari2b.Add("x.Harga_Beli") : arrcari2bsf.Add("{barang.Harga_Beli}")
        'ComboBox7b.Items.Add("Harga Jual") : arrcari2b.Add("x.Harga_Jual") : arrcari2bsf.Add("{barang.Harga_Jual}")
        'ComboBox7b.Items.Add("Stock") : arrcari2b.Add("x.Good_Stock") : arrcari2bsf.Add("{barang.Good_Stock}")
        'ComboBox7b.Items.Add("Stock Minimum") : arrcari2b.Add("x.Stock_Minimum") : arrcari2bsf.Add("{barang.Stock_Minimum}")
        'ComboBox7b.Items.Add("Lemari") : arrcari2b.Add("Lemari")
        'ComboBox7b.Items.Add("Kategori") : arrcari2b.Add("x.kode_kategori") : arrcari2bsf.Add("{barang.kode_kategori}")

        ComboBox1b.Enabled = False : TextBox7b.Enabled = False
        ComboBox1b.SelectedIndex = -1 : TextBox7b.Text = ""
        ComboBox1.Enabled = False : ComboBox3.Enabled = False : ComboBox4.Enabled = False
        ComboBox1.SelectedIndex = 0 : ComboBox3.SelectedIndex = 1 : ComboBox4.SelectedIndex = 1

        arrSO.Clear()

        Try
            OpenConn()

            Dim ff_kd_kota As String = ""
            SQL = "Select kode_kota From stock_owner where "
            SQL = SQL & "kode_perusahaan = '" & KodePerusahaan & "' and "
            SQL = SQL & "kode_stock_owner = '" & Lokasi & "'"
            Using dr = OpenTrans(SQL)
                If dr.Read Then
                    ff_kd_kota = dr("kode_kota")
                Else
                    ff_kd_kota = "X"
                End If
            End Using

            SQL = "Select kode_kota From kota where "
            SQL = SQL & "kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by kode_kota"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboKota.Items.Add(dr("kode_kota"))
                Loop
            End Using
            ComboKota.Text = ff_kd_kota

            ComboBox7.Items.Clear()
            ComboBox7.Items.Add("---SELURUH---")
            'SQL = "select Kode_Stock_Owner from Stock_Owner_Gudang_lain where "
            'SQL = SQL & "Kode_Perusahaan = '" & KodePerusahaan & "' order by Kode_Stock_Owner"

            SQL = "select Kode_Stock_Owner "
            SQL = SQL & "FROM Stock_Owner_Gudang_lain a "
            SQL = SQL & "inner JOIN N_EMI_Master_Kategori_Gudang_Barang_Lain b on a.Kode_Perusahaan = b.kode_perusahaan and a.Kode_Stock_Owner = b.Kode_Stock_Owner_Gudang "
            SQL = SQL & "inner JOIN N_EMI_Master_Kategori_Gudang_Binding_User_Barang_Lain c ON b.Kode_Perusahaan = c.Kode_Perusahaan and b.Urut_Oto = c.Id_Kategori_Gudang "
            SQL = SQL & "WHERE a.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and c.User_ID = '" & UserID & "' "
            SQL = SQL & "ORDER BY a.Kode_Stock_Owner "
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox7.Items.Add(dr("Kode_Stock_Owner"))
                Loop
            End Using
            ComboBox7.SelectedIndex = 0

            ComboBox8.Items.Clear() : arrGroup_Jenis.Clear()
            ComboBox8.Items.Add("---SELURUH---") : arrGroup_Jenis.Add("")
            SQL = "select Kode_Group_Jenis,Id_Group_Jenis from EMI_Group_Jenis_Lain "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by Kode_Group_Jenis"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox8.Items.Add(dr("Kode_Group_Jenis"))
                    arrGroup_Jenis.Add(dr("Id_Group_Jenis"))
                Loop
            End Using
            ComboBox8.SelectedIndex = 0

            ComboBox9.Items.Clear() : arrArea.Clear()
            ComboBox9.Items.Add("---SELURUH---") : arrArea.Add("")
            SQL = "select Id_WMS_Area,Kode_WMS_Area from EMI_WMS_Areas "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by Kode_WMS_Area"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox9.Items.Add(dr("Kode_WMS_Area"))
                    arrArea.Add(dr("Id_WMS_Area"))
                Loop
            End Using
            ComboBox9.SelectedIndex = 0

            ComboBox10.Items.Clear() : arrRow.Clear()
            ComboBox10.Items.Add("---SELURUH---") : arrRow.Add("")
            SQL = "select Id_WMS_Row,Kode_WMS_Row from EMI_WMS_Row "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by Kode_WMS_Row"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox10.Items.Add(dr("Kode_WMS_Row"))
                    arrRow.Add(dr("Id_WMS_Row"))
                Loop
            End Using
            ComboBox10.SelectedIndex = 0

            ComboBox13.Items.Clear() : arrBay.Clear()
            ComboBox13.Items.Add("---SELURUH---") : arrBay.Add("")
            SQL = "select Id_WMS_Bay,Kode_WMS_Bay from EMI_WMS_Bay "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by Kode_WMS_Bay"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox13.Items.Add(dr("Kode_WMS_Bay"))
                    arrBay.Add(dr("Id_WMS_Bay"))
                Loop
            End Using
            ComboBox13.SelectedIndex = 0

            ComboBox11.Items.Clear() : arrLevel.Clear()
            ComboBox11.Items.Add("---SELURUH---") : arrLevel.Add("")
            SQL = "select Id_WMS_Level,Kode_WMS_Level from EMI_WMS_Level "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by Kode_WMS_Level"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox11.Items.Add(dr("Kode_WMS_Level"))
                    arrLevel.Add(dr("Id_WMS_Level"))
                Loop
            End Using
            ComboBox11.SelectedIndex = 0

            ComboBox12.Items.Clear() : arrPosition.Clear()
            ComboBox12.Items.Add("---SELURUH---") : arrPosition.Add("")
            SQL = "select Id_WMS_Position,Kode_WMS_Position from EMI_WMS_Position "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by Kode_WMS_Position"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox12.Items.Add(dr("Kode_WMS_Position"))
                    arrPosition.Add(dr("Id_WMS_Position"))
                Loop
            End Using
            ComboBox12.SelectedIndex = 0


            cmbStatus.Items.Clear() : arrStatus.Clear()
            cmbStatus.Items.Add("---SELURUH---") : arrStatus.Add("")
            SQL = "select id,kode_warna,Keterangan From EMI_Master_Warna  "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by keterangan "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    cmbStatus.Items.Add(Dr("keterangan")) : arrStatus.Add(Dr("kode_warna"))
                Loop
            End Using
            cmbStatus.SelectedIndex = 0



            If CekButtonRole("Ganti_Lokasi_Display_Barang_Lain") = "T" Then
                ComboKota.Enabled = False
            Else
                ComboKota.Enabled = True
            End If





            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

        Try
            OpenConn()

            If CekButtonRole("Cetak_Display_Barang_Detail_HPP") = "T" Then
                Btn_Cetak_Detail_HPP.Visible = False
            Else
                Btn_Cetak_Detail_HPP.Visible = True
            End If

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
        'If UserLevel = "1" Then
        '    ComboBox7.Enabled = True
        'Else
        '    ComboBox7.Enabled = False
        'End If
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If CheckBox1.Checked = True Then
            If ComboBox1b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox1b.Focus() : Exit Sub
            ElseIf TextBox7b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox7b.Focus() : Exit Sub
            End If
        End If

        If CheckBox2.Checked = True Then
            If ComboBox7b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox7b.Focus() : Exit Sub
            ElseIf TextBox6b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox6b.Focus() : Exit Sub
            End If
        End If

        If ComboBox7.Text.Trim.Length = 0 Then
            MessageBox.Show("Gudang belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox7.Focus() : Exit Sub
        ElseIf ComboBox8.Text.Trim.Length = 0 Then
            MessageBox.Show("Jenis belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox8.Focus() : Exit Sub
        ElseIf ComboBox9.Text.Trim.Length = 0 Then
            MessageBox.Show("Area belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox9.Focus() : Exit Sub
        ElseIf ComboBox10.Text.Trim.Length = 0 Then
            MessageBox.Show("Row belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox10.Focus() : Exit Sub
        ElseIf ComboBox13.Text.Trim.Length = 0 Then
            MessageBox.Show("Bay belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox13.Focus() : Exit Sub
        ElseIf ComboBox11.Text.Trim.Length = 0 Then
            MessageBox.Show("Level belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox11.Focus() : Exit Sub
        ElseIf ComboBox12.Text.Trim.Length = 0 Then
            MessageBox.Show("Position belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox12.Focus() : Exit Sub
        End If

        'DataGridView1.Columns(7).HeaderText = "QR CODE"
        ' DataGridView1.Columns(9).Visible = False

        Try


            OpenConn()

            Cek_Flagging_Barang_Lain()

            DataGridView1.Rows.Clear()
            SQL = "select a.*, dbo.get_hpp(a.serial_number) as HPP "
            SQL = SQL & "from Stock_Barang_Lain_SN_Per_Rak as a inner join EMI_Group_Jenis_Lain as gj on a.id_group_jenis = gj.id_group_jenis "
            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.user_id = '" & UserID & "' "


            'SQL = SQL & "gj.Flag_Packaging = '" & Flag_Packaging & "' and gj.Flag_Raw_Material = '" & Flag_Raw_Material & "' and "
            'SQL = SQL & "gj.Flag_Finished_Good = '" & Flag_Finished_Good & "' and gj.Flag_Sample = '" & Flag_Sample & "' and "
            'SQL = SQL & "gj.Flag_Semi_FG = '" & Flag_Semi_FG & "' and gj.Flag_Scrap = '" & Flag_Scrap & "' and "
            'SQL = SQL & "gj.Flag_Bahan_Bakar = '" & Flag_Bahan_Bakar & "' and gj.Flag_Peralatan = '" & Flag_Peralatan & "' "
            '6
            'SQL = SQL & FilterPengeluaranCostCenter
            '            SQL = SQL & "AND (gj.flag_ATK = '" & fATK & "' OR gj.flag_asset = '" & fAsset & "' OR gj.flag_sparepart = '" & fSparepart & "' or gj.flag_peralatan = '" & fPeralatan & "'") "

            'SQL = SQL & FilterPengeluaranCostCenter

            If CheckBox1.Checked = True Then
                SQL = SQL & " And a." & arrcarib.Item(ComboBox1b.SelectedIndex) & " " & ComboBox1.Text & " '" & ComboBox3.Text & TextBox7b.Text & ComboBox4.Text & "' "
            End If

            If CheckBox2.Checked = True Then
                SQL = SQL & " and a." & arrcari2b.Item(ComboBox7b.SelectedIndex) & " " & ComboBox2.Text & " '" & ComboBox5.Text & TextBox6b.Text & ComboBox6.Text & "' "
            End If

            If ComboBox7.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Stock_Owner = '" & ComboBox7.Text & "' "
            End If

            If ComboBox8.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Group_Jenis = '" & ComboBox8.Text & "' "
            End If

            If ComboBox9.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Area = '" & ComboBox9.Text & "' "
            End If

            If ComboBox10.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Row = '" & ComboBox10.Text & "' "
            End If

            If ComboBox13.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Bay = '" & ComboBox13.Text & "' "
            End If

            If ComboBox11.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Level = '" & ComboBox11.Text & "' "
            End If

            If ComboBox12.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Position = '" & ComboBox12.Text & "' "
            End If

            If cmbStatus.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.warna = '" & cmbStatus.Text & "' "
            End If

            SQL = SQL & "order by a.kode_stock_owner, a.nama, a.Labeling_WMS_Position"
            Using ds = BindingTrans(SQL)
                With ds.Tables("MyTable")
                    For i As Integer = 0 To .Rows.Count - 1
                        DataGridView1.Rows.Add(1)

                        Dim stock_tersedia As String = ""
                        'Format(.Rows(i).Item("Total_Stock_Tersedia_Satuan_Besar"), "N0")

                        DataGridView1.Rows.Item(i).Cells(0).Value = .Rows(i).Item("kode_stock_owner")
                        DataGridView1.Rows.Item(i).Cells(1).Value = .Rows(i).Item("kode_group_jenis")
                        DataGridView1.Rows.Item(i).Cells(2).Value = .Rows(i).Item("kode_barang")
                        DataGridView1.Rows.Item(i).Cells(3).Value = .Rows(i).Item("nama")
                        DataGridView1.Rows.Item(i).Cells(4).Value = Format(.Rows(i).Item("Total_Stock_Tersedia_Satuan_Besar"), "N2") & " " & .Rows(i).Item("Satuan_Besar")
                        DataGridView1.Rows.Item(i).Cells(5).Value = Format(.Rows(i).Item("jumlah_bags"), "N2")
                        If IsDBNull(.Rows(i).Item("tgl_produksi")) Then
                            DataGridView1.Rows.Item(i).Cells(6).Value = ""
                        Else
                            DataGridView1.Rows.Item(i).Cells(6).Value = Format(.Rows(i).Item("Tgl_produksi"), "dd MMM yyyy") '.Rows(i).Item("Total_Stock_Inquiry_Satuan_Besar") & " " & .Rows(i).Item("Satuan_Besar")
                        End If
                        If IsDBNull(.Rows(i).Item("tgl_expired")) Then
                            DataGridView1.Rows.Item(i).Cells(7).Value = ""
                        Else
                            DataGridView1.Rows.Item(i).Cells(7).Value = Format(.Rows(i).Item("Tgl_expired"), "dd MMM yyyy") '& " " & .Rows(i).Item("Satuan_Besar")
                        End If
                        DataGridView1.Rows.Item(i).Cells(8).Value = .Rows(i).Item("Qr_Code")
                        DataGridView1.Rows.Item(i).Cells(9).Value = .Rows(i).Item("Labeling_WMS_Position")
                        DataGridView1.Rows.Item(i).Cells(10).Value = "" 'Format(.Rows(i).Item("HPP"), "N2")

                        If IsDBNull(.Rows(i).Item("sisa_umur")) Then
                            DataGridView1.Rows.Item(i).Cells(11).Value = ""
                        Else
                            DataGridView1.Rows.Item(i).Cells(11).Value = .Rows(i).Item("sisa_umur") & " hari"
                        End If

                        If IsDBNull(.Rows(i).Item("umur")) Then
                            DataGridView1.Rows.Item(i).Cells(12).Value = ""
                        Else
                            DataGridView1.Rows.Item(i).Cells(12).Value = .Rows(i).Item("umur") & " hari"
                        End If

                        If IsDBNull(.Rows(i).Item("warna")) Then
                            DataGridView1.Rows.Item(i).Cells(13).Value = ""
                        Else
                            DataGridView1.Rows.Item(i).Cells(13).Value = .Rows(i).Item("warna") & ""
                        End If
                    Next
                End With
            End Using

            Dgv_BarangPerlokasi.Rows.Clear()
            SQL = "select a.* "
            SQL = SQL & "from Stock_Barang_lain_SN_Per_lokasi as a inner join emi_group_jenis_lain as gj on a.kode_group_jenis = gj.kode_group_jenis "
            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "AND a.user_id = '" & UserID & "' "

            'SQL = SQL & "gj.Flag_Packaging = '" & Flag_Packaging & "' and gj.Flag_Raw_Material = '" & Flag_Raw_Material & "' and "
            'SQL = SQL & "gj.Flag_Finished_Good = '" & Flag_Finished_Good & "' and gj.Flag_Sample = '" & Flag_Sample & "' and "
            'SQL = SQL & "gj.Flag_Semi_FG = '" & Flag_Semi_FG & "' and gj.Flag_Scrap = '" & Flag_Scrap & "' and "
            'SQL = SQL & "gj.Flag_Bahan_Bakar = '" & Flag_Bahan_Bakar & "' and gj.Flag_Peralatan = '" & Flag_Peralatan & "' "

            '1
            ' SQL = SQL & FilterPengeluaranCostCenter
            SQL = SQL & "AND (gj.flag_ATK = '" & fATK & "' OR gj.flag_asset = '" & fAsset & "' OR gj.flag_sparepart = '" & fSparepart & "') "

            If CheckBox1.Checked = True Then
                SQL = SQL & " and a." & arrcarib.Item(ComboBox1b.SelectedIndex) & " " & ComboBox1.Text & " '" & ComboBox3.Text & TextBox7b.Text & ComboBox4.Text & "' "
            End If

            If CheckBox2.Checked = True Then
                SQL = SQL & " and a." & arrcari2b.Item(ComboBox7b.SelectedIndex) & " " & ComboBox2.Text & " '" & ComboBox5.Text & TextBox6b.Text & ComboBox6.Text & "' "
            End If

            If ComboBox7.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Stock_Owner = '" & ComboBox7.Text & "' "
            End If

            If ComboBox8.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Group_Jenis = '" & ComboBox8.Text & "' "
            End If

            If cmbStatus.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.warna = '" & cmbStatus.Text & "' "
            End If



            SQL = SQL & "order by a.kode_stock_owner, a.nama"
            Using ds = BindingTrans(SQL)
                With ds.Tables("MyTable")
                    For i As Integer = 0 To .Rows.Count - 1
                        Dgv_BarangPerlokasi.Rows.Add(1)

                        Dim stock_tersedia As String = ""
                        'Format(.Rows(i).Item("Total_Stock_Tersedia_Satuan_Besar"), "N0")

                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(0).Value = .Rows(i).Item("kode_stock_owner")
                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(1).Value = .Rows(i).Item("kode_group_jenis")
                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(2).Value = .Rows(i).Item("kode_barang")
                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(3).Value = .Rows(i).Item("nama")
                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(4).Value = Format(.Rows(i).Item("Total_Stock_Tersedia_Satuan_Besar"), "N2") & " " & .Rows(i).Item("Satuan_Besar")
                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(5).Value = Format(.Rows(i).Item("jumlah_bags"), "N2")
                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(6).Value = .Rows(i).Item("satuan_besar")
                        Dgv_BarangPerlokasi.Rows.Item(i).Cells(7).Value = .Rows(i).Item("warna")
                    Next
                End With
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub BtnCetak_Click_1(sender As Object, e As EventArgs) Handles BtnCetak.Click
        If CheckBox1.Checked = True Then
            If ComboBox1b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox1b.Focus() : Exit Sub
            ElseIf TextBox7b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox7b.Focus() : Exit Sub
            End If
        End If

        If CheckBox2.Checked = True Then
            If ComboBox7b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox7b.Focus() : Exit Sub
            ElseIf TextBox6b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox6b.Focus() : Exit Sub
            End If
        End If

        If ComboBox7.Text.Trim.Length = 0 Then
            MessageBox.Show("Gudang belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox7.Focus() : Exit Sub
        ElseIf ComboBox8.Text.Trim.Length = 0 Then
            MessageBox.Show("Jenis belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox8.Focus() : Exit Sub
        ElseIf ComboBox9.Text.Trim.Length = 0 Then
            MessageBox.Show("Area belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox9.Focus() : Exit Sub
        ElseIf ComboBox10.Text.Trim.Length = 0 Then
            MessageBox.Show("Row belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox10.Focus() : Exit Sub
        ElseIf ComboBox13.Text.Trim.Length = 0 Then
            MessageBox.Show("Bay belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox13.Focus() : Exit Sub
        ElseIf ComboBox11.Text.Trim.Length = 0 Then
            MessageBox.Show("Level belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox11.Focus() : Exit Sub
        ElseIf ComboBox12.Text.Trim.Length = 0 Then
            MessageBox.Show("Position belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox12.Focus() : Exit Sub
        End If

        '   DataGridView1.Columns(7).HeaderText = "QR CODE"
        ' DataGridView1.Columns(9).Visible = False

        Dim SF As String = ""

        Try

            OpenConn()

            Cek_Flagging_Barang_Lain()

            SQL = "select a.*, dbo.get_hpp(a.serial_number) as HPP "
            SQL = SQL & "from Stock_Barang_Lain_SN_Per_Rak as a inner join emi_group_jenis_lain as gj on a.id_group_jenis = gj.id_group_jenis "
            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.user_id = '" & UserID & "' "

            'SQL = SQL & "gj.Flag_Packaging = '" & Flag_Packaging & "' and gj.Flag_Raw_Material = '" & Flag_Raw_Material & "' and "
            'SQL = SQL & "gj.Flag_Finished_Good = '" & Flag_Finished_Good & "' and gj.Flag_Sample = '" & Flag_Sample & "' and "
            'SQL = SQL & "gj.Flag_Semi_FG = '" & Flag_Semi_FG & "' and gj.Flag_Scrap = '" & Flag_Scrap & "' and "
            'SQL = SQL & "gj.Flag_Bahan_Bakar = '" & Flag_Bahan_Bakar & "' and gj.Flag_Peralatan = '" & Flag_Peralatan & "' "
            '2
            'SQL = SQL & FilterPengeluaranCostCenter
            SQL = SQL & "AND (gj.flag_ATK = '" & fATK & "' OR gj.flag_asset = '" & fAsset & "' OR gj.flag_sparepart = '" & fSparepart & "') "

            SF = "{Stock_Barang_Lain_SN_Per_Rak.Kode_Perusahaan} = '" & KodePerusahaan & "' "
            SF = SF & "AND {Stock_Barang_Lain_SN_Per_Rak.user_id} = '" & UserID & "' "
            'SF = SF & "{EMI_Group_Jenis.Flag_Packaging} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Raw_Material} = 'T' and {EMI_Group_Jenis.Flag_Finished_Good} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Sample} = 'T' and {EMI_Group_Jenis.Flag_Semi_FG} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Scrap} = 'T' and {EMI_Group_Jenis.Flag_Bahan_Bakar} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Peralatan} = 'T'  "
            '3
            '  SF = SF & FilterPengeluaranCostCenterCR
            SF = SF & "AND ({EMI_Group_Jenis_Lain.Flag_ATK} = '" & fATK & "' or {EMI_Group_Jenis_Lain.Flag_Asset} = '" & fAsset & "' or {EMI_Group_Jenis_Lain.Flag_Sparepart} = '" & fSparepart & "')"


            If CheckBox1.Checked = True Then
                SQL = SQL & " and a." & arrcarib.Item(ComboBox1b.SelectedIndex) & " " & ComboBox1.Text & " '" & ComboBox3.Text & TextBox7b.Text & ComboBox4.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak." & arrcarib.Item(ComboBox1b.SelectedIndex) & "} " & ComboBox1.Text & " '"
                SF = SF & Strings.Replace(ComboBox3.Text, "%", "*") & TextBox7b.Text & Strings.Replace(ComboBox4.Text, "%", "*") & "' "
            End If

            If CheckBox2.Checked = True Then
                SQL = SQL & " and a." & arrcari2b.Item(ComboBox7b.SelectedIndex) & " " & ComboBox2.Text & " '" & ComboBox5.Text & TextBox6b.Text & ComboBox6.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak." & arrcari2b.Item(ComboBox7b.SelectedIndex) & "} " & ComboBox2.Text & " '"
                SF = SF & Strings.Replace(ComboBox5.Text, "%", "*") & TextBox6b.Text & Strings.Replace(ComboBox6.Text, "%", "*") & "' "
            End If

            If ComboBox7.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Stock_Owner = '" & ComboBox7.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_Stock_Owner} = '" & ComboBox7.Text & "' "
            End If

            If ComboBox8.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Group_Jenis = '" & ComboBox8.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_Group_Jenis} = '" & ComboBox8.Text & "'"
            End If

            If ComboBox9.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Area = '" & ComboBox9.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Area} = '" & ComboBox9.Text & "' "
            End If

            If ComboBox10.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Row = '" & ComboBox10.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Row} = '" & ComboBox10.Text & "' "
            End If

            If ComboBox13.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Bay = '" & ComboBox13.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Bay} = '" & ComboBox13.Text & "' "
            End If

            If ComboBox11.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Level = '" & ComboBox11.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Level} = '" & ComboBox11.Text & "' "
            End If

            If ComboBox12.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Position = '" & ComboBox12.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Position} = '" & ComboBox12.Text & "' "
            End If

            SQL = SQL & "order by a.kode_stock_owner, a.nama, a.Labeling_WMS_Position"

            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then

                        Dim CrDoc As New Display_Barang_Detail_Lain_Rpt

                        CrDoc.SetDataSource(Ds)
                        CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                        CrDoc.SummaryInfo.ReportTitle = ""
                        CrDoc.RecordSelectionFormula = SF

                        With A_Place_For_Printing2
                            .Text = "Print Form"
                            .CrystalReportViewer1.ReportSource = CrDoc
                            .CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                            .Refresh()
                            .Show()
                        End With

                    Else
                        MessageBox.Show("Data tidak ditemukan!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End With
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub Btn_Cetak_Detail_HPP_Click(sender As Object, e As EventArgs) Handles Btn_Cetak_Detail_HPP.Click
        If CheckBox1.Checked = True Then
            If ComboBox1b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox1b.Focus() : Exit Sub
            ElseIf TextBox7b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox7b.Focus() : Exit Sub
            End If
        End If

        If CheckBox2.Checked = True Then
            If ComboBox7b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox7b.Focus() : Exit Sub
            ElseIf TextBox6b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox6b.Focus() : Exit Sub
            End If
        End If

        If ComboBox7.Text.Trim.Length = 0 Then
            MessageBox.Show("Gudang belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox7.Focus() : Exit Sub
        ElseIf ComboBox8.Text.Trim.Length = 0 Then
            MessageBox.Show("Jenis belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox8.Focus() : Exit Sub
        ElseIf ComboBox9.Text.Trim.Length = 0 Then
            MessageBox.Show("Area belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox9.Focus() : Exit Sub
        ElseIf ComboBox10.Text.Trim.Length = 0 Then
            MessageBox.Show("Row belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox10.Focus() : Exit Sub
        ElseIf ComboBox13.Text.Trim.Length = 0 Then
            MessageBox.Show("Bay belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox13.Focus() : Exit Sub
        ElseIf ComboBox11.Text.Trim.Length = 0 Then
            MessageBox.Show("Level belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox11.Focus() : Exit Sub
        ElseIf ComboBox12.Text.Trim.Length = 0 Then
            MessageBox.Show("Position belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox12.Focus() : Exit Sub
        End If

        '   DataGridView1.Columns(7).HeaderText = "QR CODE"
        ' DataGridView1.Columns(9).Visible = False

        Try
            OpenConn()

            If CekButtonRole("Cetak_Display_Barang_Detail_HPP") = "T" Then
                MessageBox.Show("Anda Tidak Memiliki Akses untuk Melakukan Cetak Laporan Ini", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

        Dim SF As String = ""

        Try

            OpenConn()

            Cek_Flagging_Barang_Lain()

            SQL = "select a.*, dbo.get_hpp(a.serial_number) as HPP "
            SQL = SQL & "from Stock_Barang_Lain_SN_Per_Rak as a inner join emi_group_jenis_lain as gj on a.id_group_jenis = gj.id_group_jenis "
            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.user_id = '" & UserID & "' "

            'SQL = SQL & "gj.Flag_Packaging = '" & Flag_Packaging & "' and gj.Flag_Raw_Material = '" & Flag_Raw_Material & "' and "
            'SQL = SQL & "gj.Flag_Finished_Good = '" & Flag_Finished_Good & "' and gj.Flag_Sample = '" & Flag_Sample & "' and "
            'SQL = SQL & "gj.Flag_Semi_FG = '" & Flag_Semi_FG & "' and gj.Flag_Scrap = '" & Flag_Scrap & "' and "
            'SQL = SQL & "gj.Flag_Bahan_Bakar = '" & Flag_Bahan_Bakar & "' and gj.Flag_Peralatan = '" & Flag_Peralatan & "' "
            '2
            'SQL = SQL & FilterPengeluaranCostCenter
            SQL = SQL & "AND (gj.flag_ATK = '" & fATK & "' OR gj.flag_asset = '" & fAsset & "' OR gj.flag_sparepart = '" & fSparepart & "') "

            SF = "{Stock_Barang_Lain_SN_Per_Rak.Kode_Perusahaan} = '" & KodePerusahaan & "' "
            SF = SF & "AND {Stock_Barang_Lain_SN_Per_Rak.user_id} = '" & UserID & "' "
            'SF = SF & "{EMI_Group_Jenis.Flag_Packaging} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Raw_Material} = 'T' and {EMI_Group_Jenis.Flag_Finished_Good} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Sample} = 'T' and {EMI_Group_Jenis.Flag_Semi_FG} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Scrap} = 'T' and {EMI_Group_Jenis.Flag_Bahan_Bakar} = 'T' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Peralatan} = 'T'  "
            '3
            '  SF = SF & FilterPengeluaranCostCenterCR
            SF = SF & "AND ({EMI_Group_Jenis_Lain.Flag_ATK} = '" & fATK & "' or {EMI_Group_Jenis_Lain.Flag_Asset} = '" & fAsset & "' or {EMI_Group_Jenis_Lain.Flag_Sparepart} = '" & fSparepart & "')"


            If CheckBox1.Checked = True Then
                SQL = SQL & " and a." & arrcarib.Item(ComboBox1b.SelectedIndex) & " " & ComboBox1.Text & " '" & ComboBox3.Text & TextBox7b.Text & ComboBox4.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak." & arrcarib.Item(ComboBox1b.SelectedIndex) & "} " & ComboBox1.Text & " '"
                SF = SF & Strings.Replace(ComboBox3.Text, "%", "*") & TextBox7b.Text & Strings.Replace(ComboBox4.Text, "%", "*") & "' "
            End If

            If CheckBox2.Checked = True Then
                SQL = SQL & " and a." & arrcari2b.Item(ComboBox7b.SelectedIndex) & " " & ComboBox2.Text & " '" & ComboBox5.Text & TextBox6b.Text & ComboBox6.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak." & arrcari2b.Item(ComboBox7b.SelectedIndex) & "} " & ComboBox2.Text & " '"
                SF = SF & Strings.Replace(ComboBox5.Text, "%", "*") & TextBox6b.Text & Strings.Replace(ComboBox6.Text, "%", "*") & "' "
            End If

            If ComboBox7.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Stock_Owner = '" & ComboBox7.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_Stock_Owner} = '" & ComboBox7.Text & "' "
            End If

            If ComboBox8.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Group_Jenis = '" & ComboBox8.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_Group_Jenis} = '" & ComboBox8.Text & "'"
            End If

            If ComboBox9.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Area = '" & ComboBox9.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Area} = '" & ComboBox9.Text & "' "
            End If

            If ComboBox10.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Row = '" & ComboBox10.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Row} = '" & ComboBox10.Text & "' "
            End If

            If ComboBox13.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Bay = '" & ComboBox13.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Bay} = '" & ComboBox13.Text & "' "
            End If

            If ComboBox11.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Level = '" & ComboBox11.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Level} = '" & ComboBox11.Text & "' "
            End If

            If ComboBox12.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_WMS_Position = '" & ComboBox12.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_Rak.Kode_WMS_Position} = '" & ComboBox12.Text & "' "
            End If

            SQL = SQL & "order by a.kode_stock_owner, a.nama, a.Labeling_WMS_Position"

            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then

                        Dim CrDoc As New N_EMI_CR_Laporan_Display_Barang_Detail_HPP

                        CrDoc.SetDataSource(Ds)
                        CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                        CrDoc.SummaryInfo.ReportTitle = ""
                        CrDoc.RecordSelectionFormula = SF

                        With A_Place_For_Printing2
                            .Text = "Print Form"
                            .CrystalReportViewer1.ReportSource = CrDoc
                            .CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                            .Refresh()
                            .Show()
                        End With

                    Else
                        MessageBox.Show("Data tidak ditemukan!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End With
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub


    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        If CheckBox1.Checked = True Then
            If ComboBox1b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox1b.Focus() : Exit Sub
            ElseIf TextBox7b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 1 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox7b.Focus() : Exit Sub
            End If
        End If

        If CheckBox2.Checked = True Then
            If ComboBox7b.SelectedIndex = -1 Then
                MessageBox.Show("Parameter 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                ComboBox7b.Focus() : Exit Sub
            ElseIf TextBox6b.Text.Trim.Length = 0 Then
                MessageBox.Show("Value 2 belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox6b.Focus() : Exit Sub
            End If
        End If

        If ComboBox7.Text.Trim.Length = 0 Then
            MessageBox.Show("Gudang belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox7.Focus() : Exit Sub
        ElseIf ComboBox8.Text.Trim.Length = 0 Then
            MessageBox.Show("Jenis belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox8.Focus() : Exit Sub
        ElseIf ComboBox9.Text.Trim.Length = 0 Then
            MessageBox.Show("Area belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox9.Focus() : Exit Sub
        ElseIf ComboBox10.Text.Trim.Length = 0 Then
            MessageBox.Show("Row belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox10.Focus() : Exit Sub
        ElseIf ComboBox13.Text.Trim.Length = 0 Then
            MessageBox.Show("Bay belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox13.Focus() : Exit Sub
        ElseIf ComboBox11.Text.Trim.Length = 0 Then
            MessageBox.Show("Level belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox11.Focus() : Exit Sub
        ElseIf ComboBox12.Text.Trim.Length = 0 Then
            MessageBox.Show("Position belum diisi!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            ComboBox12.Focus() : Exit Sub
        End If

        '   DataGridView1.Columns(7).HeaderText = "QR CODE"
        '  DataGridView1.Columns(9).Visible = False

        Dim SF As String = ""

        Try

            OpenConn()

            Cek_Flagging_Barang_Lain()

            SQL = "select a.* "
            SQL = SQL & "from Stock_Barang_lain_SN_Per_Lokasi as a inner join emi_group_jenis_Lain as gj on a.kode_group_jenis = gj.kode_group_jenis "

            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.user_id = '" & UserID & "' "

            'SQL = SQL & "gj.Flag_Packaging = '" & Flag_Packaging & "' and gj.Flag_Raw_Material = '" & Flag_Raw_Material & "' and "
            'SQL = SQL & "gj.Flag_Finished_Good = '" & Flag_Finished_Good & "' and gj.Flag_Sample = '" & Flag_Sample & "' and "
            'SQL = SQL & "gj.Flag_Semi_FG = '" & Flag_Semi_FG & "' and gj.Flag_Scrap = '" & Flag_Scrap & "' and "
            'SQL = SQL & "gj.Flag_Bahan_Bakar = '" & Flag_Bahan_Bakar & "' and gj.Flag_Peralatan = '" & Flag_Peralatan & "' "
            '4
            'SQL = SQL & FilterPengeluaranCostCenter
            SQL = SQL & "AND (gj.flag_ATK = '" & fATK & "' OR gj.flag_asset = '" & fAsset & "' OR gj.flag_sparepart = '" & fSparepart & "') "

            SF = "{Stock_Barang_Lain_SN_Per_lokasi.Kode_Perusahaan} = '" & KodePerusahaan & "' "
            SF = SF & "AND {Stock_Barang_Lain_SN_Per_lokasi.user_id} = '" & UserID & "' "
            'SF = SF & "{EMI_Group_Jenis.Flag_Packaging} = '" & Flag_Packaging & "' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Raw_Material} = '" & Flag_Raw_Material & "' and {EMI_Group_Jenis.Flag_Finished_Good} = '" & Flag_Finished_Good & "' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Sample} = '" & Flag_Sample & "' and {EMI_Group_Jenis.Flag_Semi_FG} = '" & Flag_Semi_FG & "' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Scrap} = '" & Flag_Scrap & "' and {EMI_Group_Jenis.Flag_Bahan_Bakar} = '" & Flag_Bahan_Bakar & "' and "
            'SF = SF & "{EMI_Group_Jenis.Flag_Peralatan} = '" & Flag_Peralatan & "' and "
            '5
            ' SF = SF & FilterPengeluaranCostCenterCR
            SF = SF & "AND ({EMI_Group_Jenis_lain.Flag_ATK} = '" & fATK & "' or {EMI_Group_Jenis_lain.Flag_Asset} = '" & fAsset & "' or {EMI_Group_Jenis_lain.Flag_Sparepart} = '" & fSparepart & "')"

            If CheckBox1.Checked = True Then
                SQL = SQL & " and a." & arrcarib.Item(ComboBox1b.SelectedIndex) & " " & ComboBox1.Text & " '" & ComboBox3.Text & TextBox7b.Text & ComboBox4.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_lokasi." & arrcarib.Item(ComboBox1b.SelectedIndex) & "} " & ComboBox1.Text & " '"
                SF = SF & Strings.Replace(ComboBox3.Text, "%", "*") & TextBox7b.Text & Strings.Replace(ComboBox4.Text, "%", "*") & "' "
            End If

            If CheckBox2.Checked = True Then
                SQL = SQL & " and a." & arrcari2b.Item(ComboBox7b.SelectedIndex) & " " & ComboBox2.Text & " '" & ComboBox5.Text & TextBox6b.Text & ComboBox6.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_lokasi." & arrcari2b.Item(ComboBox7b.SelectedIndex) & "} " & ComboBox2.Text & " '"
                SF = SF & Strings.Replace(ComboBox5.Text, "%", "*") & TextBox6b.Text & Strings.Replace(ComboBox6.Text, "%", "*") & "' "
            End If

            If ComboBox7.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Stock_Owner = '" & ComboBox7.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_lokasi.Kode_Stock_Owner} = '" & ComboBox7.Text & "' "
            End If

            If ComboBox8.SelectedIndex = 0 Then
                SQL = SQL & ""
            Else
                SQL = SQL & " and a.Kode_Group_Jenis = '" & ComboBox8.Text & "' "

                SF = SF & " and {Stock_Barang_Lain_SN_Per_lokasi.Kode_Group_Jenis} = '" & ComboBox8.Text & "' "
            End If

            SQL = SQL & "order by a.kode_stock_owner, a.nama"

            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then

                        Dim CrDoc As New Display_Barang_Lain_Rpt

                        CrDoc.SetDataSource(Ds)
                        CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                        CrDoc.SummaryInfo.ReportTitle = ""
                        CrDoc.RecordSelectionFormula = SF

                        With A_Place_For_Printing2
                            .Text = "Print Form"
                            .CrystalReportViewer1.ReportSource = CrDoc
                            .CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                            .Refresh()
                            .Show()
                        End With

                    Else
                        MessageBox.Show("Data tidak ditemukan!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End With
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub Perusahaan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Kosongb("Y")

        ComboBox1b.Focus()
    End Sub

    Private Sub ComboBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox1b.KeyPress
        If e.KeyChar = Chr(13) Then ComboBox1.Focus()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5b.Click
        carib("T", "T", "T")
    End Sub

    Private Sub TextBox7_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox7b.KeyPress
        If e.KeyChar = Chr(13) Then Button1_Click_1(TextBox7b, e)
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6b.Click
        carib("Y", "T", "T")
    End Sub

    Private Sub ComboBox7_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox7b.KeyPress
        If e.KeyChar = Chr(13) Then ComboBox2.Focus()
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            ComboBox1b.Enabled = True : TextBox7b.Enabled = True
            ComboBox1b.SelectedIndex = -1 : TextBox7b.Text = ""
            ComboBox1.Enabled = True : ComboBox3.Enabled = True : ComboBox4.Enabled = True
            ComboBox1.SelectedIndex = 0 : ComboBox3.SelectedIndex = 1 : ComboBox4.SelectedIndex = 1
        Else
            ComboBox1b.Enabled = False : TextBox7b.Enabled = False
            ComboBox1b.SelectedIndex = -1 : TextBox7b.Text = ""
            ComboBox1.Enabled = False : ComboBox3.Enabled = False : ComboBox4.Enabled = False
            ComboBox1.SelectedIndex = 0 : ComboBox3.SelectedIndex = 1 : ComboBox4.SelectedIndex = 1
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            ComboBox7b.Enabled = True : TextBox6b.Enabled = True
            ComboBox7b.SelectedIndex = -1 : TextBox6b.Text = ""
            ComboBox2.Enabled = True : ComboBox5.Enabled = True : ComboBox6.Enabled = True
            ComboBox2.SelectedIndex = 0 : ComboBox5.SelectedIndex = 0 : ComboBox6.SelectedIndex = 1
        Else
            ComboBox7b.Enabled = False : TextBox6b.Enabled = False
            ComboBox7b.SelectedIndex = -1 : TextBox6b.Text = ""
            ComboBox2.Enabled = False : ComboBox5.Enabled = False : ComboBox6.Enabled = False
            ComboBox2.SelectedIndex = 0 : ComboBox5.SelectedIndex = 0 : ComboBox6.SelectedIndex = 1
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        carib("T", "Y", "T")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        carib("Y", "Y", "T")
    End Sub

    Private Sub ComboBox1_KeyPress1(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox1.KeyPress
        If e.KeyChar = Chr(13) Then ComboBox3.Focus()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 0 Then
            If CheckBox1.Checked = True Then
                ComboBox3.Enabled = True : ComboBox4.Enabled = True
                ComboBox3.SelectedIndex = 1 : ComboBox4.SelectedIndex = 1
            Else
                ComboBox3.Enabled = False : ComboBox4.Enabled = False
                ComboBox3.SelectedIndex = 1 : ComboBox4.SelectedIndex = 1
            End If
        Else
            ComboBox3.Enabled = False : ComboBox4.Enabled = False
            ComboBox3.SelectedIndex = 0 : ComboBox4.SelectedIndex = 0
        End If
    End Sub

    Private Sub ComboBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox2.KeyPress
        If e.KeyChar = Chr(13) Then ComboBox5.Focus()
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.SelectedIndex = 0 Then
            If CheckBox2.Checked = True Then
                ComboBox5.Enabled = True : ComboBox6.Enabled = True
                ComboBox5.SelectedIndex = 1 : ComboBox6.SelectedIndex = 1
            Else
                ComboBox5.Enabled = False : ComboBox6.Enabled = False
                ComboBox5.SelectedIndex = 1 : ComboBox6.SelectedIndex = 1
            End If
        Else
            ComboBox5.Enabled = False : ComboBox6.Enabled = False
            ComboBox5.SelectedIndex = 0 : ComboBox6.SelectedIndex = 0
        End If
    End Sub

    Private Sub ComboBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox3.KeyPress
        If e.KeyChar = Chr(13) Then TextBox7b.Focus()
    End Sub

    Private Sub ComboBox5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox5.KeyPress
        If e.KeyChar = Chr(13) Then TextBox6b.Focus()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        carib("T", "T", "Y")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        carib("Y", "T", "Y")
    End Sub
End Class