﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button

Public Class EMI_Kendaraan_Display
    Dim arrcari As New ArrayList
    Dim Jenis = "ETA"

    Public Property filter_tambahan As String
    Public Property asal As String

    Dim LvKdSupplier, LvNmSupplier, LvNoSJ As String
    Dim LvIdEkspedisi, LvEkspedisi, LvSupir, LvPlatNomor As String
    Dim LvNoTimbangan, LvNoPO, LvNoSJTimbangan, LvTgl, LvJam As String
    Dim LvBruto, LvTglBruto, LvJamBruto, LvFotoBruto1, LvFotoBruto2 As String
    Dim LvMasuk, LvTara, LvTglTara, LvJamTara As String
    Dim LvFotoTara1, LvFotoTara2, LvKeluar, LvNetto, LvLokasi, LvNoLoading, LvProsesLoading As String
    Dim isTimbangMasuk, isTimbangKeluar As String

    ''Dim itemNoFaktur As Integer = 0
    'Dim itemKdSupplier As Integer = 0
    'Dim itemNmSupplier As Integer = 1
    'Dim itemNoSJ As Integer = 2
    'Dim itemIDEkspedisi As Integer = 3
    'Dim itemEkspedisi As Integer = 4
    'Dim itemSupir As Integer = 5
    'Dim itemPlatNomor As Integer = 6
    'Dim ItemNoTimbangan As Integer = 7
    'Dim itemNoPO As Integer = 8
    'Dim itemNoSJTimbangan As Integer = 9
    'Dim itemTgl As Integer = 10
    'Dim itemJam As Integer = 11
    'Dim itemBruto As Integer = 12
    'Dim itemTglBruto As Integer = 13

    'Dim itemJamBruto As Integer = 14
    'Dim itemFotoBruto1 As Integer = 15
    'Dim itemFotoBruto2 As Integer = 16
    'Dim itemMasuk As Integer = 17
    'Dim itemTara As Integer = 18
    'Dim itemTglTara As Integer = 19
    'Dim itemJamTara As Integer = 20
    'Dim itemFotoTara1 As Integer = 21
    'Dim itemFotoTara2 As Integer = 22
    'Dim itemKeluar As Integer = 23
    'Dim itemNetto As Integer = 24
    'Dim itemLokasi As Integer = 25
    'Dim itemNoLoading As Integer = 26
    'Dim itemProsesLoading As Integer = 27

    Dim itemLokasi As Integer = 0
    Dim itemNmSupplier As Integer = 1
    Dim itemNoSJ As Integer = 2
    Dim itemSupir As Integer = 3
    Dim itemPlatNomor As Integer = 4
    Dim itemBruto As Integer = 5
    Dim itemNoLoading As Integer = 6
    Dim itemKdSupplier As Integer = 7
    Dim itemIDEkspedisi As Integer = 8
    Dim itemEkspedisi As Integer = 9
    Dim ItemNoTimbangan As Integer = 10
    Dim itemIsTimbangMasuk As Integer = 11
    Dim itemIsTimbangKeluar As Integer = 12

    Private Sub Btn_Refresh_Click(sender As Object, e As EventArgs) Handles Btn_Refresh.Click
        kosong()
    End Sub

    Private Function CekNothing(ByVal str As String) As String
        Dim hasil As String = ""

        If str Is Nothing Then
            hasil = ""
        Else
            hasil = str
        End If

        Return hasil
    End Function

    Private Sub Get_Isi_ListView(ByVal NoIndex As Integer)
        'LvNoFaktur = Lv_ListKendaraan.Items(NoIndex).Text
        'LvKdSupplier = Lv_ListKendaraan.Items(NoIndex).SubItems(itemKdSupplier).Text
        'LvNmSupplier = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNmSupplier).Text
        'LvNoSJ = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNoSJ).Text
        'LvIdEkspedisi = Lv_ListKendaraan.Items(NoIndex).SubItems(itemIDEkspedisi).Text
        'LvEkspedisi = Lv_ListKendaraan.Items(NoIndex).SubItems(itemEkspedisi).Text
        'LvSupir = Lv_ListKendaraan.Items(NoIndex).SubItems(itemSupir).Text
        'LvPlatNomor = Lv_ListKendaraan.Items(NoIndex).SubItems(itemPlatNomor).Text
        'LvNoTimbangan = Lv_ListKendaraan.Items(NoIndex).SubItems(ItemNoTimbangan).Text
        'LvNoPO = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNoPO).Text
        'LvNoSJTimbangan = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNoSJTimbangan).Text
        'LvTgl = Lv_ListKendaraan.Items(NoIndex).SubItems(itemTgl).Text
        'LvJam = Lv_ListKendaraan.Items(NoIndex).SubItems(itemJam).Text
        'LvBruto = Lv_ListKendaraan.Items(NoIndex).SubItems(itemBruto).Text
        'LvTglBruto = Lv_ListKendaraan.Items(NoIndex).SubItems(itemTglBruto).Text
        'LvJamBruto = Lv_ListKendaraan.Items(NoIndex).SubItems(itemJamBruto).Text
        'LvFotoBruto1 = Lv_ListKendaraan.Items(NoIndex).SubItems(itemFotoBruto1).Text
        'LvFotoBruto2 = Lv_ListKendaraan.Items(NoIndex).SubItems(itemFotoBruto2).Text
        'LvMasuk = Lv_ListKendaraan.Items(NoIndex).SubItems(itemMasuk).Text
        'LvTara = Lv_ListKendaraan.Items(NoIndex).SubItems(itemTara).Text
        'LvTglTara = Lv_ListKendaraan.Items(NoIndex).SubItems(itemTglTara).Text
        'LvJamTara = Lv_ListKendaraan.Items(NoIndex).SubItems(itemJamTara).Text
        'LvFotoTara1 = Lv_ListKendaraan.Items(NoIndex).SubItems(itemFotoTara1).Text
        'LvFotoTara2 = Lv_ListKendaraan.Items(NoIndex).SubItems(itemFotoTara2).Text
        'LvKeluar = Lv_ListKendaraan.Items(NoIndex).SubItems(itemKeluar).Text
        'LvNetto = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNetto).Text
        'LvLokasi = Lv_ListKendaraan.Items(NoIndex).SubItems(itemLokasi).Text
        'LvNoLoading = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNoLoading).Text
        'LvProsesLoading = Lv_ListKendaraan.Items(NoIndex).SubItems(itemProsesLoading).Text

        LvNmSupplier = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNmSupplier).Text
        LvNoSJ = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNoSJ).Text
        LvSupir = Lv_ListKendaraan.Items(NoIndex).SubItems(itemSupir).Text
        LvPlatNomor = Lv_ListKendaraan.Items(NoIndex).SubItems(itemPlatNomor).Text
        LvLokasi = Lv_ListKendaraan.Items(NoIndex).SubItems(itemLokasi).Text
        LvBruto = Lv_ListKendaraan.Items(NoIndex).SubItems(itemBruto).Text
        LvNoLoading = Lv_ListKendaraan.Items(NoIndex).SubItems(itemNoLoading).Text
        LvKdSupplier = Lv_ListKendaraan.Items(NoIndex).SubItems(itemKdSupplier).Text
        LvIdEkspedisi = Lv_ListKendaraan.Items(NoIndex).SubItems(itemKdSupplier).Text
        LvNmSupplier = Lv_ListKendaraan.Items(NoIndex).SubItems(itemEkspedisi).Text
        LvNoTimbangan = Lv_ListKendaraan.Items(NoIndex).SubItems(ItemNoTimbangan).Text
        isTimbangMasuk = Lv_ListKendaraan.Items(NoIndex).SubItems(itemIsTimbangMasuk).Text
        isTimbangKeluar = Lv_ListKendaraan.Items(NoIndex).SubItems(itemIsTimbangKeluar).Text

    End Sub

    Private Sub Popup_Timbang_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")
    End Sub

    Private Sub Popup_Timbang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")

        Try
            OpenConn()

            Base_Language.Get_Languages(Bahasa_Pilihan, "GLOBAL")
            Base_Language.Get_Languages(Bahasa_Pilihan, Jenis)

            Btn_Refresh.Text = Base_Language.Lang_Global_Refresh
            'Label1.Text = Base_Language.Lang_Global_ListKendaraan

            If filter_tambahan = " and a.flag_Timbang is null " Then
                Label1.Text = "Display - Kendaraan Masuk"
            Else
                Label1.Text = "Display - Kendaraan Keluar"
            End If

            Lv_ListKendaraan.Columns.Clear()
            ' Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_NoFaktur, 0, HorizontalAlignment.Left) '0
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Kode_Supplier, 0, HorizontalAlignment.Left) '0
            'Lv_ListKendaraan.Columns.Add(Base_Language.lang_global_Nama_Supplier, 150, HorizontalAlignment.Left) '1
            'Lv_ListKendaraan.Columns.Add("No. SJ", 100, HorizontalAlignment.Left) '2
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Ekspedisi, 0, HorizontalAlignment.Left) '3
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Ekspedisi, 0, HorizontalAlignment.Left) '4
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Supir, 100, HorizontalAlignment.Left) '5
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_PlatNomor, 100, HorizontalAlignment.Left) '6
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_NoTimbangan, 0, HorizontalAlignment.Left) '7
            'Lv_ListKendaraan.Columns.Add("No. PO", 0, HorizontalAlignment.Left) '8
            'Lv_ListKendaraan.Columns.Add("No. SJ" + " " + Base_Language.Lang_Global_Timbangan, 0, HorizontalAlignment.Left) '9
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Tanggal, 0, HorizontalAlignment.Left) '10
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Jam, 0, HorizontalAlignment.Left) '11
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Bruto, 0, HorizontalAlignment.Left) '12
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_TglBruto, 0, HorizontalAlignment.Left) '13
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_JamBruto, 0, HorizontalAlignment.Left) '14
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_FotoBruto + "1", 0, HorizontalAlignment.Left) '15
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_FotoBruto + "2", 0, HorizontalAlignment.Left) '16
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_TimbangMasuk, 0, HorizontalAlignment.Left) '17
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Tara, 0, HorizontalAlignment.Left) '18
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_TglTara, 0, HorizontalAlignment.Left) '19
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_JamTara, 0, HorizontalAlignment.Left) '20
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_FotoTara + "1", 0, HorizontalAlignment.Left) '21
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_FotoTara + "2", 0, HorizontalAlignment.Left) '22
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_TimbangKeluar, 0, HorizontalAlignment.Left) '23
            'Lv_ListKendaraan.Columns.Add("Netto", 0, HorizontalAlignment.Left) '24
            'Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Lokasi, 120, HorizontalAlignment.Left).DisplayIndex = 0 '25
            'Lv_ListKendaraan.Columns.Add("No Loading", 0, HorizontalAlignment.Left) '26

            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Lokasi, 200, HorizontalAlignment.Left).DisplayIndex = 0 '0
            Lv_ListKendaraan.Columns.Add(Base_Language.lang_global_Nama_Supplier, 250, HorizontalAlignment.Left) '1
            Lv_ListKendaraan.Columns.Add("No. SJ", 200, HorizontalAlignment.Left) '2
            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Supir, 150, HorizontalAlignment.Left) '3
            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_PlatNomor, 150, HorizontalAlignment.Left) '4

            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Bruto, 0, HorizontalAlignment.Left) '5
            Lv_ListKendaraan.Columns.Add("No Loading", 0, HorizontalAlignment.Left) '6
            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Kode_Supplier, 0, HorizontalAlignment.Left) '7
            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Ekspedisi, 0, HorizontalAlignment.Left) '8
            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_Ekspedisi, 0, HorizontalAlignment.Left) '9
            Lv_ListKendaraan.Columns.Add(Base_Language.Lang_Global_NoTimbangan, 0, HorizontalAlignment.Left) '10
            Lv_ListKendaraan.Columns.Add("isTimbangMasuk", 0, HorizontalAlignment.Left) '10
            Lv_ListKendaraan.Columns.Add("isTimbangKeluar", 0, HorizontalAlignment.Left) '10

            Lv_ListKendaraan.View = View.Details

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

        kosong()
    End Sub

    Public Sub kosong()
        Get_Timbangan_Unloading()
    End Sub

    Private Sub Get_Timbangan_Unloading()
        Try
            OpenConn()

            Lv_ListKendaraan.Items.Clear()
            Lv_ListKendaraan.View = View.Details


            SQL = ";with cte as( SELECT a.lokasi, a.Kode_Supplier, b.Nama, a.No_SJ, a.ETA, a.Id_Ekspedisi, a.driver AS Supir, "
            SQL = SQL & "a.no_plat AS Plat_Number,a.flag_proses_loading, a.No_faktur AS no_loading, a.ID_Jenis_Muatan, c.Nama_Ekspedisi, "

            SQL = SQL & "isnull((select top(1) 'Y' from EMI_Pembelian_Loading_detail x where x.no_faktur=a.no_faktur and "
            SQL = SQL & "x.flag_timbang_masuk is null and a.Flag_Proses_loading is null ORDER BY x.no_faktur),'-') as Timbang_Masuk, "
            SQL = SQL & "isnull((select top(1) 'Y' from EMI_Pembelian_Loading_detail x where x.no_faktur=a.no_faktur and "
            SQL = SQL & "x.flag_sudah_bongkar_android is null and x.flag_timbang_masuk='Y' and a.Flag_Proses_Loading is null ORDER BY x.no_faktur),'-') as Unloading, "
            SQL = SQL & "isnull((select top(1) 'Y' from EMI_Pembelian_Loading_detail x where x.no_faktur=a.no_faktur and "
            SQL = SQL & "x.flag_sudah_bongkar_android ='Y' and a.Flag_timbang_keluar is null and a.Flag_Proses_Loading='Y' ORDER BY x.no_faktur),'-') as Timbang_Keluar, "

            SQL = SQL & "isnull((select top(1) bruto from emi_timbang_unloading x where x.no_loading=a.no_faktur and "
            SQL = SQL & "x.flag_selesai is null ORDER BY x.no_loading),0) as Bruto, "
            SQL = SQL & "isnull((select top(1) No_Faktur from emi_timbang_unloading x where x.no_loading=a.no_faktur and "
            SQL = SQL & "x.flag_selesai is null ORDER BY x.no_loading),'-') as No_Timbangan "
            SQL = SQL & "FROM EMI_Pembelian_Loading a, Suppliers b, EMI_Master_Ekspedisi c WHERE "
            SQL = SQL & "a.Kode_Perusahaan = b.Kode_Perusahaan AND a.Kode_Supplier = b.Kode_Supplier "
            SQL = SQL & "and a.Id_Ekspedisi=c.Id_Ekspedisi and  a.Kode_Perusahaan = '" & KodePerusahaan & "' AND a.Status IS NULL) "
            SQL = SQL & "select * from cte "
            SQL = SQL & "where " & filter_tambahan & " "
            SQL = SQL & "ORDER BY ETA DESC; "

            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    Dim Lvw As ListViewItem
                    Lvw = Lv_ListKendaraan.Items.Add(dr("lokasi"))
                    Lvw.SubItems.Add(dr("Nama"))
                    Lvw.SubItems.Add(dr("No_SJ"))
                    Lvw.SubItems.Add(dr("Supir"))
                    Lvw.SubItems.Add(dr("Plat_Number"))
                    If General_Class.CekNULL(dr("Bruto")) = "0" Then
                        Lvw.SubItems.Add("-")
                    Else
                        Lvw.SubItems.Add(Format(dr("Bruto"), "N0"))
                    End If
                    Lvw.SubItems.Add(dr("no_loading"))
                    Lvw.SubItems.Add(dr("Kode_Supplier"))
                    Lvw.SubItems.Add(dr("Id_Ekspedisi"))
                    Lvw.SubItems.Add(dr("Nama_Ekspedisi"))
                    If General_Class.CekNULL(dr("No_Timbangan")) = "" Then
                        Lvw.SubItems.Add("-")
                    Else
                        Lvw.SubItems.Add(dr("No_Timbangan"))
                    End If
                    Lvw.SubItems.Add(dr("Timbang_Masuk"))
                    Lvw.SubItems.Add(dr("Timbang_Keluar"))

                    '''Lvw = Lv_ListKendaraan.Items.Add(dr("No_Faktur"))
                    'Lvw = Lv_ListKendaraan.Items.Add(dr("Kode_Supplier"))
                    'Lvw.SubItems.Add(dr("Nama"))
                    'Lvw.SubItems.Add(dr("No_SJ"))
                    'Lvw.SubItems.Add(dr("Id_Ekspedisi"))
                    'Lvw.SubItems.Add(dr("Kode_Ekspedisi"))
                    'Lvw.SubItems.Add(dr("Supir"))
                    'Lvw.SubItems.Add(dr("Plat_Number"))

                    '''Handle NULL
                    'If General_Class.CekNULL(dr("No_Timbangan")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("No_Timbangan"))
                    'End If

                    'Lvw.SubItems.Add("")
                    'Lvw.SubItems.Add("")

                    'If General_Class.CekNULL(dr("Tanggal")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Tanggal"), "dd MMM yyyy"))
                    'End If
                    'If General_Class.CekNULL(dr("Jam")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("Jam"))
                    'End If
                    'If General_Class.CekNULL(dr("Bruto")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Bruto"), "N0"))
                    'End If
                    'If General_Class.CekNULL(dr("Tgl_Bruto")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Tgl_Bruto"), "dd MMM yyyy"))
                    'End If
                    'If General_Class.CekNULL(dr("Jam_Bruto")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("Jam_Bruto"))
                    'End If
                    'If General_Class.CekNULL(dr("Foto_Bruto_1")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("Foto_Bruto_1"))
                    'End If
                    'If General_Class.CekNULL(dr("Foto_Bruto_2")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("Foto_Bruto_2"))
                    'End If
                    'If General_Class.CekNULL(dr("Timbang_Masuk")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Timbang_Masuk"), "N0"))
                    'End If
                    'If General_Class.CekNULL(dr("Tara")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Tara"), "N0"))
                    'End If
                    'If General_Class.CekNULL(dr("Tgl_Tara")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Tgl_Tara"), "dd MMM yyyy"))
                    'End If
                    'If General_Class.CekNULL(dr("Jam_Tara")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("Jam_Tara"))
                    'End If
                    'If General_Class.CekNULL(dr("Foto_Tara_1")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("Foto_Tara_1"))
                    'End If
                    'If General_Class.CekNULL(dr("Foto_Tara_2")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(dr("Foto_Tara_2"))
                    'End If
                    'If General_Class.CekNULL(dr("Timbang_Keluar")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Timbang_Keluar"), "N0"))
                    'End If
                    'If General_Class.CekNULL(dr("Netto")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("Netto"), "N0"))
                    'End If
                    'Lvw.SubItems.Add(dr("Lokasi"))
                    'Lvw.SubItems.Add(dr("no_loading"))
                    'If General_Class.CekNULL(dr("flag_proses_loading")) = "" Then
                    '    Lvw.SubItems.Add("-")
                    'Else
                    '    Lvw.SubItems.Add(Format(dr("flag_proses_loading")))
                    'End If
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub ListView2_DoubleClick(sender As Object, e As EventArgs) Handles Lv_ListKendaraan.DoubleClick


        Get_Isi_ListView(Lv_ListKendaraan.FocusedItem.Index)

        If asal = "Unloading_Barang" Then
            EMI_Timbang_Unloading.kosong()
            If LvBruto = "-" Or isTimbangMasuk = "Y" Then
                EMI_Timbang_Unloading.LblNo_Loading.Text = LvNoLoading
                EMI_Timbang_Unloading.Lbl_KodeSupplier.Text = LvKdSupplier
                EMI_Timbang_Unloading.Lbl_NamaSupplier.Text = LvNmSupplier
                EMI_Timbang_Unloading.Txt_Supplier.Text = LvKdSupplier + "(" + LvNmSupplier + ")"
                EMI_Timbang_Unloading.Lbl_IDEkspedisi.Text = LvIdEkspedisi
                EMI_Timbang_Unloading.Lbl_NmEkspedisi.Text = LvEkspedisi
                EMI_Timbang_Unloading.Lbl_NoSJ.Text = LvNoSJ
                'EMI_Timbang_Unloading.Txt_Ekspedisi.Text = LvEkspedisi
                EMI_Timbang_Unloading.Txt_Ekspedisi = LvEkspedisi
                EMI_Timbang_Unloading.Txt_Supir.Text = LvSupir
                EMI_Timbang_Unloading.Txt_PlatNomor.Text = LvPlatNomor
                ' EMI_Timbang_Unloading.Get_Timbang_Masuk()


                'EMI_Timbang_Unloading.Lbl_WaktuTimbangBruto.Visible = True
                'EMI_Timbang_Unloading.DTP_Bruto.Visible = True
                'EMI_Timbang_Unloading.Lbl_Timbang1.Visible = True
                'EMI_Timbang_Unloading.Txt_Timbang1.Visible = True
                'EMI_Timbang_Unloading.Txt_Timbang1.Enabled = True
                'EMI_Timbang_Unloading.Label21.Visible = True
                'EMI_Timbang_Unloading.Lbl_Bruto.Location = New Point(15, 307)
                'EMI_Timbang_Unloading.Txt_Bruto.Location = New Point(130, 307)
                'EMI_Timbang_Unloading.Label21.Location = New Point(274, 307)

                'EMI_Timbang_Unloading.Lbl_Timbang2.Visible = False
                'EMI_Timbang_Unloading.Lbl_Netto.Visible = False
                'EMI_Timbang_Unloading.Txt_Timbang2.Visible = False
                ' EMI_Timbang_Unloading.Txt_Timbang2.Enabled = False
                'EMI_Timbang_Unloading.Txt_Netto.Visible = False
                'EMI_Timbang_Unloading.Label8.Visible = False
                'EMI_Timbang_Unloading.Label23.Visible = False
                ' EMI_Timbang_Unloading.Lbl_WaktuTimbangTara.Visible = False
                'EMI_Timbang_Unloading.DTP_Tara.Visible = False

                EMI_Timbang_Unloading.filterDetailBarang = "and b.Flag_Timbang_Masuk is null and b.Flag_Sudah_Bongkar_Android is null and b.Flag_Timbang_Keluar is null"
                EMI_Timbang_Unloading.Get_DGV()
                EMI_Timbang_Unloading.Btn_Simpan.Tag = "&SimpanBruto"
                EMI_Timbang_Unloading.Btn_Simpan.Text = "&Simpan Bruto"

            Else
                EMI_Timbang_Unloading.LblNo_Loading.Text = LvNoLoading
                EMI_Timbang_Unloading.Txt_NoFaktur.Text = LvNoTimbangan
                'EMI_Timbang_Unloading.Txt_Ekspedisi.Text = LvEkspedisi
                EMI_Timbang_Unloading.Txt_Ekspedisi = LvEkspedisi
                EMI_Timbang_Unloading.Lbl_KodeSupplier.Text = LvKdSupplier
                EMI_Timbang_Unloading.Lbl_NamaSupplier.Text = LvNmSupplier
                EMI_Timbang_Unloading.Txt_Supplier.Text = LvKdSupplier + "(" + LvNmSupplier + ")"
                EMI_Timbang_Unloading.Txt_Supir.Text = LvSupir
                EMI_Timbang_Unloading.Txt_PlatNomor.Text = LvPlatNomor
                EMI_Timbang_Unloading.Txt_Timbang1.Text = LvBruto
                EMI_Timbang_Unloading.Lbl_NoSJ.Text = LvNoSJ
                EMI_Timbang_Unloading.ListView2.CheckBoxes = False

                'EMI_Timbang_Unloading.Lbl_WaktuTimbangBruto.Visible = True
                ' EMI_Timbang_Unloading.DTP_Bruto.Visible = True
                'EMI_Timbang_Unloading.Lbl_Timbang1.Visible = True
                'EMI_Timbang_Unloading.Txt_Timbang1.Visible = True
                'EMI_Timbang_Unloading.Txt_Timbang1.Enabled = True
                'EMI_Timbang_Unloading.Label21.Visible = True

                ' EMI_Timbang_Unloading.Lbl_Timbang2.Visible = True
                ' EMI_Timbang_Unloading.Lbl_Netto.Visible = True
                ' EMI_Timbang_Unloading.Txt_Timbang2.Visible = True
                '  EMI_Timbang_Unloading.Txt_Timbang2.Enabled = True
                '  EMI_Timbang_Unloading.Txt_Netto.Visible = True
                ' EMI_Timbang_Unloading.Label8.Visible = True
                ' EMI_Timbang_Unloading.Label23.Visible = True
                ' EMI_Timbang_Unloading.Lbl_WaktuTimbangTara.Visible = True
                '  EMI_Timbang_Unloading.DTP_Tara.Visible = True
                ' EMI_Timbang_Unloading.Lbl_Tara.Location = New Point(15, 307)
                'EMI_Timbang_Unloading.Txt_Tara.Location = New Point(130, 307)
                'EMI_Timbang_Unloading.Label8.Location = New Point(274, 307)


                ' EMI_Timbang_Unloading.Get_Timbang_Keluar()
                EMI_Timbang_Unloading.filterDetailBarang = "and b.flag_timbang_masuk='Y' and b.Flag_Sudah_Bongkar_Android='Y'"
                EMI_Timbang_Unloading.Get_DGV()
                ' EMI_Timbang_Unloading.Hitung_Netto()
                EMI_Timbang_Unloading.Btn_Simpan.Tag = "&SimpanTara"
                EMI_Timbang_Unloading.Btn_Simpan.Text = "&Simpan Tara"
                EMI_Timbang_Unloading.DataGridView1.Columns(4).Visible = True
            End If

            EMI_Timbang_Unloading.ShowDialog()
        ElseIf asal = "QC_BAHAN" Then
            'EMI_QC_Bahan.TxtNoLoading.Text = LvNoLoading
            'EMI_QC_Bahan.txtNoSJ.Text = LvNoSJ
            'EMI_QC_Bahan.txtNomorPlat.Text = LvPlatNomor
            'EMI_QC_Bahan.ShowDialog()

        ElseIf asal = "Barang_Masuk" Then
            'Emi_Barang_Masuk.kosong()


            'Emi_Barang_Masuk.txtKodeSupp.Text = LvKdSupplier
            'Emi_Barang_Masuk.TxtBarangMasuk_NmSupplier.Text = LvNmSupplier
            'Emi_Barang_Masuk.TxtBarangMasuk_NoPO.Text = ""

            'Dim gudang As String = ""
            'Try
            '    OpenConn()
            '    SQL = "select Kode_Stock_Owner_gudang from Binding_Lokasi_Gudang where kode_perusahaan = '" & KodePerusahaan & "' and Gudang_Default = 'Y' and Kode_Stock_Owner='" & LvLokasi & "' "
            '    Using dr = OpenTrans(SQL)
            '        If dr.Read Then
            '            gudang = dr("Kode_Stock_Owner_gudang")
            '        Else
            '            dr.Close()
            '            CloseConn()
            '            MessageBox.Show(Base_Language.lang_global_Error_LokasiTidakAda, Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            '            Exit Sub
            '        End If
            '    End Using

            '    CloseConn()
            'Catch ex As Exception
            '    CloseConn()
            '    MessageBox.Show(ex.Message)
            '    Exit Sub
            'End Try

            'Emi_Barang_Masuk.txtBarangMasuk_LokasiGudang.Text = gudang
            'Emi_Barang_Masuk.CmbBarangMasuk_Lokasi.Text = LvLokasi
            'Emi_Barang_Masuk.TxtBarang_Masuk_NoNota.Text = LvNoSJ
            'Emi_Barang_Masuk.TxtBarangMasuk_NoPlat.Text = LvPlatNomor

            'Emi_Barang_Masuk.TxtBarang_Masuk_NoNota.Focus()
            'Emi_Barang_Masuk.LvBarangMasuk_DataPO.Items.Clear()

            'Emi_Barang_Masuk.TxtBarangMasuk_KdBarang.Clear()
            'Emi_Barang_Masuk.TxtBarangMasuk_NmBarang.Clear()
            'Emi_Barang_Masuk.TxtBarangMasuk_Jml.Clear()

            'Emi_Barang_Masuk.ShowDialog()
        Else
            MessageBox.Show(Base_Language.Lang_Global_FormAsal & " . .!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If

    End Sub

End Class