﻿Imports System.Globalization

Public Class EMI_Request_Material_General

    Dim judulForm As String = "Request Material General"
    Dim lv As New ListViewItem
    Dim LInisial As New ArrayList
    Dim LSOReq, LSOSup As New ArrayList
    Public isError As String
    Dim total_hpp_metode_B As Double
    Dim fId_group As String

    Dim LvKodeBarang, LvNamaBarang, LvJumlah, LvSatuan, LvKet As String

    'Dim item_Lokasi As Integer = 0
    Dim item_KdBarang As Integer = 0
    Dim item_NamaBarang As Integer = 1
    Dim item_Jumlah As Integer = 2
    Dim item_Satuan As Integer = 3
    Dim item_Keterangan As Integer = 4

    Private Sub Pengeluaran_Barang_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")

        CmbSO_Req.Focus()
    End Sub

    Private Sub Pengeluaran_Barang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim x As New Point(17, 243)
        LvBrg.Location = x

        Kosong()
        CmbSO_Req.Focus()
    End Sub

    Private Sub Kosong()

        LvBarang.Columns.Clear() : LvBarang.Items.Clear()
        'LvBarang.Columns.Add("Lokasi", 160, HorizontalAlignment.Left)
        LvBarang.Columns.Add("Kode Barang", 146, HorizontalAlignment.Left)
        LvBarang.Columns.Add("Nama ", 420, HorizontalAlignment.Left)
        LvBarang.Columns.Add("Jumlah", 200, HorizontalAlignment.Right)
        LvBarang.Columns.Add("Satuan", 100, HorizontalAlignment.Center)
        LvBarang.Columns.Add("Keterangan", 300, HorizontalAlignment.Left)
        LvBarang.View = View.Details

        LvBrg.Columns.Clear() : LvBrg.Items.Clear()
        LvBrg.Columns.Add("Kode Barang", 160, HorizontalAlignment.Left)
        LvBrg.Columns.Add("Nama", 360, HorizontalAlignment.Left)
        LvBrg.Columns.Add("Jumlah Stock", 145, HorizontalAlignment.Left)
        LvBrg.Columns.Add("Satuan", 68, HorizontalAlignment.Left)
        LvBrg.View = View.Details

        get_jam()

        Try
            OpenConn()

            get_no_faktur()

            CmbSO_Req.Enabled = True
            CmbSo_Sup.Enabled = True
            TxtJlh.Enabled = False
            TxtKet.Enabled = False

            Txt_Ket.Text = ""
            TxtKodeBarang.Text = "" : TxtNamaBarang.Text = "" : Txt_Stock.Text = "0" : TxtSatuan.Text = "" : TxtKet.Text = "" : TxtTotal.Text = "" : Txt_Stock.Text = ""

            CmbSO_Req.Items.Clear() : LSOReq.Clear() : CmbSo_Sup.Items.Clear() : LSOSup.Clear()
            SQL = "Select kode_stock_owner, keterangan from stock_owner_gudang order by kode_stock_owner"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    CmbSO_Req.Items.Add(dr("keterangan")) : LSOReq.Add(dr("kode_stock_owner"))
                    CmbSo_Sup.Items.Add(dr("keterangan")) : LSOSup.Add(dr("kode_stock_owner"))
                Loop
            End Using

            LvBarang.Items.Clear()
            HitungTotal()

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub get_no_faktur()
        Dim FRM As String = "RMG"

        TxtNoFaktur.Text = FRM & Format(tgl_skg, "MMyy") & "-" &
                             General_Class.Get_Last_Number2("Emi_Material_Requisition_General", "No_Faktur", 5,
                             "Kode_perusahaan", KodePerusahaan,
                             "And", "substring(No_Faktur, 1, " & Len(FRM) + 4 & ")", FRM & Format(tgl_skg, "MMyy"))
    End Sub

    Private Sub Get_Isi_Listview(ByVal i As Integer)
        LvKodeBarang = LvBarang.Items(i).SubItems(item_KdBarang).Text
        LvNamaBarang = LvBarang.Items(i).SubItems(item_NamaBarang).Text
        LvJumlah = LvBarang.Items(i).SubItems(item_Jumlah).Text
        LvSatuan = LvBarang.Items(i).SubItems(item_Satuan).Text
        LvKet = LvBarang.Items(i).SubItems(item_Keterangan).Text
    End Sub

    Private Sub TxtKodeBarang_TextChanged(sender As Object, e As EventArgs) Handles TxtKodeBarang.TextChanged
        If CmbSO_Req.SelectedIndex = -1 Then
            MessageBox.Show("Pilih Dahulu Gudang Request", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSO_Req.Focus() : Exit Sub
        ElseIf CmbSo_Sup.SelectedIndex = -1 Then
            MessageBox.Show("Pilih Dahulu Gudang Supply", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSo_Sup.Focus() : Exit Sub
        End If

        If TxtKodeBarang.Text.Trim.Length = 0 Then
            LvBrg.Visible = False : Exit Sub
        Else
            LvBrg.Visible = True
        End If

        Try

            OpenConn()

            Dim lv As New ListViewItem
            LvBrg.Items.Clear()

            SQL = "select a.Kode_Stock_Owner, a.Kode_Barang, a.Nama, a.Good_Stock, a.Satuan, "
            SQL = SQL & "dbo.ubah_satuan(a.kode_perusahaan, 'masa',a.kode_barang, a.Satuan, "
            SQL = SQL & "(select top 1 z.Satuan from Barang_Detail_Satuan z where z.Kode_Perusahaan = a.Kode_Perusahaan and z.Kode_barang = a.Kode_Barang and z.Flag_Tampil_Display = 'Y'), "
            SQL = SQL & "a.Good_Stock ) as Good_Stock_Besar,  "
            SQL = SQL & "ISNULL((select top 1 z.Satuan from Barang_Detail_Satuan z where z.Kode_Perusahaan = a.Kode_Perusahaan and z.Kode_barang = a.Kode_Barang and z.Flag_Tampil_Display = 'Y'), '-') as Satuan_Besar "
            SQL = SQL & "from barang a "
            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.kode_stock_owner = '" & LSOSup(CmbSo_Sup.SelectedIndex) & "' "
            SQL = SQL & "and a.Kode_Barang like '%" & TxtKodeBarang.Text.Trim & "%' "
            SQL = SQL & "order by a.nama, a.Good_Stock "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    lv = LvBrg.Items.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Format(Dr("Good_Stock_Besar"), "N2"))
                    lv.SubItems.Add(Dr("Satuan_Besar"))
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub TxtKodeBarang_Leave(sender As Object, e As EventArgs) Handles TxtKodeBarang.Leave
        If CmbSO_Req.SelectedIndex = -1 AndAlso CmbSo_Sup.SelectedIndex = -1 Then Exit Sub

        If TxtKodeBarang.Text.Trim.Length = 0 Then Exit Sub
        If LvBrg.Focused = True Then Exit Sub

        Try
            Cek_Flagging()

            OpenConn()

            SQL = "select a.Kode_Stock_Owner, a.Kode_Barang, a.Nama, a.Good_Stock, a.Satuan, "
            SQL = SQL & "dbo.ubah_satuan(a.kode_perusahaan, 'masa',a.kode_barang, a.Satuan, "
            SQL = SQL & "(select top 1 z.Satuan from Barang_Detail_Satuan z where z.Kode_Perusahaan = a.Kode_Perusahaan and z.Kode_barang = a.Kode_Barang and z.Flag_Tampil_Display = 'Y'), "
            SQL = SQL & "a.Good_Stock ) as Good_Stock_Besar,  "
            SQL = SQL & "ISNULL((select top 1 z.Satuan from Barang_Detail_Satuan z where z.Kode_Perusahaan = a.Kode_Perusahaan and z.Kode_barang = a.Kode_Barang and z.Flag_Tampil_Display = 'Y'), '-') as Satuan_Besar "
            SQL = SQL & "from barang a "
            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.kode_stock_owner = '" & LSOSup(CmbSo_Sup.SelectedIndex) & "' "
            SQL = SQL & "and a.Kode_Barang = '" & TxtKodeBarang.Text.Trim & "' "
            SQL = SQL & "order by a.nama, a.Good_Stock "
            Using Dr = OpenTrans(SQL)
                If Dr.Read Then
                    TxtKodeBarang.Text = Dr("Kode_Barang")
                    TxtNamaBarang.Text = Dr("Nama")
                    Txt_Stock.Text = Format(Dr("Good_Stock_Besar"), "N2")
                    TxtSatuan.Text = Dr("Satuan_Besar")
                    TxtJlh.Focus()
                Else
                    MessageBox.Show("Kode barang tidak ditemukan . . ! !", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    TxtKodeBarang.Text = "" : TxtNamaBarang.Text = "" : TxtSatuan.Text = ""
                    Txt_Stock.Text = "" : TxtKet.Text = "" : TxtJlh.Text = ""
                    TxtKodeBarang.Focus()
                End If
                LvBrg.Visible = False
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub TxtKodeBarang_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtKodeBarang.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtKodeBarang.Text.Trim.Length = 0 Then TxtNamaBarang.Focus()
            TxtKodeBarang_Leave(TxtKodeBarang, e)
            LvBrg.Visible = False
        End If
    End Sub

    Private Sub TxtKodeBarang_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtKodeBarang.KeyDown
        If e.KeyCode = Keys.Down Then LvBrg.Focus()
    End Sub

    Private Sub TxtNamaBarang_TextChanged(sender As Object, e As EventArgs) Handles TxtNamaBarang.TextChanged
        If CmbSO_Req.SelectedIndex = -1 Then
            MessageBox.Show("Pilih Dahulu Gudang Request", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSO_Req.Focus() : Exit Sub
        ElseIf CmbSo_Sup.SelectedIndex = -1 Then
            MessageBox.Show("Pilih Dahulu Gudang Supply", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSo_Sup.Focus() : Exit Sub
        End If
        If TxtNamaBarang.Text.Trim.Length = 0 Then
            LvBrg.Visible = False : Exit Sub
        Else
            LvBrg.Visible = True
        End If

        Try
            Cek_Flagging()

            OpenConn()

            Dim lv As New ListViewItem
            LvBrg.Items.Clear()

            SQL = "select a.Kode_Stock_Owner, a.Kode_Barang, a.Nama, a.Good_Stock, a.Satuan, "
            SQL = SQL & "dbo.ubah_satuan(a.kode_perusahaan, 'masa',a.kode_barang, a.Satuan, "
            SQL = SQL & "(select top 1 z.Satuan from Barang_Detail_Satuan z where z.Kode_Perusahaan = a.Kode_Perusahaan and z.Kode_barang = a.Kode_Barang and z.Flag_Tampil_Display = 'Y'), "
            SQL = SQL & "a.Good_Stock ) as Good_Stock_Besar,  "
            SQL = SQL & "ISNULL((select top 1 z.Satuan from Barang_Detail_Satuan z where z.Kode_Perusahaan = a.Kode_Perusahaan and z.Kode_barang = a.Kode_Barang and z.Flag_Tampil_Display = 'Y'), '-') as Satuan_Besar "
            SQL = SQL & "from barang a "
            SQL = SQL & "where a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.kode_stock_owner = '" & LSOSup(CmbSo_Sup.SelectedIndex) & "' "
            SQL = SQL & "and a.nama like '%" & TxtNamaBarang.Text.Trim & "%' "
            SQL = SQL & "order by a.nama, a.Good_Stock "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    lv = LvBrg.Items.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Format(Dr("Good_Stock_Besar"), "N2"))
                    lv.SubItems.Add(Dr("Satuan_Besar"))
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub TxtNamaBarang_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNamaBarang.KeyPress
        If e.KeyChar = Chr(13) Then
            TxtKodeBarang_Leave(TxtNamaBarang, e)
            LvBrg.Visible = False
        End If
    End Sub

    Private Sub TxtNamaBarang_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtNamaBarang.KeyDown
        If e.KeyCode = Keys.Down Then LvBrg.Focus()
    End Sub

    Private Sub LvBrg_DoubleClick(sender As Object, e As EventArgs) Handles LvBrg.DoubleClick
        Dim KodeSO As String = LvBrg.FocusedItem.Text
        Dim Kode As String = LvBrg.FocusedItem.SubItems(0).Text

        TxtKodeBarang.Text = Kode

        CmbSO_Req.Enabled = False
        CmbSo_Sup.Enabled = False

        LvBrg.Visible = False
        TxtKodeBarang_Leave(LvBrg, e)
        Txt_Stock.Focus()

        TxtJlh.Enabled = True
        TxtKet.Enabled = True
    End Sub

    Private Sub LvBrg_KeyDown(sender As Object, e As KeyEventArgs) Handles LvBrg.KeyDown
        If e.KeyCode = Keys.Enter Then
            LvBrg_DoubleClick(LvBrg, e)
        End If
    End Sub

    Private Sub TxtJlh_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txt_Stock.KeyPress, TxtJlh.KeyPress
        If e.KeyChar = Chr(13) Then TxtKet.Focus()
        If Not (e.KeyChar >= "0"c And e.KeyChar <= "9"c Or e.KeyChar = Chr(8) Or e.KeyChar = "."c) Then e.KeyChar = Chr(0)
    End Sub

    Private Sub TxtKet_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtKet.KeyPress
        If e.KeyChar = Chr(13) Then BtnOK.Focus()
    End Sub

    Private Sub TxtJlh_Leave(sender As Object, e As EventArgs) Handles TxtJlh.Leave
        ''======================
        ''=     SET FORMAT     =
        ''======================
        Dim culture As CultureInfo = CultureInfo.CurrentCulture

        If Not TxtJlh.Text.Trim.Length = 0 Then
            Dim cellKuantity As String = TxtJlh.Text

            If cellKuantity = "" Then
                Exit Sub
            End If

            Dim nilai As Decimal = Decimal.Parse(cellKuantity)
            Dim formattedValue As String = nilai.ToString("N2", culture)

            TxtJlh.Text = formattedValue

        End If
    End Sub

    Private Sub TxtJlh_Enter(sender As Object, e As EventArgs) Handles TxtJlh.Enter
        '======================
        '=     SET FORMAT     =
        '======================

        If Not TxtJlh.Text.Trim.Length = 0 Then
            Dim cellKuantity As String = TxtJlh.Text

            If cellKuantity = "" Then
                Exit Sub
            End If

            Dim cleanedStr As String = HilangkanTanda(cellKuantity) ' Menghapus titik
            Dim nilai As Decimal = Decimal.Parse(cleanedStr)

            TxtJlh.Text = nilai
        End If
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        TxtKodeBarang.Text = "" : TxtNamaBarang.Text = "" : Txt_Stock.Text = "0" : TxtSatuan.Text = "" : TxtKet.Text = ""
    End Sub

    Private Sub BtnRefresh_Click(sender As Object, e As EventArgs) Handles BtnRefresh.Click
        Kosong()
        CmbSO_Req.Focus()
    End Sub

    Private Sub BtnOK_Click(sender As Object, e As EventArgs) Handles BtnOK.Click
        If CmbSO_Req.Text.Trim.Length = 0 Then
            MessageBox.Show("lokasi Request harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSO_Req.Focus() : Exit Sub
        ElseIf CmbSo_Sup.Text.Trim.Length = 0 Then
            MessageBox.Show("lokasi Supply harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSo_Sup.Focus() : Exit Sub
        ElseIf TxtKodeBarang.Text.Trim.Length = 0 Then
            MessageBox.Show("Kode barang harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TxtKodeBarang.Focus() : Exit Sub
        ElseIf TxtNamaBarang.Text.Trim.Length = 0 Then
            MessageBox.Show("Nama barang harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TxtNamaBarang.Focus() : Exit Sub
        ElseIf TxtJlh.Text.Trim.Length = 0 Then
            MessageBox.Show("Jumlah barang harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TxtJlh.Focus() : Exit Sub
        ElseIf TxtSatuan.Text.Trim.Length = 0 Then
            MessageBox.Show("Satun barang harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TxtSatuan.Focus() : Exit Sub
        ElseIf TxtKet.Text.Trim.Length = 0 Then
            MessageBox.Show("Keterangan barang harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TxtKet.Focus() : Exit Sub
        End If

        For i As Integer = 0 To LvBarang.Items.Count - 1
            If TxtKodeBarang.Text.Trim.ToUpper = LvBarang.Items(i).SubItems(item_KdBarang).Text Then
                MessageBox.Show("Kode barang sudah anda masukkan!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TxtKodeBarang.Focus() : Exit Sub
            End If
        Next

        If Val(HilangkanTanda(TxtJlh.Text)) > Val(HilangkanTanda(Txt_Stock.Text)) Then
            MessageBox.Show("Jumlah barang tidak boleh melebihi stock!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TxtJlh.Focus() : Exit Sub
        End If

        Dim Lv As ListViewItem
        Lv = LvBarang.Items.Add(TxtKodeBarang.Text)
        Lv.SubItems.Add(TxtNamaBarang.Text.Trim)
        Lv.SubItems.Add(Format(Val(HilangkanTanda(TxtJlh.Text.Trim)), "N2"))
        Lv.SubItems.Add(TxtSatuan.Text.Trim)
        Lv.SubItems.Add(TxtKet.Text.Trim)

        HitungTotal()

        TxtKodeBarang.Text = "" : TxtNamaBarang.Text = "" : Txt_Stock.Text = "" : TxtJlh.Text = "" : TxtSatuan.Text = "" : TxtKet.Text = ""

    End Sub

    Private Sub HitungTotal()
        Dim Total As Integer = 0
        For i As Integer = 0 To LvBarang.Items.Count - 1
            Total += Val(HilangkanTanda(LvBarang.Items(i).SubItems(item_Jumlah).Text))
        Next
        TxtTotal.Text = Format(Total, "N2")
    End Sub

    Private Sub LvBarang_KeyDown(sender As Object, e As KeyEventArgs) Handles LvBarang.KeyDown
        If LvBarang.Items.Count = 0 Or LvBarang.FocusedItem.Index = -1 Then
            Exit Sub
        End If

        Dim currentRow = LvBarang.FocusedItem.Index

        If e.KeyCode = Keys.Delete Then

            Dim Hapus1 As String = MessageBox.Show("Apakah Anda Yakin, Ingin Menghapus Data ?", Base_Language.Lang_Global_Perhatian, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Hapus1 = vbNo Then Exit Sub

            LvBarang.Items.RemoveAt(currentRow)

        End If

        HitungTotal()
    End Sub

    Private Sub CmbSO_Req_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbSO_Req.SelectedIndexChanged
        If CmbSO_Req.Items.Count = 0 Then Exit Sub

        If CmbSO_Req.SelectedIndex = CmbSo_Sup.SelectedIndex Then
            MessageBox.Show("Gudang Request dan Gudang Supply tidak boleh sama!", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSO_Req.SelectedIndex = -1 : CmbSO_Req.Focus() : Exit Sub
        End If
    End Sub

    Private Sub CmbSo_Sup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbSo_Sup.SelectedIndexChanged
        If CmbSo_Sup.Items.Count = 0 Then Exit Sub

        If CmbSo_Sup.SelectedIndex = CmbSO_Req.SelectedIndex Then
            MessageBox.Show("Gudang Request dan Gudang Supply tidak boleh sama!", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbSo_Sup.SelectedIndex = -1 : CmbSo_Sup.Focus() : Exit Sub
        End If
    End Sub

    Private Sub BtnSimpan_Click(sender As Object, e As EventArgs) Handles BtnSimpan.Click
        If LvBarang.Items.Count = 0 Then
            MessageBox.Show("Tidak ada Data yang disimpan!", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            LvBarang.Focus() : Exit Sub
        End If

        get_jam()

        Try
            OpenConn()
            Cmd.Transaction = Cn.BeginTransaction
            get_no_faktur()

            '========================
            '=     INSERT INDUK     =
            '========================
            SQL = "insert into Emi_Material_Requisition_General (Kode_Perusahaan, No_Faktur, Kode_Stock_Owner_Req, Kode_Stock_Owner_Sup, Keterangan, Total, Tanggal, Jam, UserId) values "
            SQL = SQL & "('" & KodePerusahaan & "', '" & TxtNoFaktur.Text.Trim & "', '" & LSOReq(CmbSO_Req.SelectedIndex) & "', '" & LSOSup(CmbSo_Sup.SelectedIndex) & "', "
            SQL = SQL & "'" & Txt_Ket.Text & "', '" & HilangkanTanda(TxtTotal.Text) & "', '" & Format(tgl_skg, "yyyy-MM-dd") & "', "
            SQL = SQL & "'" & Format(tgl_skg, "HH:mm:ss") & "', '" & UserID & "')"
            ExecuteTrans(SQL)

            For i As Integer = 0 To LvBarang.Items.Count - 1

                Get_Isi_Listview(i)



                '============================
                '=     GET SATUAN KECIL     =
                '============================
                Dim SatuanKecil As String = ""
                SQL = "select Satuan from Barang_Detail_Satuan where Kode_Perusahaan = '" & KodePerusahaan & "' "
                SQL = SQL & "and Kode_barang = '" & LvKodeBarang & "' and Flag_Tampil_Display is null"
                Using Dr = OpenTrans(SQL)
                    If Dr.Read Then
                        SatuanKecil = Dr("Satuan")
                    Else
                        Dr.Close()
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("Satuan Kecil Tidak di Temukan", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Exit Sub
                    End If
                End Using

                '===============================
                '=     CONVERT NILAI KECIL     =
                '===============================
                Dim jumlahKecil As Double = 0
                SQL = "select dbo.ubah_satuan('" & KodePerusahaan & "', 'masa','" & LvKodeBarang & "', '" & LvSatuan & "', "
                SQL = SQL & "'" & SatuanKecil & "', '" & HilangkanTanda(LvJumlah) & "' ) as hasil "
                Using Dr = OpenTrans(SQL)
                    If Dr.Read Then
                        jumlahKecil = Decimal.Parse(Dr("hasil"))
                    Else
                        Dr.Close()
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("Gagal Ubah Nilai Kecil", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Exit Sub
                    End If
                End Using

                '=========================
                '=     INSERT DETAIL     =
                '=========================
                SQL = "insert into Emi_Material_Requisition_General_Detail (Kode_Perusahaan, No_Faktur, Kode_Barang, Jumlah, Satuan, Jumlah_Barang, Satuan_Barang, Keterangan) values "
                SQL = SQL & "('" & KodePerusahaan & "', '" & TxtNoFaktur.Text.Trim & "', '" & LvKodeBarang & "', '" & HilangkanTanda(LvJumlah) & "', "
                SQL = SQL & "'" & LvSatuan & "', '" & HilangkanTanda(jumlahKecil) & "', '" & SatuanKecil & "', '" & LvKet & "')"
                ExecuteTrans(SQL)


            Next




            Cmd.Transaction.Commit()
            CloseTrans()
            CloseConn()
            MessageBox.Show("Data Berhasil Disimpan", judulForm, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Kosong()
        Catch ex As Exception
            CloseTrans()
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

End Class