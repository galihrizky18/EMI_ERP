﻿Imports System.Deployment.Internal
Imports System.IO
Imports System.IO.Ports
Imports System.Text
Imports System.Web.UI.WebControls
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button
Imports Azure.Storage.Blobs
Imports Azure.Storage.Blobs.Models
Imports Microsoft.VisualBasic.ApplicationServices
Imports WebEye.Controls.WinForms.StreamPlayerControl
Imports ZXing.QrCode


Public Class EMI_Timbang_Floor_Scale
    Dim arrcari As New ArrayList
    Dim Jenis = "Transaksi_Timbang_Kosong"
    Public Txt_Ekspedisi As String = ""
    Dim Random As New Random()

    Private imageBytes1 As Byte = Nothing
    Private FileSize1 As UInt32
    Private rawData1() As Byte
    Private fs1 As FileStream

    Dim arrIdJenisMuatan, arrMetodeTruckScale As New ArrayList
    Dim arrNamaBarang, arrKodeBarang, arrUrutPO As New ArrayList
    Dim selectedBarang, selectedUrutPO As New ArrayList

    Dim Lv_NoSJ, Lv_NoPO, Lv_NoFaktur, Lv_NoUrut, Lv_JumlahMasuk, Lv_KodeBarang, lv_NamaBarang As String
    Dim idJenisMuatan As String
    Dim jumlahMasuk As Integer
    Dim Netto As Integer
    Dim totalMasuk As Integer

    Dim itemFaktur As Integer = 0
    Dim itemNoUrut As Integer = 1
    Dim itemKodeBarang As Integer = 2
    Dim itemNoSJ As Integer = 3


    Dim itemNoPO As Integer = 4
    Dim itemNamaBarang As Integer = 5
    Dim itemJmlhMasuk As Integer = 6

    Public filterDetailBarang As String = ""

    Private Sub Transaksi_Timbang_Unloading_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")
    End Sub

    Private Sub Transaksi_Timbang_Unloading_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")

        Try
            OpenConn()

            Base_Language.Get_Languages(Bahasa_Pilihan, "GLOBAL")
            Base_Language.Get_Languages(Bahasa_Pilihan, Jenis)



            Btn_Simpan.Text = Base_Language.Lang_Global_Simpan
            Btn_Refresh.Text = Base_Language.Lang_Global_Refresh

            'GroupBox1.text = "Data Timbang"
            lblLokasi.Text = "Lokasi"
            'Lbl_Ekspedisi.Text = Base_Language.Lang_Global_Ekspedisi
            lblBarang.Text = "Nama Barang"

            'lblJumlahEstimasi.Text = "Timbang 1"
            'lblJumlahTimbang.Text = "Timbang 2"



            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub

        End Try
        'kosong()

    End Sub



    Public Sub kosong()
        CmbJenisTimbang.Items.Clear()
        CmbJenisTimbang.Items.Add("BARANG MASUK")
        CmbJenisTimbang.Items.Add("TRANSFER STOCK")

        Txt_Timbangan.Text = "99999"


        txt_lokasi.Text = ""
        txt_barang.Text = ""
        'Txt_Ekspedisi.Text = ""
        Txt_Ekspedisi = ""
        txt_barang.Text = ""

        txt_Jml_Estimasi.Text = ""
        txt_Jumlah_Timbang.Text = ""

        'txt_Jml_Estimasi.Enabled = True
        ' txt_Jumlah_Timbang.Enabled = True

        txt_Jumlah_Timbang.Text = Txt_Timbangan.Text

        Try
            OpenConn()

            CmbSatuan.Items.Clear()
            SQL = "select satuan from emi_satuan where kode_Perusahaan='" & KodePerusahaan & "' "
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    CmbSatuan.Items.Add(dr("satuan"))
                Loop
            End Using

            Dim satuan_timbang As String = ""
            SQL = "select Satuan_Timbang from init where kode_Perusahaan='" & KodePerusahaan & "' "
            Using dr = OpenTrans(SQL)
                If dr.Read Then
                    satuan_timbang = dr("Satuan_Timbang")
                End If
            End Using

            CmbSatuan.Text = satuan_timbang
            CmbSatuan.Enabled = False

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    'Data PO berdasarkan Supplier



    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs)
        If e.KeyChar = Chr(13) Then txt_barang.Focus()
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs)
        If e.KeyChar = Chr(13) Then Btn_Simpan.Focus()
    End Sub

    Private Sub Btn_Refresh_Click(sender As Object, e As EventArgs) Handles Btn_Refresh.Click
        Txt_Timbangan.Text = "99999"
    End Sub



    Private Sub Btn_Simpan_Click(sender As Object, e As EventArgs) Handles Btn_Simpan.Click

        If txt_Jumlah_Timbang.Text.Trim.Length = 0 Then
            MessageBox.Show("Jumlah timbang tidak boleh kosong!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If

        get_jam()

        Try
            OpenConn()

            Cmd.Transaction = Cn.BeginTransaction

            If CmbJenisTimbang.Text.Trim.ToUpper = "BARANG MASUK" Then

                Dim jumlah_masuk_Barang As Double = 0
                Dim Satuan_Barang As String = ""

                SQL = "select distinct Satuan from Barang where "
                SQL = SQL & "Kode_Barang='" & TxtKdBarang.Text & "' and Kode_Perusahaan='" & KodePerusahaan & "' "
                Using dr2 = OpenTrans(SQL)
                    If dr2.Read Then
                        Satuan_Barang = dr2("Satuan")
                    Else
                        dr2.Close()
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("Barang Tidak ditemukan . . ! !")
                        Exit Sub
                    End If
                End Using


                'UBAH KE SATUAN PO
                SQL = "select dbo.Ubah_Satuan('" & KodePerusahaan & "','MASA','" & TxtKdBarang.Text & "',"
                SQL = SQL & "'" & CmbSatuan.Text & "','" & Satuan_Barang & "',"
                SQL = SQL & "" & HilangkanTanda(txt_Jumlah_Timbang.Text) & ") as Hasil "
                Using dr3 = OpenTrans(SQL)
                    If dr3.Read Then
                        If General_Class.CekNULL(dr3("Hasil")) <> "" Then
                            jumlah_masuk_Barang = dr3("Hasil")
                        Else
                            MessageBox.Show("Satuan " & CmbSatuan.Text & " Ke " & Satuan_Barang & " Tidak ditemukan . . !", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Exit Sub
                        End If
                    End If
                End Using

                SQL = "update EMI_Barang_Masuk_Perpallet set  "
                SQL = SQL & "Flag_Timbang = 'Y', "
                SQL = SQL & "jumlah = '" & HilangkanTanda(txt_Jumlah_Timbang.Text) & "', "
                SQL = SQL & "Nilai_Barang = '" & jumlah_masuk_Barang & "', "
                SQL = SQL & "tanggal_Timbang = '" & Format(CDate(tgl_skg), "yyyy-MM-dd") & "', "
                SQL = SQL & "jam_Timbang = '" & Format(CDate(tgl_skg), "HH:mm:ss") & "', "
                SQL = SQL & "user_Timbang = '" & UserID & "' "
                SQL = SQL & "where kode_perusahaan = '" & KodePerusahaan & "' "
                SQL = SQL & "and no_faktur = '" & txtKodeTransfer.Text & "' "
                ExecuteTrans(SQL)

            ElseIf CmbJenisTimbang.Text.Trim.ToUpper = "TRANSFER STOCK" Then

                'HAPUS TABEL SEMENTARA
                SQL = "truncate table Cetak_TransferStock "
                ExecuteTrans(SQL)

                Dim idWarehousTujuan As String = ""
                Dim noPalletTujaun As String = ""
                Dim jumlahBags As String = ""
                Dim SoTujuan As String = ""

                SQL = "select a.Status,b.Selesai,b.Flag_Pot_Stock, b.Id_Wms_Tujuan, b.No_Pallet_Tujuan, b.Jumlah_Bags, a.SO_Tujuan "
                SQL = SQL & "from tf_stock a, Tf_Stock_det b "
                SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Kode_Transfer = b.No_Faktur "
                SQL = SQL & "and a.kode_transfer = '" & txtKodeTransfer.Text & "' "
                Using Dr = OpenTrans(SQL)
                    If Dr.Read Then

                        If General_Class.CekNULL(Dr("status")) <> "" Then
                            Dr.Close()
                            CloseTrans()
                            CloseConn()
                            MessageBox.Show("Proses tidak bisa dilanjutkan, barang sudah dibatalkan!!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Exit Sub
                        ElseIf General_Class.CekNULL(Dr("selesai")) = "Y" Then
                            Dr.Close()
                            CloseTrans()
                            CloseConn()
                            MessageBox.Show("Terjadi kesalahan, barang sudah selesai diproses!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Exit Sub
                        ElseIf General_Class.CekNULL(Dr("flag_pot_stock")) = "Y" Then
                            Dr.Close()
                            CloseTrans()
                            CloseConn()
                            MessageBox.Show("Terjadi kesalahan, barang sudah pernah ditimbang!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Exit Sub
                        End If

                        idWarehousTujuan = isNull(Dr("Id_Wms_Tujuan"))
                        noPalletTujaun = isNull(Dr("No_Pallet_Tujuan"))
                        jumlahBags = isNull(Dr("Jumlah_Bags"))
                        SoTujuan = isNull(Dr("SO_Tujuan"))

                    Else
                        Dr.Close()
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("Data barang tidak ditemukan!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Exit Sub
                    End If
                End Using


                SQL = "update Tf_Stock_det set  "
                SQL = SQL & "Flag_Pot_Stock = 'Y', "
                SQL = SQL & "jumlah_pot_Stock = '" & HilangkanTanda(txt_Jumlah_Timbang.Text) & "', "
                SQL = SQL & "tanggal_pot_stock = '" & Format(CDate(tgl_skg), "yyyy-MM-dd") & "', "
                SQL = SQL & "jam_pot_stock = '" & Format(CDate(tgl_skg), "HH:mm:ss") & "', "
                SQL = SQL & "userid_pot_stock = '" & UserID & "' "
                SQL = SQL & "where kode_perusahaan = '" & KodePerusahaan & "' "
                SQL = SQL & "and no_faktur = '" & txtKodeTransfer.Text & "' "
                ExecuteTrans(SQL)

                '====================================
                '=       CONVERT SATUAN KECIL       =
                '====================================
                Dim nilai_kecildetail As Double = 0
                SQL = "select dbo.ubah_satuan('" & KodePerusahaan & "', 'masa','" & TxtKdBarang.Text & "', '" & CmbSatuan.SelectedItem.ToString & "',"
                SQL = SQL & "'" & Txt_SatuanKecil.Text & "', '" & txt_Jumlah_Timbang.Text.ToString & "' ) as hasil"
                Using Dr1 = OpenTrans(SQL)
                    If Dr1.Read Then
                        If General_Class.CekNULL(Dr1("hasil")) = "" Then
                            Dr1.Close()
                            CloseTrans()
                            CloseConn()
                            MessageBox.Show("data konversi satuan kirim tidak ada ")
                            Exit Sub
                        End If

                        nilai_kecildetail = Dr1("hasil")
                    Else
                        Dr1.Close()
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("data konversi satuan kirim tidak ada ")
                        Exit Sub
                    End If
                End Using

                '============================
                '=       POTONG STOCK       =
                '============================

                'Dim jumlahAkhir As Double = Val(dgv_GoodStock) - Val(dgv_Jumlah)

                SQL = "update barang set Good_Stock= Good_Stock-" & nilai_kecildetail & ", Jumlah_Bags = Jumlah_Bags - " & jumlahBags & " "
                SQL = SQL & "where Kode_Perusahaan='" & KodePerusahaan & "' and Kode_Stock_Owner='" & txt_lokasi.Text & "' "
                SQL = SQL & " and Kode_Barang='" & TxtKdBarang.Text & "'"
                ExecuteTrans(SQL)

                SQL = "update barang_sn set jumlah = jumlah-" & nilai_kecildetail & ", Jumlah_Bags = Jumlah_Bags - " & jumlahBags & " "
                SQL = SQL & "where Kode_Stock_Owner='" & txt_lokasi.Text & "' and Kode_Barang='" & TxtKdBarang.Text & "' "
                SQL = SQL & "and Serial_Number='" & txt_Barang_SN.Text & "'"
                ExecuteTrans(SQL)

                '====================================
                '=       CEK KESESUAIAN STOCK       =
                '====================================
                SQL = "SELECT round(SUM(good_stock),2) AS good_stock, isnull((select round(sum(jumlah),2) from Barang_sn x "
                SQL = SQL & "where a.kode_Barang=x.kode_Barang and a.Kode_Stock_Owner=x.kode_Stock_Owner "
                SQL = SQL & "and a.kode_Perusahaan=x.kode_Perusahaan ),0) as Jumlah_sn, "
                SQL = SQL & "isnull(round(SUM(jumlah_bags), 2), 0) AS jumlah_bags_barang, "
                SQL = SQL & "isnull((select round(sum(Jumlah_Bags), 2) from Barang_sn y "
                SQL = SQL & "where a.kode_Barang=y.kode_Barang and a.Kode_Stock_Owner=y.kode_Stock_Owner and a.kode_Perusahaan=y.kode_Perusahaan ), 0) as jumlah_bags_sn "
                SQL = SQL & "FROM barang a WHERE a.Kode_Stock_Owner = '" & txt_lokasi.Text & "' "
                SQL = SQL & "AND a.Kode_Barang = '" & TxtKdBarang.Text & "' and a.Kode_Perusahaan='" & KodePerusahaan & "' "
                SQL = SQL & "group by a.kode_Barang, a.Kode_Stock_Owner, a.kode_Perusahaan "
                Using Ds = BindingTrans(SQL)
                    With Ds.Tables("MyTable")
                        If .Rows.Count <> 0 Then
                            If .Rows(0).Item("good_stock") <> .Rows(0).Item("Jumlah_sn") Or .Rows(0).Item("jumlah_bags_barang") <> .Rows(0).Item("jumlah_bags_sn") Then
                                CloseTrans()
                                CloseConn()
                                MessageBox.Show("Terjadi Kesalahan . . ! !", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                                Exit Sub
                            End If
                        Else
                            CloseTrans()
                            CloseConn()
                            MessageBox.Show("Data tidak ditemukan . . ! !", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Exit Sub
                        End If
                    End With
                End Using


                '==============================
                '=       INSERT SN BARU       =
                '==============================

                Dim hargaIsn As String = ""
                Dim QrLama As String = ""
                Dim batchLama As String = ""
                Dim namaBarang As String = ""
                Dim expDate As String = ""

                'Ambil Data Lama
                SQL = "select a.Serial_Number, a.Qr_Code, a.Kode_Unik_Berjalan, b.Nama, a.Batch_Number, a.Tgl_Expired "
                SQL = SQL & "from barang_sn a, barang b "
                SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan "
                SQL = SQL & "and a.Kode_Stock_Owner = b.Kode_Stock_Owner "
                SQL = SQL & "and a.Kode_Barang = b.Kode_Barang "
                SQL = SQL & "and a.Kode_Perusahaan='" & KodePerusahaan & "' "
                SQL = SQL & "and a.Kode_Stock_Owner='" & txt_lokasi.Text & "' "
                SQL = SQL & "and a.Kode_Barang ='" & TxtKdBarang.Text & "' "
                SQL = SQL & "and a.Serial_Number='" & txt_Barang_SN.Text & "' "
                Using Dr = OpenTrans(SQL)
                    Do While Dr.Read
                        hargaIsn = Get_Harga_SN(Dr("Serial_Number"))
                        QrLama = General_Class.CekNULL(Dr("Qr_Code"))
                        batchLama = General_Class.CekNULL(Dr("Batch_Number"))
                        namaBarang = General_Class.CekNULL(Dr("Nama"))
                        expDate = General_Class.CekNULL(Dr("Tgl_Expired"))
                    Loop
                End Using

                'GENERATE SN BARU
                Dim str As String = Format(Random.Next(0, 999), "000") & Format(CDate(FMenu.ToolStripStatusLabel3.Text), "HHmmss")
                Dim Kode_Unik As String = str.Substring(0, 5) & "BB" & Chr(64 + str.Substring(6, 1)) & str.Substring(6, Len(str) - 6)
                Dim SN_Baru As String = Kode_Unik & Tanda_SN & "01" & Tanda_SN & hargaIsn & Tanda_SN & "02" & Tanda_SN & Format(DateTime.Now, "yyyy-MM-dd")

                Dim newKodeUnikBerjalan As String = Generate_Random_Kode(10)

                'INSERT BARANG SN BARU  
                SQL = "insert into Barang_SN (Kode_Perusahaan, Kode_Stock_Owner, Kode_Barang, Serial_Number, Jumlah, Warning_Stock, Bad_Stock, Jumlah_Bags, "
                SQL = SQL & "Tgl_Expired, Tgl_Produksi, Stock_PO, Stock_Inquiry, Id_Warehouse, id_Susunan, Qr_Code, Kode_Unik_Berjalan, Kode_Unik_Asal, Nomor_Pallet) "
                SQL = SQL & "select Kode_Perusahaan, '" & SoTujuan & "', Kode_Barang, '" & SN_Baru & "', '" & nilai_kecildetail & "', Warning_Stock, Bad_Stock, Jumlah_Bags, "
                SQL = SQL & "Tgl_Expired, Tgl_Produksi, Stock_PO, Stock_Inquiry, '" & idWarehousTujuan & "', id_Susunan , Qr_Code, '" & newKodeUnikBerjalan & "', Kode_Unik_Asal, '" & noPalletTujaun & "' "
                SQL = SQL & "from Barang_SN "
                SQL = SQL & "where Kode_Perusahaan='" & KodePerusahaan & "' "
                SQL = SQL & "and Kode_Stock_Owner='" & txt_lokasi.Text & "' "
                SQL = SQL & "and Kode_Barang='" & TxtKdBarang.Text & "' "
                SQL = SQL & "and Serial_Number='" & txt_Barang_SN.Text & "' "
                ExecuteTrans(SQL)

                '============================
                '=       TAMBAH STOCK       =
                '============================

                SQL = "update barang set Good_Stock= Good_Stock + " & nilai_kecildetail & ", Jumlah_Bags = Jumlah_Bags + " & jumlahBags & " "
                SQL = SQL & "where Kode_Perusahaan='" & KodePerusahaan & "' and Kode_Stock_Owner='" & SoTujuan & "' "
                SQL = SQL & " and Kode_Barang='" & TxtKdBarang.Text & "'"
                ExecuteTrans(SQL)

                'CEK KESESUAIAN STOCK
                SQL = "SELECT round(SUM(good_stock),2) AS good_stock, isnull((select round(sum(jumlah),2) from Barang_sn x "
                SQL = SQL & "where a.kode_Barang=x.kode_Barang and a.Kode_Stock_Owner=x.kode_Stock_Owner "
                SQL = SQL & "and a.kode_Perusahaan=x.kode_Perusahaan ),0) as Jumlah_sn, "
                SQL = SQL & "isnull(round(SUM(jumlah_bags), 2), 0) AS jumlah_bags_barang, "
                SQL = SQL & "isnull((select round(sum(Jumlah_Bags), 2) from Barang_sn y "
                SQL = SQL & "where a.kode_Barang=y.kode_Barang and a.Kode_Stock_Owner=y.kode_Stock_Owner and a.kode_Perusahaan=y.kode_Perusahaan ), 0) as jumlah_bags_sn "
                SQL = SQL & "FROM barang a WHERE a.Kode_Stock_Owner = '" & SoTujuan & "' "
                SQL = SQL & "AND a.Kode_Barang = '" & TxtKdBarang.Text & "' and a.Kode_Perusahaan='" & KodePerusahaan & "' "
                SQL = SQL & "group by a.kode_Barang, a.Kode_Stock_Owner, a.kode_Perusahaan "
                Using Ds = BindingTrans(SQL)
                    With Ds.Tables("MyTable")
                        If .Rows.Count <> 0 Then
                            If .Rows(0).Item("good_stock") <> .Rows(0).Item("Jumlah_sn") Or .Rows(0).Item("jumlah_bags_barang") <> .Rows(0).Item("jumlah_bags_sn") Then
                                CloseTrans()
                                CloseConn()
                                MessageBox.Show("Terjadi Kesalahan . . ! !", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                                Exit Sub
                            End If
                        Else
                            CloseTrans()
                            CloseConn()
                            MessageBox.Show("Data tidak ditemukan . . ! !", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Exit Sub
                        End If
                    End With
                End Using


                '=====================================
                '=       GENERATE BARCODE BARU       =
                '=====================================

                Dim fullNewQr As String = QrLama & "-" & newKodeUnikBerjalan

                Barcode.Image = Generate_QR(fullNewQr)

                Dim FileToSaveAs1 As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp, "newBarcodeTfStock.jpg")
                If Not (System.IO.File.Exists(FileToSaveAs1)) Then
                    Barcode.Image.Save(FileToSaveAs1, System.Drawing.Imaging.ImageFormat.Jpeg)
                End If

                fs1 = New FileStream(FileToSaveAs1, FileMode.Open, FileAccess.Read)
                FileSize1 = fs1.Length
                rawData1 = New Byte(FileSize1) {}
                fs1.Read(rawData1, 0, FileSize1)
                fs1.Close()
                Cmd.Parameters.Add("@newBarcode", SqlDbType.Image).Value = rawData1


                '===================================
                '=       INSERT BARCODE BARU       =
                '===================================
                SQL = "insert into Cetak_TransferStock (kode_perusahaan, kode_barang, Barcode, Nama, QrUtuh, Qr, Tgl_Expired, batch) values "
                SQL = SQL & "('" & KodePerusahaan & "', '" & TxtKdBarang.Text & "', @newBarcode, '" & namaBarang & "', '" & fullNewQr & "', '" & QrLama & "', "
                SQL = SQL & "'" & expDate & "', '" & batchLama & "') "
                ExecuteTrans(SQL)


                Cmd.Transaction.Commit()
                CloseTrans()
                CloseConn()
                MessageBox.Show(Base_Language.Lang_Global_Sukses_Simpan, Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)


                Try
                    OpenConn()
                    Dim CrDoc As New Object

                    SQL = "select Kode_Perusahaan from Cetak_TransferStock where Kode_Perusahaan='" & KodePerusahaan & "' and Kode_Barang='" & TxtKdBarang.Text & "'"
                    Using Ds = BindingTrans(SQL)
                        If Ds.Tables("MyTable").Rows.Count <> 0 Then
                            CrDoc = New NewBarcodeTransferStock
                            With A_Place_For_Printing2
                                CrDoc.SetDataSource(Ds)
                                CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                                CrDoc.PrintOptions.PrinterName = ""
                                CrDoc.RecordSelectionFormula = "{Cetak_TransferStock.Kode_Perusahaan} = '" & KodePerusahaan & "' and {Cetak_TransferStock.Kode_Barang} = '" & TxtKdBarang.Text & "' and {Cetak_TransferStock.batch} = '" & batchLama & "' "
                                CrDoc.SummaryInfo.ReportTitle = "New Barcode Transfer Stock"
                                .Text = "New Barcode Transfer Stock"
                                .CrystalReportViewer1.ReportSource = CrDoc
                                .Refresh()
                                .Show()
                            End With

                        End If
                    End Using

                    CloseConn()
                Catch ex As Exception
                    CloseConn()
                    MessageBox.Show(ex.Message)
                    Exit Sub
                End Try

                Exit Sub

            End If

            Cmd.Transaction.Commit()
            CloseTrans()
            CloseConn()

            MessageBox.Show(Base_Language.Lang_Global_Sukses_Simpan, Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Me.Close()

            EMI_Display_Barang_Masuk_Per_Pallet2222.kosong()
            EMI_Transfer_Stock_Display.kosong()

        Catch ex As Exception
            CloseTrans()
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub


    Private Function Generate_Random_Kode(ByVal length As Integer) As String
        Dim chars As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        Dim result As New StringBuilder()

        For i As Integer = 1 To length
            Dim index As Integer = Random.Next(0, chars.Length)
            result.Append(chars(index))
        Next

        Return result.ToString()
    End Function

    Public Function Generate_QR(ByVal isi As String)
        Dim options As New QrCodeEncodingOptions

        options.DisableECI = True
        options.CharacterSet = "UTF-8"
        'options.Width = 80
        'options.Height = 80

        Dim qr As New ZXing.BarcodeWriter()
        'qr.Options = options
        qr.Options.Width = 80
        qr.Options.Height = 80

        qr.Format = ZXing.BarcodeFormat.QR_CODE

        Dim result As New Bitmap(qr.Write(isi))
        'result.SetResolution(50, 50)

        Return result
    End Function

    Public Shared Function isNull(ByVal xNullString As Object) As String
        Try
            If IsDBNull(xNullString) Then
                Return "0"
            Else
                Return xNullString
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return "0"
        End Try
    End Function



End Class