﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EMI_Transaksi_Quality_Control
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Btn_Simpan = New System.Windows.Forms.Button()
        Me.Btn_Hapus = New System.Windows.Forms.Button()
        Me.Btn_Refresh = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.DGV_Data_QC = New System.Windows.Forms.DataGridView()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Dgv_QC_Lab = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Btn_Diterima = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btn_Peringatan = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Btn_Ditolak = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtNoFaktur = New System.Windows.Forms.TextBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TxtNamaBarang = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtNoLoading = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TxtNoPlat = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TxtNamasup = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtKdBarang = New System.Windows.Forms.TextBox()
        Me.TxtJenisQC = New System.Windows.Forms.TextBox()
        Me.PanelGradient1 = New ERP_EMI.CustomControl.PanelGradient()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.min_range_lap = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Max_range_lap = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Min_Seharusnya_Lap = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Max_Seharusnya_Lap = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewComboBoxColumn1 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.min_range = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.max_range = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Min_Seharusnya = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Max_Seharusnya = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.DGV_Data_QC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgv_QC_Lab, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Btn_Diterima.SuspendLayout()
        Me.Btn_Peringatan.SuspendLayout()
        Me.Btn_Ditolak.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.PanelGradient1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1147, 64)
        Me.Panel1.TabIndex = 22
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(392, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Transaksi - Quality Control (Barang)"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Red
        Me.Panel2.Location = New System.Drawing.Point(0, 51)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(942, 12)
        Me.Panel2.TabIndex = 34
        Me.Panel2.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Red
        Me.Panel3.Location = New System.Drawing.Point(1, 63)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(19, 708)
        Me.Panel3.TabIndex = 35
        Me.Panel3.Visible = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Red
        Me.Panel5.Location = New System.Drawing.Point(1126, 67)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(19, 708)
        Me.Panel5.TabIndex = 37
        Me.Panel5.Visible = False
        '
        'Btn_Simpan
        '
        Me.Btn_Simpan.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.Btn_Simpan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_Simpan.ForeColor = System.Drawing.Color.White
        Me.Btn_Simpan.Location = New System.Drawing.Point(19, 725)
        Me.Btn_Simpan.Name = "Btn_Simpan"
        Me.Btn_Simpan.Size = New System.Drawing.Size(84, 36)
        Me.Btn_Simpan.TabIndex = 6
        Me.Btn_Simpan.Text = "&Simpan"
        Me.Btn_Simpan.UseVisualStyleBackColor = False
        '
        'Btn_Hapus
        '
        Me.Btn_Hapus.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.Btn_Hapus.Enabled = False
        Me.Btn_Hapus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_Hapus.ForeColor = System.Drawing.Color.White
        Me.Btn_Hapus.Location = New System.Drawing.Point(1142, 738)
        Me.Btn_Hapus.Name = "Btn_Hapus"
        Me.Btn_Hapus.Size = New System.Drawing.Size(84, 36)
        Me.Btn_Hapus.TabIndex = 7
        Me.Btn_Hapus.Text = "&Hapus"
        Me.Btn_Hapus.UseVisualStyleBackColor = False
        Me.Btn_Hapus.Visible = False
        '
        'Btn_Refresh
        '
        Me.Btn_Refresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.Btn_Refresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_Refresh.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh.Location = New System.Drawing.Point(109, 725)
        Me.Btn_Refresh.Name = "Btn_Refresh"
        Me.Btn_Refresh.Size = New System.Drawing.Size(84, 36)
        Me.Btn_Refresh.TabIndex = 8
        Me.Btn_Refresh.Text = "&Refresh"
        Me.Btn_Refresh.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Red
        Me.Panel6.Location = New System.Drawing.Point(-1, 711)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(599, 12)
        Me.Panel6.TabIndex = 35
        Me.Panel6.Visible = False
        '
        'DGV_Data_QC
        '
        Me.DGV_Data_QC.AllowUserToAddRows = False
        Me.DGV_Data_QC.AllowUserToDeleteRows = False
        Me.DGV_Data_QC.AllowUserToResizeColumns = False
        Me.DGV_Data_QC.AllowUserToResizeRows = False
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_Data_QC.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DGV_Data_QC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DGV_Data_QC.BackgroundColor = System.Drawing.Color.White
        Me.DGV_Data_QC.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_Data_QC.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DGV_Data_QC.ColumnHeadersHeight = 30
        Me.DGV_Data_QC.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column11, Me.Column12, Me.Column13, Me.Column14, Me.Column15, Me.Column16, Me.Column17, Me.Column18, Me.Column19, Me.Column20, Me.min_range_lap, Me.Max_range_lap, Me.Min_Seharusnya_Lap, Me.Max_Seharusnya_Lap})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_Data_QC.DefaultCellStyle = DataGridViewCellStyle8
        Me.DGV_Data_QC.Location = New System.Drawing.Point(2, 0)
        Me.DGV_Data_QC.MultiSelect = False
        Me.DGV_Data_QC.Name = "DGV_Data_QC"
        Me.DGV_Data_QC.RowHeadersWidth = 21
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_Data_QC.RowsDefaultCellStyle = DataGridViewCellStyle9
        Me.DGV_Data_QC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DGV_Data_QC.Size = New System.Drawing.Size(1098, 451)
        Me.DGV_Data_QC.TabIndex = 459
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Red
        Me.Panel7.Location = New System.Drawing.Point(-1, 763)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(599, 12)
        Me.Panel7.TabIndex = 35
        Me.Panel7.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(23, 90)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 16)
        Me.Label2.TabIndex = 460
        '
        'Dgv_QC_Lab
        '
        Me.Dgv_QC_Lab.AllowUserToAddRows = False
        Me.Dgv_QC_Lab.AllowUserToDeleteRows = False
        Me.Dgv_QC_Lab.AllowUserToResizeColumns = False
        Me.Dgv_QC_Lab.AllowUserToResizeRows = False
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_QC_Lab.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle10
        Me.Dgv_QC_Lab.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Dgv_QC_Lab.BackgroundColor = System.Drawing.Color.White
        Me.Dgv_QC_Lab.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_QC_Lab.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.Dgv_QC_Lab.ColumnHeadersHeight = 30
        Me.Dgv_QC_Lab.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewComboBoxColumn1, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.min_range, Me.max_range, Me.Min_Seharusnya, Me.Max_Seharusnya})
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_QC_Lab.DefaultCellStyle = DataGridViewCellStyle18
        Me.Dgv_QC_Lab.Location = New System.Drawing.Point(2, 0)
        Me.Dgv_QC_Lab.MultiSelect = False
        Me.Dgv_QC_Lab.Name = "Dgv_QC_Lab"
        Me.Dgv_QC_Lab.RowHeadersWidth = 21
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_QC_Lab.RowsDefaultCellStyle = DataGridViewCellStyle19
        Me.Dgv_QC_Lab.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgv_QC_Lab.Size = New System.Drawing.Size(1093, 451)
        Me.Dgv_QC_Lab.TabIndex = 459
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Work Sans SemiBold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(525, 632)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 28)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Summary"
        '
        'Btn_Diterima
        '
        Me.Btn_Diterima.BackColor = System.Drawing.Color.FromArgb(CType(CType(158, Byte), Integer), CType(CType(158, Byte), Integer), CType(CType(158, Byte), Integer))
        Me.Btn_Diterima.Controls.Add(Me.Label4)
        Me.Btn_Diterima.Location = New System.Drawing.Point(87, 664)
        Me.Btn_Diterima.Name = "Btn_Diterima"
        Me.Btn_Diterima.Size = New System.Drawing.Size(323, 36)
        Me.Btn_Diterima.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Work Sans SemiBold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(121, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 23)
        Me.Label4.TabIndex = 462
        Me.Label4.Text = "Diterima"
        '
        'Btn_Peringatan
        '
        Me.Btn_Peringatan.BackColor = System.Drawing.Color.FromArgb(CType(CType(158, Byte), Integer), CType(CType(158, Byte), Integer), CType(CType(158, Byte), Integer))
        Me.Btn_Peringatan.Controls.Add(Me.Label6)
        Me.Btn_Peringatan.Location = New System.Drawing.Point(411, 664)
        Me.Btn_Peringatan.Name = "Btn_Peringatan"
        Me.Btn_Peringatan.Size = New System.Drawing.Size(323, 36)
        Me.Btn_Peringatan.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Work Sans SemiBold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(116, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 23)
        Me.Label6.TabIndex = 462
        Me.Label6.Text = "Peringatan"
        '
        'Btn_Ditolak
        '
        Me.Btn_Ditolak.BackColor = System.Drawing.Color.FromArgb(CType(CType(158, Byte), Integer), CType(CType(158, Byte), Integer), CType(CType(158, Byte), Integer))
        Me.Btn_Ditolak.Controls.Add(Me.Label7)
        Me.Btn_Ditolak.Location = New System.Drawing.Point(735, 664)
        Me.Btn_Ditolak.Name = "Btn_Ditolak"
        Me.Btn_Ditolak.Size = New System.Drawing.Size(323, 36)
        Me.Btn_Ditolak.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Work Sans SemiBold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(126, 7)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 23)
        Me.Label7.TabIndex = 462
        Me.Label7.Text = "Ditolak"
        '
        'txtNoFaktur
        '
        Me.txtNoFaktur.BackColor = System.Drawing.Color.Goldenrod
        Me.txtNoFaktur.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoFaktur.ForeColor = System.Drawing.SystemColors.Window
        Me.txtNoFaktur.Location = New System.Drawing.Point(21, 65)
        Me.txtNoFaktur.MaxLength = 30
        Me.txtNoFaktur.Name = "txtNoFaktur"
        Me.txtNoFaktur.ReadOnly = True
        Me.txtNoFaktur.Size = New System.Drawing.Size(227, 21)
        Me.txtNoFaktur.TabIndex = 462
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(20, 146)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1104, 483)
        Me.TabControl1.TabIndex = 463
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Dgv_QC_Lab)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1096, 457)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Lab"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.DGV_Data_QC)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1096, 457)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Lapangan"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TxtNamaBarang
        '
        Me.TxtNamaBarang.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtNamaBarang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtNamaBarang.Enabled = False
        Me.TxtNamaBarang.Font = New System.Drawing.Font("Work Sans", 8.999999!)
        Me.TxtNamaBarang.Location = New System.Drawing.Point(464, 121)
        Me.TxtNamaBarang.MaxLength = 100
        Me.TxtNamaBarang.Name = "TxtNamaBarang"
        Me.TxtNamaBarang.Size = New System.Drawing.Size(212, 22)
        Me.TxtNamaBarang.TabIndex = 465
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Work Sans", 10.0!)
        Me.Label3.Location = New System.Drawing.Point(347, 121)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 20)
        Me.Label3.TabIndex = 467
        Me.Label3.Text = "Nama Barang"
        '
        'TxtNoLoading
        '
        Me.TxtNoLoading.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtNoLoading.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtNoLoading.Enabled = False
        Me.TxtNoLoading.Font = New System.Drawing.Font("Work Sans", 8.999999!)
        Me.TxtNoLoading.Location = New System.Drawing.Point(125, 93)
        Me.TxtNoLoading.MaxLength = 50
        Me.TxtNoLoading.Name = "TxtNoLoading"
        Me.TxtNoLoading.Size = New System.Drawing.Size(216, 22)
        Me.TxtNoLoading.TabIndex = 464
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Work Sans", 10.0!)
        Me.Label8.Location = New System.Drawing.Point(24, 93)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(85, 20)
        Me.Label8.TabIndex = 466
        Me.Label8.Text = "No Loading"
        '
        'TxtNoPlat
        '
        Me.TxtNoPlat.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtNoPlat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtNoPlat.Enabled = False
        Me.TxtNoPlat.Font = New System.Drawing.Font("Work Sans", 8.999999!)
        Me.TxtNoPlat.Location = New System.Drawing.Point(125, 121)
        Me.TxtNoPlat.MaxLength = 50
        Me.TxtNoPlat.Name = "TxtNoPlat"
        Me.TxtNoPlat.Size = New System.Drawing.Size(216, 22)
        Me.TxtNoPlat.TabIndex = 468
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Work Sans", 10.0!)
        Me.Label9.Location = New System.Drawing.Point(24, 121)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 20)
        Me.Label9.TabIndex = 469
        Me.Label9.Text = "No Plat"
        '
        'TxtNamasup
        '
        Me.TxtNamasup.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtNamasup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtNamasup.Enabled = False
        Me.TxtNamasup.Font = New System.Drawing.Font("Work Sans", 8.999999!)
        Me.TxtNamasup.Location = New System.Drawing.Point(464, 93)
        Me.TxtNamasup.MaxLength = 100
        Me.TxtNamasup.Name = "TxtNamasup"
        Me.TxtNamasup.Size = New System.Drawing.Size(212, 22)
        Me.TxtNamasup.TabIndex = 470
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Work Sans", 10.0!)
        Me.Label10.Location = New System.Drawing.Point(347, 93)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(111, 20)
        Me.Label10.TabIndex = 471
        Me.Label10.Text = "Nama Supplier"
        '
        'TxtKdBarang
        '
        Me.TxtKdBarang.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtKdBarang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtKdBarang.Enabled = False
        Me.TxtKdBarang.Font = New System.Drawing.Font("Work Sans", 8.999999!)
        Me.TxtKdBarang.Location = New System.Drawing.Point(682, 121)
        Me.TxtKdBarang.MaxLength = 100
        Me.TxtKdBarang.Name = "TxtKdBarang"
        Me.TxtKdBarang.Size = New System.Drawing.Size(212, 22)
        Me.TxtKdBarang.TabIndex = 472
        Me.TxtKdBarang.Visible = False
        '
        'TxtJenisQC
        '
        Me.TxtJenisQC.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtJenisQC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtJenisQC.Enabled = False
        Me.TxtJenisQC.Font = New System.Drawing.Font("Work Sans", 8.999999!)
        Me.TxtJenisQC.Location = New System.Drawing.Point(682, 93)
        Me.TxtJenisQC.MaxLength = 100
        Me.TxtJenisQC.Name = "TxtJenisQC"
        Me.TxtJenisQC.Size = New System.Drawing.Size(212, 22)
        Me.TxtJenisQC.TabIndex = 473
        Me.TxtJenisQC.Visible = False
        '
        'PanelGradient1
        '
        Me.PanelGradient1.cuteColor1 = System.Drawing.Color.FromArgb(CType(CType(95, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(185, Byte), Integer))
        Me.PanelGradient1.cuteColor2 = System.Drawing.Color.LightGreen
        Me.PanelGradient1.cuteTransparent1 = 100
        Me.PanelGradient1.cuteTransparent2 = 64
        Me.PanelGradient1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelGradient1.Location = New System.Drawing.Point(0, 62)
        Me.PanelGradient1.Margin = New System.Windows.Forms.Padding(1)
        Me.PanelGradient1.Name = "PanelGradient1"
        Me.PanelGradient1.Size = New System.Drawing.Size(1147, 2)
        Me.PanelGradient1.TabIndex = 22
        '
        'Column11
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column11.DefaultCellStyle = DataGridViewCellStyle3
        Me.Column11.Frozen = True
        Me.Column11.HeaderText = "ID Kode Uji"
        Me.Column11.MinimumWidth = 6
        Me.Column11.Name = "Column11"
        Me.Column11.Visible = False
        Me.Column11.Width = 90
        '
        'Column12
        '
        Me.Column12.Frozen = True
        Me.Column12.HeaderText = "Kode Uji"
        Me.Column12.MinimumWidth = 6
        Me.Column12.Name = "Column12"
        Me.Column12.Width = 170
        '
        'Column13
        '
        Me.Column13.Frozen = True
        Me.Column13.HeaderText = "Keterangan"
        Me.Column13.MinimumWidth = 6
        Me.Column13.Name = "Column13"
        Me.Column13.Width = 300
        '
        'Column14
        '
        Me.Column14.Frozen = True
        Me.Column14.HeaderText = "Satuan"
        Me.Column14.MinimumWidth = 6
        Me.Column14.Name = "Column14"
        '
        'Column15
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column15.DefaultCellStyle = DataGridViewCellStyle4
        Me.Column15.HeaderText = "Value"
        Me.Column15.MinimumWidth = 6
        Me.Column15.Name = "Column15"
        Me.Column15.Width = 150
        '
        'Column16
        '
        Me.Column16.HeaderText = "Value Combo"
        Me.Column16.MinimumWidth = 6
        Me.Column16.Name = "Column16"
        Me.Column16.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column16.Width = 250
        '
        'Column17
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column17.DefaultCellStyle = DataGridViewCellStyle5
        Me.Column17.HeaderText = "Step"
        Me.Column17.MinimumWidth = 6
        Me.Column17.Name = "Column17"
        Me.Column17.Width = 80
        '
        'Column18
        '
        Me.Column18.HeaderText = "-"
        Me.Column18.MinimumWidth = 6
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        Me.Column18.Visible = False
        Me.Column18.Width = 95
        '
        'Column19
        '
        Me.Column19.HeaderText = "Flag_Tampil_Dekstop"
        Me.Column19.MinimumWidth = 6
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        Me.Column19.Visible = False
        Me.Column19.Width = 125
        '
        'Column20
        '
        Me.Column20.HeaderText = "No Urut"
        Me.Column20.MinimumWidth = 6
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        Me.Column20.Visible = False
        Me.Column20.Width = 125
        '
        'min_range_lap
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.min_range_lap.DefaultCellStyle = DataGridViewCellStyle6
        Me.min_range_lap.HeaderText = "Range Mininimal"
        Me.min_range_lap.Name = "min_range_lap"
        Me.min_range_lap.ReadOnly = True
        Me.min_range_lap.Width = 130
        '
        'Max_range_lap
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Max_range_lap.DefaultCellStyle = DataGridViewCellStyle7
        Me.Max_range_lap.HeaderText = "Range Maksimal"
        Me.Max_range_lap.Name = "Max_range_lap"
        Me.Max_range_lap.ReadOnly = True
        Me.Max_range_lap.Width = 130
        '
        'Min_Seharusnya_Lap
        '
        Me.Min_Seharusnya_Lap.HeaderText = "Max_Seharusnya_Lap"
        Me.Min_Seharusnya_Lap.Name = "Min_Seharusnya_Lap"
        Me.Min_Seharusnya_Lap.ReadOnly = True
        Me.Min_Seharusnya_Lap.Visible = False
        '
        'Max_Seharusnya_Lap
        '
        Me.Max_Seharusnya_Lap.HeaderText = "Max_Seharusnya_Lap"
        Me.Max_Seharusnya_Lap.Name = "Max_Seharusnya_Lap"
        Me.Max_Seharusnya_Lap.ReadOnly = True
        Me.Max_Seharusnya_Lap.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle12
        Me.DataGridViewTextBoxColumn1.Frozen = True
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID Kode Uji"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Visible = False
        Me.DataGridViewTextBoxColumn1.Width = 90
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.Frozen = True
        Me.DataGridViewTextBoxColumn2.HeaderText = "Kode Uji"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 170
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.Frozen = True
        Me.DataGridViewTextBoxColumn3.HeaderText = "Keterangan"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 300
        '
        'DataGridViewTextBoxColumn4
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle13
        Me.DataGridViewTextBoxColumn4.Frozen = True
        Me.DataGridViewTextBoxColumn4.HeaderText = "Satuan"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn5.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridViewTextBoxColumn5.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 150
        '
        'DataGridViewComboBoxColumn1
        '
        Me.DataGridViewComboBoxColumn1.HeaderText = "Value Combo"
        Me.DataGridViewComboBoxColumn1.MinimumWidth = 6
        Me.DataGridViewComboBoxColumn1.Name = "DataGridViewComboBoxColumn1"
        Me.DataGridViewComboBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewComboBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewComboBoxColumn1.Width = 250
        '
        'DataGridViewTextBoxColumn6
        '
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn6.DefaultCellStyle = DataGridViewCellStyle15
        Me.DataGridViewTextBoxColumn6.HeaderText = "Step"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 80
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "-"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Visible = False
        Me.DataGridViewTextBoxColumn7.Width = 95
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Flag_Tampil_Dekstop"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Visible = False
        Me.DataGridViewTextBoxColumn8.Width = 125
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "No Urut"
        Me.DataGridViewTextBoxColumn9.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Visible = False
        Me.DataGridViewTextBoxColumn9.Width = 125
        '
        'min_range
        '
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.min_range.DefaultCellStyle = DataGridViewCellStyle16
        Me.min_range.HeaderText = "Range Minimal"
        Me.min_range.Name = "min_range"
        Me.min_range.ReadOnly = True
        Me.min_range.Width = 130
        '
        'max_range
        '
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.max_range.DefaultCellStyle = DataGridViewCellStyle17
        Me.max_range.HeaderText = "Range Maksimal"
        Me.max_range.Name = "max_range"
        Me.max_range.ReadOnly = True
        Me.max_range.Width = 130
        '
        'Min_Seharusnya
        '
        Me.Min_Seharusnya.HeaderText = "Min_Seharusnya"
        Me.Min_Seharusnya.Name = "Min_Seharusnya"
        Me.Min_Seharusnya.ReadOnly = True
        Me.Min_Seharusnya.Visible = False
        '
        'Max_Seharusnya
        '
        Me.Max_Seharusnya.HeaderText = "Max_Seharusnya"
        Me.Max_Seharusnya.Name = "Max_Seharusnya"
        Me.Max_Seharusnya.ReadOnly = True
        Me.Max_Seharusnya.Visible = False
        '
        'EMI_Transaksi_Quality_Control
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1147, 774)
        Me.Controls.Add(Me.TxtJenisQC)
        Me.Controls.Add(Me.TxtKdBarang)
        Me.Controls.Add(Me.TxtNamasup)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.TxtNoPlat)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TxtNamaBarang)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtNoLoading)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.txtNoFaktur)
        Me.Controls.Add(Me.Btn_Ditolak)
        Me.Controls.Add(Me.Btn_Peringatan)
        Me.Controls.Add(Me.Btn_Diterima)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Btn_Refresh)
        Me.Controls.Add(Me.Btn_Hapus)
        Me.Controls.Add(Me.Btn_Simpan)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "EMI_Transaksi_Quality_Control"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DGV_Data_QC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgv_QC_Lab, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Btn_Diterima.ResumeLayout(False)
        Me.Btn_Diterima.PerformLayout()
        Me.Btn_Peringatan.ResumeLayout(False)
        Me.Btn_Peringatan.PerformLayout()
        Me.Btn_Ditolak.ResumeLayout(False)
        Me.Btn_Ditolak.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents PanelGradient1 As CustomControl.PanelGradient
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Btn_Simpan As Button
    Friend WithEvents Btn_Hapus As Button
    Friend WithEvents Btn_Refresh As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents DGV_Data_QC As DataGridView
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Dgv_QC_Lab As DataGridView
    Friend WithEvents Label5 As Label
    Friend WithEvents Btn_Diterima As Panel
    Friend WithEvents Btn_Peringatan As Panel
    Friend WithEvents Btn_Ditolak As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtNoFaktur As TextBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TxtNamaBarang As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TxtNoLoading As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TxtNoPlat As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TxtNamasup As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TxtKdBarang As TextBox
    Friend WithEvents TxtJenisQC As TextBox
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents Column12 As DataGridViewTextBoxColumn
    Friend WithEvents Column13 As DataGridViewTextBoxColumn
    Friend WithEvents Column14 As DataGridViewTextBoxColumn
    Friend WithEvents Column15 As DataGridViewTextBoxColumn
    Friend WithEvents Column16 As DataGridViewComboBoxColumn
    Friend WithEvents Column17 As DataGridViewTextBoxColumn
    Friend WithEvents Column18 As DataGridViewTextBoxColumn
    Friend WithEvents Column19 As DataGridViewTextBoxColumn
    Friend WithEvents Column20 As DataGridViewTextBoxColumn
    Friend WithEvents min_range_lap As DataGridViewTextBoxColumn
    Friend WithEvents Max_range_lap As DataGridViewTextBoxColumn
    Friend WithEvents Min_Seharusnya_Lap As DataGridViewTextBoxColumn
    Friend WithEvents Max_Seharusnya_Lap As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewComboBoxColumn1 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents min_range As DataGridViewTextBoxColumn
    Friend WithEvents max_range As DataGridViewTextBoxColumn
    Friend WithEvents Min_Seharusnya As DataGridViewTextBoxColumn
    Friend WithEvents Max_Seharusnya As DataGridViewTextBoxColumn
End Class
