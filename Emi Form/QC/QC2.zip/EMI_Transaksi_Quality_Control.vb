﻿Imports System.Reflection
Imports System.Windows.Forms.VisualStyles
Imports System.Xml


Public Class EMI_Transaksi_Quality_Control
    Dim arrcari, arrJenisQC As New ArrayList
    Dim arrCmbSwtich As New ArrayList
    Dim Jenis = "Master_Quality_Control"
    Dim id_qc As String
    Dim warna As String
    Dim SudahLoadWarna As Boolean = False

    Public noQc As String

    'Array 2 dimensi menggunakan list
    Dim arr2Switch As New List(Of List(Of String))


    Dim LvIDUji As String
    Dim LvKodeUji As String
    Dim LvKet As String
    Dim LvSatuan As String
    Dim LvMinAwal As String
    Dim LvMaxAwal As String
    Dim LvMinHasil As String
    Dim LvMaxHasil As String
    Dim LvJenis As String
    Dim LvTampilMasuk As String
    Dim LvTampilBongkar As String

    Dim CellIDUji As Integer = 0
    Dim CellKodeUji As Integer = 1
    Dim CellKet As Integer = 2
    Dim CellSatuan As Integer = 3
    Dim CellMinAwal As Integer = 4
    Dim CellMaxAwal As Integer = 5
    Dim CellMinHasil As Integer = 6
    Dim CellMaxHasil As Integer = 7
    Dim CellJenis As Integer = 8
    Dim CellTampilMasuk As Integer = 9
    Dim CellTampilBongkar As Integer = 10

    Dim LvData_Kode As String
    Dim LvData_Ket As String
    Dim LvData_satuan As String
    Dim LvData_ID As String

    Dim cellData_Kode As Integer = 0
    Dim cellData_Ket As Integer = 1
    Dim cellData_satuan As Integer = 2
    Dim cellData_ID As Integer = 3


    Public Sub Get_Isi_Listview(ByVal No_Index As Integer)

        LvIDUji = DGV_Data_QC.Rows(No_Index).Cells(CellIDUji).Value.ToString
        LvKodeUji = DGV_Data_QC.Rows(No_Index).Cells(CellKodeUji).Value.ToString
        LvKet = DGV_Data_QC.Rows(No_Index).Cells(CellKet).Value.ToString
        LvSatuan = DGV_Data_QC.Rows(No_Index).Cells(CellSatuan).Value.ToString
        LvMinAwal = DGV_Data_QC.Rows(No_Index).Cells(CellMinAwal).Value.ToString
        LvMaxAwal = DGV_Data_QC.Rows(No_Index).Cells(CellMaxAwal).Value.ToString
        LvMinHasil = DGV_Data_QC.Rows(No_Index).Cells(CellMinHasil).Value.ToString
        LvMaxHasil = DGV_Data_QC.Rows(No_Index).Cells(CellMaxHasil).Value.ToString
        LvJenis = DGV_Data_QC.Rows(No_Index).Cells(CellJenis).Value.ToString
        LvTampilMasuk = DGV_Data_QC.Rows(No_Index).Cells(CellTampilMasuk).Value.ToString
        LvTampilBongkar = DGV_Data_QC.Rows(No_Index).Cells(CellTampilBongkar).Value.ToString
    End Sub



    Private Sub kosong()
        txtNoFaktur.Text = ""
        txtNoFaktur.Text = noQc
        txtNoFaktur.Focus()

        TxtNoLoading.Text = ""
        TxtNamaBarang.Text = ""
        TxtKdBarang.Text = ""
        TxtNamasup.Text = ""
        TxtNoPlat.Text = ""
        TxtJenisQC.Text = ""

        DGV_Data_QC.Rows.Clear()
        Dgv_QC_Lab.Rows.Clear()

        Btn_Simpan.Text = Base_Language.Lang_Global_Simpan
        Btn_Hapus.Text = Base_Language.Lang_Global_Hapus

        Btn_Refresh.Text = Base_Language.Lang_Global_Refresh
        Btn_Simpan.Tag = "&Simpan"
        Btn_Hapus.Enabled = False

        warna = String.Empty
        Btn_Diterima.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Peringatan.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Ditolak.BackColor = Color.FromArgb(158, 158, 158)

        SudahLoadWarna = False

        Dgv_QC_Lab.Columns("min_range").DisplayIndex = 4
        Dgv_QC_Lab.Columns("max_range").DisplayIndex = 5

        DGV_Data_QC.Columns("min_range_lap").DisplayIndex = 4
        DGV_Data_QC.Columns("max_range_lap").DisplayIndex = 5

        Tampil()

        Load_QC("lapangan")
        Load_QC("lab")


    End Sub
    Private Sub Tampil()
        Try
            OpenConn()
            SQL = "Select a.No_Faktur,b.Kode_Supplier,d.Nama,b.driver As Supir,b.No_Plat As Plat_Number,b.No_SJ,a.Tanggal, "
            SQL = SQL & "a.Kode_Barang, c.nama As nama_barang, a.step, a.No_Fak_Loading_Barang, a.Jenis_QC, a.warna "
            SQL = SQL & "From EMI_Hasil_Quality_Control a, emi_pembelian_loading b, barang c, Suppliers d Where "
            SQL = SQL & "a.Kode_Perusahaan = b.Kode_Perusahaan And a.No_Fak_Loading_Barang = b.no_faktur And "
            SQL = SQL & "a.status Is null And b.status Is null And a.Kode_Perusahaan = c.Kode_Perusahaan And "
            SQL = SQL & "a.Kode_Barang = c.Kode_Barang And a.Kode_Stock_Owner = c.Kode_Stock_Owner "
            SQL = SQL & "And b.Kode_Perusahaan=d.Kode_Perusahaan And b.Kode_Supplier=d.Kode_Supplier "
            SQL = SQL & "And a.kode_Perusahaan='" & KodePerusahaan & "' and a.no_faktur='" & txtNoFaktur.Text & "' "
            Using dr = OpenTrans(SQL)
                If dr.Read Then
                    TxtNoLoading.Text = dr("No_Fak_Loading_Barang")
                    TxtNoPlat.Text = dr("Plat_Number")
                    TxtNamaBarang.Text = dr("nama_barang")
                    TxtNamasup.Text = dr("Nama")
                    TxtKdBarang.Text = dr("Kode_Barang")
                    TxtJenisQC.Text = dr("Jenis_QC")
                End If
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub
    Private Sub Load_QC(ByVal filter As String)
        Try
            OpenConn()

            Base_Language.Get_Languages(Bahasa_Pilihan, "GLOBAL")
            Base_Language.Get_Languages(Bahasa_Pilihan, Jenis)

            Label1.Text = Base_Language.Lang_Quality_Control_Judul

            '=====================
            '=     KODE LAMA     =
            '=====================
            'SQL = ";with cte_qc as ( "
            'SQL = SQL & "select a.kode_perusahaan,a.No_Faktur,a.Id_Quality_Control,b.Kode_Uji,b.Keterangan as Keterangan_Kode_QC,b.Satuan,a.Value_Kode_Uji, "
            'SQL = SQL & "isnull((select x.Keterangan from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and  "
            'SQL = SQL & "x.Id_Switch = a.Value_Kode_Uji), null) as value_Qc, "

            'SQL = SQL & "isnull((select x.id_switch from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and "
            'SQL = SQL & "x.Id_Switch = a.Value_Kode_Uji), null) as Id_Switch, d.Step,d.Tanggal,d.Jam,b.Id_Kategori_Komponen, "
            'SQL = SQL & "c.Keterangan,b.Flag_Tampil_Dekstop,b.Flag_Tampil_android,a.No_Urut, d.flag_sudah_qc_dekstop "
            'SQL = SQL & ",isnull(c.Flag_Input,'T') as Flag_Input, isnull(c.Flag_Option,'T') as Flag_Option, isnull(c.Flag_Slider ,'T') as Flag_Slider "
            'SQL = SQL & "from EMI_Hasil_Detail_Quality_Control a, EMI_Quality_Control b, EMI_Kategori_Komponen c, EMI_Hasil_Quality_Control d "
            'SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Id_Quality_Control = b.Id_QC_Formula and b.Kode_Perusahaan = c.Kode_Perusahaan "
            'SQL = SQL & "and b.Id_Kategori_Komponen = c.Id_Kategori_Komponen  "
            'SQL = SQL & "and a.Kode_Perusahaan = d.Kode_Perusahaan and a.No_Faktur = d.No_Faktur "

            'SQL = SQL & "union all  "

            'SQL = SQL & "select a.kode_perusahaan,a.no_faktur,a.Id_Quality_Control,b.Kode_Uji,b.Keterangan as Keterangan_Kode_QC,b.Satuan,a.Value_Kode_Uji, "

            'SQL = SQL & "isnull((select x.Keterangan from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan "
            'SQL = SQL & "and  x.Id_Switch = a.value_kode_uji ), null) as value_Qc, "

            'SQL = SQL & "isnull((select x.Id_Switch from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and "
            'SQL = SQL & "x.Id_Switch = a.value_kode_uji ), null) as Id_Switch ,d.Step,d.Tanggal,d.Jam,b.Id_Kategori_Komponen, "

            'SQL = SQL & "c.Keterangan,b.Flag_Tampil_Dekstop,b.Flag_Tampil_android,a.No_Urut, d.flag_sudah_qc_dekstop "
            'SQL = SQL & ",isnull(c.Flag_Input,'T') as Flag_Input, isnull(c.Flag_Option,'T') as Flag_Option, isnull(c.Flag_Slider ,'T') as Flag_Slider "
            'SQL = SQL & "from EMI_Hasil_Detail_Switch_QC a, EMI_Quality_Control b, EMI_Kategori_Komponen c, EMI_Hasil_Quality_Control d "
            'SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Id_Quality_Control = b.Id_QC_Formula and b.Kode_Perusahaan = c.Kode_Perusahaan "
            'SQL = SQL & "and b.Id_Kategori_Komponen = c.Id_Kategori_Komponen "
            'SQL = SQL & "and a.Kode_Perusahaan = d.Kode_Perusahaan and a.No_Faktur = d.No_Faktur "
            'SQL = SQL & ") select * from cte_qc where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & txtNoFaktur.Text & "' and flag_sudah_qc_dekstop is null "

            'If filter = "lapangan" Then
            '    SQL = SQL & "And flag_tampil_android = 'Y' "
            'ElseIf filter = "lab" Then
            '    SQL = SQL & "And Flag_Tampil_Dekstop = 'Y' "
            'End If
            'SQL = SQL & "order by flag_tampil_dekstop,Keterangan_Kode_QC "

            SQL = ";with cte_qc as ( "
            SQL = SQL & "select a.kode_perusahaan, a.No_Faktur, a.Id_Quality_Control, b.Kode_Uji, b.Keterangan as Keterangan_Kode_QC, b.Satuan, a.Value_Kode_Uji, "
            SQL = SQL & "d.Step, d.Tanggal, d.Jam, b.Id_Kategori_Komponen, c.Keterangan, b.Flag_Tampil_Dekstop, b.Flag_Tampil_android, a.No_Urut, d.flag_sudah_qc_dekstop, "
            SQL = SQL & "e.Min_Range, e.Max_Range, e.Min_Nilai_Seharusnya, e.Max_Nilai_Seharusnya, "
            SQL = SQL & "isnull((select x.Keterangan from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and x.Id_Switch = a.Value_Kode_Uji), null) as value_Qc, "
            SQL = SQL & "isnull((select x.id_switch from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and x.Id_Switch = a.Value_Kode_Uji), null) as Id_Switch, "
            SQL = SQL & "isnull(c.Flag_Input,'T') as Flag_Input, isnull(c.Flag_Option,'T') as Flag_Option, isnull(c.Flag_Slider ,'T') as Flag_Slider "
            SQL = SQL & "from EMI_Hasil_Detail_Quality_Control a, EMI_Quality_Control b, EMI_Kategori_Komponen c, EMI_Hasil_Quality_Control d, EMI_Quality_Control_PerBarang e "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan " ' Join EMI_Hasil_Detail_Quality_Control & EMI_Quality_Control
            SQL = SQL & "and a.Kode_Perusahaan = d.Kode_Perusahaan " ' Join EMI_Hasil_Detail_Quality_Control & EMI_Hasil_Quality_Control
            SQL = SQL & "and b.Kode_Perusahaan = c.Kode_Perusahaan " ' Join EMI_Quality_Control & EMI_Kategori_Komponen
            SQL = SQL & "and d.Kode_Perusahaan = e.Kode_Perusahaan " ' Join EMI_Hasil_Quality_Control & EMI_Quality_Control_PerBarang
            SQL = SQL & "and a.Id_Quality_Control = b.Id_QC_Formula "
            SQL = SQL & "and b.Id_Kategori_Komponen = c.Id_Kategori_Komponen "
            SQL = SQL & "and a.No_Faktur = d.No_Faktur "
            SQL = SQL & "and d.Kode_Barang = e.Kode_barang "
            SQL = SQL & "and a.Id_Quality_Control = e.Id_QC_Formula "

            SQL = SQL & "union all "

            SQL = SQL & "select a.kode_perusahaan, a.no_faktur, a.Id_Quality_Control, b.Kode_Uji, b.Keterangan as Keterangan_Kode_QC, b.Satuan, a.Value_Kode_Uji, "
            SQL = SQL & "d.Step, d.Tanggal, d.Jam, b.Id_Kategori_Komponen, c.Keterangan, b.Flag_Tampil_Dekstop, b.Flag_Tampil_android, a.No_Urut, d.flag_sudah_qc_dekstop, "
            SQL = SQL & "e.Min_Range, e.Max_Range, e.Min_Nilai_Seharusnya, e.Max_Nilai_Seharusnya, "
            SQL = SQL & "isnull((select x.Keterangan from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and  x.Id_Switch = a.value_kode_uji ), null) as value_Qc, "
            SQL = SQL & "isnull((select x.Id_Switch from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and x.Id_Switch = a.value_kode_uji ), null) as Id_Switch , "
            SQL = SQL & "isnull(c.Flag_Input,'T') as Flag_Input, isnull(c.Flag_Option,'T') as Flag_Option, isnull(c.Flag_Slider ,'T') as Flag_Slider "
            SQL = SQL & "from EMI_Hasil_Detail_Switch_QC a, EMI_Quality_Control b, EMI_Kategori_Komponen c, EMI_Hasil_Quality_Control d, EMI_Quality_Control_PerBarang e "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan " ' Join EMI_Hasil_Detail_Switch_QC & EMI_Quality_Control
            SQL = SQL & "and b.Kode_Perusahaan = c.Kode_Perusahaan " ' Join EMI_Quality_Control & EMI_Kategori_Komponen
            SQL = SQL & "and a.Kode_Perusahaan = d.Kode_Perusahaan " ' Join EMI_Hasil_Detail_Switch_QC & EMI_Hasil_Quality_Control
            SQL = SQL & "and d.Kode_Perusahaan = e.Kode_Perusahaan " ' Join EMI_Hasil_Quality_Control & EMI_Quality_Control_PerBarang
            SQL = SQL & "and a.Id_Quality_Control = b.Id_QC_Formula "
            SQL = SQL & "and b.Id_Kategori_Komponen = c.Id_Kategori_Komponen "
            SQL = SQL & "and a.No_Faktur = d.No_Faktur "
            SQL = SQL & "and d.Kode_Barang = e.Kode_barang "
            SQL = SQL & "and a.Id_Quality_Control = e.Id_QC_Formula "

            SQL = SQL & ") select * from cte_qc "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and No_Faktur = '" & txtNoFaktur.Text & "' "

            'JANGAN LUPA DI UNCOMMENT
            'SQL = SQL & "and flag_sudah_qc_dekstop is null "

            If filter = "lapangan" Then
                SQL = SQL & "And flag_tampil_android = 'Y' "
            ElseIf filter = "lab" Then
                SQL = SQL & "And Flag_Tampil_Dekstop = 'Y' "
            End If

            SQL = SQL & "order by flag_tampil_dekstop,Keterangan_Kode_QC "
            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then

                        If filter = "lapangan" Then
                            For i As Integer = 0 To .Rows.Count - 1
                                DGV_Data_QC.Rows.Add(1)

                                DGV_Data_QC.Rows(i).Cells(0).Value = .Rows(i).Item("id_quality_control")
                                DGV_Data_QC.Rows(i).Cells(1).Value = .Rows(i).Item("kode_uji")
                                DGV_Data_QC.Rows(i).Cells(2).Value = .Rows(i).Item("Keterangan_Kode_QC")
                                DGV_Data_QC.Rows(i).Cells(3).Value = .Rows(i).Item("satuan")


                                If General_Class.CekNULL(.Rows(i).Item("value_qc")) = "" Then
                                    DGV_Data_QC.Rows(i).Cells(4).Value = .Rows(i).Item("value_kode_uji")

                                    DGV_Data_QC.Rows(i).Cells(5).Value = ""
                                    DGV_Data_QC.Rows(i).Cells(4).ReadOnly = True
                                    DGV_Data_QC.Rows(i).Cells(5).ReadOnly = True
                                Else
                                    DGV_Data_QC.Rows(i).Cells(4).Value = ""

                                    Dim dgvCmbValueSwitch As DataGridViewComboBoxCell
                                    dgvCmbValueSwitch = DGV_Data_QC.Rows(i).Cells(5)
                                    dgvCmbValueSwitch.Items.Clear() : arrCmbSwtich.Clear()
                                    dgvCmbValueSwitch.Items.Add(.Rows(i).Item("value_Qc")) : arrCmbSwtich.Add(.Rows(i).Item("id_switch"))

                                    dgvCmbValueSwitch.Value = dgvCmbValueSwitch.Items(0)

                                    DGV_Data_QC.Rows(i).Cells(4).ReadOnly = True
                                    DGV_Data_QC.Rows(i).Cells(5).ReadOnly = True
                                End If
                                DGV_Data_QC.Rows(i).Cells(6).Value = .Rows(i).Item("step")
                                DGV_Data_QC.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow
                                DGV_Data_QC.Rows(i).Cells(8).Value = ""
                                DGV_Data_QC.Rows(i).Cells(9).Value = .Rows(i).Item("no_urut")


                                If Not General_Class.CekNULL(.Rows(i).Item("Min_Range")) = "" Then
                                    DGV_Data_QC.Rows(i).Cells(10).Value = .Rows(i).Item("Min_Range")
                                    DGV_Data_QC.Rows(i).Cells(11).Value = .Rows(i).Item("Max_Range")
                                    DGV_Data_QC.Rows(i).Cells(12).Value = .Rows(i).Item("Min_Nilai_Seharusnya")
                                    DGV_Data_QC.Rows(i).Cells(13).Value = .Rows(i).Item("Max_Nilai_Seharusnya")
                                Else
                                    DGV_Data_QC.Rows(i).Cells(10).Value = ""
                                    DGV_Data_QC.Rows(i).Cells(11).Value = ""
                                    DGV_Data_QC.Rows(i).Cells(12).Value = ""
                                    DGV_Data_QC.Rows(i).Cells(13).Value = ""

                                End If

                            Next

                        Else
                            '===========================
                            arr2Switch.Clear()

                            For i As Integer = 0 To .Rows.Count - 1
                                Dgv_QC_Lab.Rows.Add(1)

                                Dim subArr As New List(Of String)

                                Dgv_QC_Lab.Rows(i).Cells(0).Value = .Rows(i).Item("id_quality_control")
                                Dgv_QC_Lab.Rows(i).Cells(1).Value = .Rows(i).Item("kode_uji")
                                Dgv_QC_Lab.Rows(i).Cells(2).Value = .Rows(i).Item("Keterangan_Kode_QC")
                                Dgv_QC_Lab.Rows(i).Cells(3).Value = .Rows(i).Item("satuan")

                                If .Rows(i).Item("Flag_Option") = "Y" Then
                                    Dgv_QC_Lab.Rows(i).Cells(4).Value = ""

                                    Dim dgvCmbValueSwitch As DataGridViewComboBoxCell
                                    dgvCmbValueSwitch = Dgv_QC_Lab.Rows(i).Cells(5)
                                    dgvCmbValueSwitch.Items.Clear() : arrCmbSwtich.Clear()

                                    SQL = "select a.Id_Switch, a.Keterangan from EMI_Switch a, EMI_Hasil_Detail_Switch_QC b "
                                    SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Id_QC_Formula = b.Id_Quality_Control "
                                    SQL = SQL & "and a.id_qc_formula = '" & .Rows(i).Item("id_quality_control") & "' and b.no_faktur = '" & txtNoFaktur.Text & "' "
                                    Using dr2 = OpenTrans(SQL)
                                        Do While dr2.Read
                                            dgvCmbValueSwitch.Items.Add(dr2("Keterangan")) : subArr.Add(dr2("id_switch"))
                                        Loop
                                    End Using

                                    Dgv_QC_Lab.Rows(i).Cells(4).ReadOnly = True
                                    Dgv_QC_Lab.Rows(i).Cells(5).ReadOnly = False
                                Else
                                    subArr.Add("")

                                    Dgv_QC_Lab.Rows(i).Cells(4).Value = ""
                                    Dgv_QC_Lab.Rows(i).Cells(4).ReadOnly = False
                                    Dgv_QC_Lab.Rows(i).Cells(5).ReadOnly = True
                                End If

                                Dgv_QC_Lab.Rows(i).Cells(6).Value = .Rows(i).Item("step")


                                If .Rows(i).Item("Flag_Option") <> "Y" Then
                                    Dgv_QC_Lab.Rows(i).Cells(4).Style.BackColor = Color.LightGray
                                End If


                                Dgv_QC_Lab.Rows(i).Cells(8).Value = .Rows(i).Item("flag_tampil_dekstop")
                                Dgv_QC_Lab.Rows(i).Cells(9).Value = .Rows(i).Item("no_urut")

                                If Not General_Class.CekNULL(.Rows(i).Item("Min_Range")) = "" Then
                                    Dgv_QC_Lab.Rows(i).Cells(10).Value = .Rows(i).Item("Min_Range")
                                    Dgv_QC_Lab.Rows(i).Cells(11).Value = .Rows(i).Item("Max_Range")
                                    Dgv_QC_Lab.Rows(i).Cells(12).Value = .Rows(i).Item("Min_Nilai_Seharusnya")
                                    Dgv_QC_Lab.Rows(i).Cells(13).Value = .Rows(i).Item("Max_Nilai_Seharusnya")
                                Else
                                    Dgv_QC_Lab.Rows(i).Cells(10).Value = ""
                                    Dgv_QC_Lab.Rows(i).Cells(11).Value = ""
                                    Dgv_QC_Lab.Rows(i).Cells(12).Value = ""
                                    Dgv_QC_Lab.Rows(i).Cells(13).Value = ""

                                End If

                                arr2Switch.Add(subArr)
                            Next
                        End If

                        'Else
                        '    CloseConn()
                        '    'MessageBox.Show("Data QC tidak ada! ", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                        '    EMI_Kendaraan_QC_Display.kosong()
                        '    Me.Close()
                        '    Exit Sub
                    End If
                End With
            End Using


            'Set Warna

            If SudahLoadWarna = False Then
                Try
                    OpenConn()

                    SQL = "select warna from EMI_Hasil_Quality_Control "
                    SQL = SQL & "where kode_perusahaan = '" & KodePerusahaan & "' and no_faktur = '" & txtNoFaktur.Text & "'"
                    Using Dr = OpenTrans(SQL)
                        Do While Dr.Read
                            If Not General_Class.CekNULL(Dr("warna")) = "" Then

                                If Dr("warna").ToString.ToUpper = "HIJAU" Then
                                    Btn_Diterima.BackColor = Color.FromArgb(75, 176, 80)
                                    warna = "HIJAU"
                                ElseIf Dr("warna").ToString.ToUpper = "KUNING" Then
                                    Btn_Peringatan.BackColor = Color.FromArgb(255, 206, 68)
                                    warna = "KUNING"
                                ElseIf Dr("warna").ToString.ToUpper = "MERAH" Then
                                    Btn_Ditolak.BackColor = Color.FromArgb(217, 59, 46)
                                    warna = "MERAH"
                                End If

                            End If
                        Loop
                    End Using

                    SudahLoadWarna = True

                    CloseConn()
                Catch ex As Exception
                    CloseConn()
                    MessageBox.Show(ex.Message)
                    Exit Sub
                End Try
            End If


            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Master_Jenis_Hewan_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")
    End Sub

    Private Sub Master_Jenis_Hewan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")

        kosong()
    End Sub

    Private Sub Btn_Refresh_Click(sender As Object, e As EventArgs) Handles Btn_Refresh.Click
        kosong()
    End Sub

    Private Sub Btn_Simpan_Click(sender As Object, e As EventArgs) Handles Btn_Simpan.Click
        If txtNoFaktur.Text.Trim.Length = 0 Then
            MessageBox.Show(Base_Language.Lang_Quality_Control_Error_Kode, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtNoFaktur.Focus() : Exit Sub

        ElseIf Dgv_QC_Lab.Rows.Count = 0 Then
            MessageBox.Show(Base_Language.Lang_Global_Data_Tdk_Ditemukan, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Dgv_QC_Lab.Focus() : Exit Sub
        End If

        If String.IsNullOrEmpty(warna) Then
            MessageBox.Show("Belum Pilih Summary", Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Label5.Focus() : Exit Sub
        End If

        Try
            OpenConn()
            Cmd.Transaction = Cn.BeginTransaction

            For i As Integer = 0 To Dgv_QC_Lab.Rows.Count - 1

                'cek apakah semua data sudah di isi
                If Dgv_QC_Lab.Rows(i).Cells(5).Value = "" And Dgv_QC_Lab.Rows(i).Cells(4).Value = "" Then
                    CloseTrans()
                    CloseConn()
                    MessageBox.Show("Kode Uji " & Dgv_QC_Lab.Rows(i).Cells(2).Value & " belum di isi!")
                    Exit Sub
                End If

                ' cek apakah dia switch apa bukan
                'kalauu switch update di EMI_Hasil_Detail_Switch_QC
                If Dgv_QC_Lab.Rows(i).Cells(5).Value <> "" Then
                    Dim comboBoxCell As DataGridViewComboBoxCell = CType(Dgv_QC_Lab.Rows(i).Cells(5), DataGridViewComboBoxCell)
                    Dim index As Integer = comboBoxCell.Items.IndexOf(comboBoxCell.Value)

                    'SQL = "update EMI_Hasil_Detail_Switch_QC set value_kode_uji = '" & Dgv_QC_Lab.Rows(i).Cells(5).Value & "' "

                    Dim valuekodeuji As String = arr2Switch(i)(index).ToString

                    '=====================
                    '=     SET WARNA     =
                    '=====================
                    Dim warnaQc As String = ""

                    SQL = "select Flag_Default from EMI_Switch where Kode_Perusahaan = '" & KodePerusahaan & "' and Id_QC_Formula = '" & Dgv_QC_Lab.Rows(i).Cells(0).Value & "' "
                    SQL = SQL & "and Id_Switch = '" & valuekodeuji & "'"
                    Using Dr = OpenTrans(SQL)
                        If Dr.Read Then

                            If Dr("Flag_Default") = "Y" Then
                                warnaQc = "HIJAU"
                            Else
                                warnaQc = "MERAH"
                            End If

                        Else
                            CloseTrans()
                            CloseConn()
                            MessageBox.Show("Data Switch Tidak Ditemukan", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Exit Sub
                        End If
                    End Using

                    '=============================================
                    '=     UPDATE EMI_Hasil_Detail_Switch_QC     =
                    '=============================================
                    SQL = "update EMI_Hasil_Detail_Switch_QC set value_kode_uji = '" & valuekodeuji & "', Warna = '" & warnaQc & "' "
                    SQL = SQL & "where kode_perusahaan = '" & KodePerusahaan & "' "
                    SQL = SQL & "and no_urut = '" & Dgv_QC_Lab.Rows(i).Cells(9).Value & "' "
                    ExecuteTrans(SQL)

                Else

                    '=====================
                    '=     SET WARNA     =
                    '=====================
                    Dim warnaQc As String = ""

                    If Val(Dgv_QC_Lab.Rows(i).Cells(4).Value) < Val(Dgv_QC_Lab.Rows(i).Cells(12).Value) Or Val(Dgv_QC_Lab.Rows(i).Cells(4).Value) > Val(Dgv_QC_Lab.Rows(i).Cells(13).Value) Then
                        warnaQc = "MERAH"
                    Else
                        warnaQc = "HIJAU"
                    End If

                    '===================================================
                    '=     UPDATE EMI_Hasil_Detail_Quality_Control     =
                    '===================================================
                    SQL = "update EMI_Hasil_Detail_Quality_Control set value_kode_uji = '" & Dgv_QC_Lab.Rows(i).Cells(4).Value & "', "
                    SQL = SQL & "Warna = '" & warnaQc & "'"
                    SQL = SQL & "where kode_perusahaan = '" & KodePerusahaan & "' "
                    SQL = SQL & "and no_urut = '" & Dgv_QC_Lab.Rows(i).Cells(9).Value & "' "
                    ExecuteTrans(SQL)
                End If
            Next


            SQL = "update EMI_Hasil_Quality_Control set Flag_Sudah_Qc_Dekstop = 'Y', Warna='" & warna & "' where kode_perusahaan = '" & KodePerusahaan & "' and no_faktur = '" & noQc & "' "
            ExecuteTrans(SQL)

            If TxtJenisQC.Text.Trim = "1" Then

                Dim lvl_Warna_Input As String = ""

                '===========================================
                '=     GET LEVEL WARNA DARI INPUT USER     =
                '===========================================
                SQL = "select Level from EMI_Master_Warna where Kode_Warna = '" & warna & "'"
                Using Dr = OpenTrans(SQL)
                    If Dr.Read Then
                        lvl_Warna_Input = Dr("Level")
                    Else
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("Data Warna Tidak ditemukan", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Exit Sub
                    End If

                End Using

                '===========================
                '=     CEK LEVEL WARNA     =
                '===========================
                SQL = "select top(1) a.No_Faktur, a.No_Fak_Loading_Barang, a.Kode_Stock_Owner, a.Kode_Barang, b.Kode_Warna, b.Level "
                SQL = SQL & "from EMI_Hasil_Quality_Control a, EMI_Master_Warna b "
                SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan "
                SQL = SQL & "and a.Warna = b.Kode_Warna "
                SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' "
                SQL = SQL & "and a.No_Fak_Loading_Barang = '" & TxtNoLoading.Text & "' "
                SQL = SQL & "and a.kode_barang = '" & TxtKdBarang.Text & "' "
                SQL = SQL & "order by b.Level desc "
                Using Ds = BindingTrans(SQL)
                    With Ds.Tables("MyTable")
                        If .Rows.Count <> 0 Then
                            For i As Integer = 0 To .Rows.Count - 1

                                'CEK APAKAH KUALITAS QC LEBIH BAIK DARI KUALITAS QC AKHIR
                                If Val(lvl_Warna_Input) > Val(.Rows(i).Item("Level")) Then

                                    SQL = "update EMI_Pembelian_Loading_detail set flag_qc_pertama ='Y', Warna = '" & warna & "' "
                                    SQL = SQL & "where No_faktur='" & TxtNoLoading.Text & "' and Kode_Perusahaan='" & KodePerusahaan & "' "
                                    SQL = SQL & "and kode_barang='" & TxtKdBarang.Text & "'"
                                    ExecuteTrans(SQL)

                                    SQL = "select Kode_Perusahaan from EMI_Pembelian_Loading_detail where "
                                    SQL = SQL & "No_faktur='" & TxtNoLoading.Text & "' and Kode_Perusahaan='" & KodePerusahaan & "' "
                                    SQL = SQL & "and flag_qc_pertama is null "
                                    Using dr = OpenTrans(SQL)
                                        If Not dr.Read Then
                                            dr.Close()
                                            SQL = "update EMI_Pembelian_Loading set flag_qc_pertama ='Y' "
                                            SQL = SQL & "where No_faktur='" & TxtNoLoading.Text & "' and Kode_Perusahaan='" & KodePerusahaan & "' "
                                            ExecuteTrans(SQL)

                                        End If
                                    End Using
                                End If

                            Next
                        End If
                    End With
                End Using



            End If


            Cmd.Transaction.Commit()
            MessageBox.Show("Data berhasil disimpan ", Judul, MessageBoxButtons.OK)
            CloseConn()
        Catch ex As Exception
            CloseTrans()
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
        kosong()
        EMI_Display_Quality_Control.kosong()
        'EMI_Display_Quality_Control.Btn_Refresh_Click(Btn_Simpan, e)
        Me.Close()
    End Sub

    Private Sub DGV_Data_QC_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs)
        If Val(DGV_Data_QC.CurrentRow.Cells(4).Value) < 0 Or IsNumeric(DGV_Data_QC.CurrentRow.Cells(4).Value) = False Then
            DGV_Data_QC.CurrentRow.Cells(4).Value = 0
        End If
    End Sub

    Private Sub Btn_Hapus_Click(sender As Object, e As EventArgs) Handles Btn_Hapus.Click
        If txtNoFaktur.Text.Trim.Length = 0 Then
            MessageBox.Show(Base_Language.Lang_Quality_Control_Error_Kode, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtNoFaktur.Focus() : Exit Sub
        End If
        Dim Hapus1 As String = MessageBox.Show(Base_Language.Lang_Global_Tanya_Hapus, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If Hapus1 = vbYes Then
            Try
                OpenConn()
                Cmd.Transaction = Cn.BeginTransaction

                SQL = "delete from EMI_Quality_Control_PerBarang where "
                SQL = SQL & "Kode_Perusahaan ='" & KodePerusahaan & "' and "
                SQL = SQL & "Kode_Barang='" & txtNoFaktur.Text & "' "
                ExecuteTrans(SQL)

                Cmd.Transaction.Commit()
                CloseConn()
            Catch ex As Exception
                CloseConn()
                MessageBox.Show(ex.Message)
                Exit Sub
            End Try
        Else
            MessageBox.Show(Base_Language.Lang_Global_Hapus_No, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If
        kosong()
    End Sub



    Private Sub DGV_Data_QC_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs)
        If e.RowIndex = 0 And e.ColumnIndex = 5 Then
            ' Melukis latar belakang default cell
            e.PaintBackground(e.ClipBounds, True)

            ' Menggunakan brush untuk mengganti warna latar belakang
            Using brush As New SolidBrush(Color.LightGreen) ' Pilih warna yang diinginkan
                e.Graphics.FillRectangle(brush, e.CellBounds)
            End Using

            ' Melukis konten cell (teks atau isi ComboBox)
            e.PaintContent(e.ClipBounds)

            ' Tandai bahwa cell sudah di-handle (tidak perlu di-render ulang oleh DataGridView)
            e.Handled = True
        End If
    End Sub



    'FUNCTION UTILITY
    Private Sub Dgv_QC_Lab_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_QC_Lab.CellClick
        If e.ColumnIndex = DataGridViewComboBoxColumn1.Index Then
            Dgv_QC_Lab.CurrentCell = Dgv_QC_Lab.Rows(e.RowIndex).Cells(e.ColumnIndex)
            Dgv_QC_Lab.BeginEdit(True)
        End If
    End Sub

    Private Sub Dgv_QC_Lab_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_QC_Lab.CellEndEdit

        If Dgv_QC_Lab.RowCount = 0 Then Exit Sub

        If IsNumeric(Dgv_QC_Lab.CurrentRow.Cells(CellMinAwal).Value) = False Then
            Dgv_QC_Lab.CurrentRow.Cells(CellMinAwal).Value = ""
        End If


        If Dgv_QC_Lab.CurrentRow.Cells(4).ReadOnly = False Then

            If Val(Dgv_QC_Lab.CurrentRow.Cells(4).Value) < Val(Dgv_QC_Lab.CurrentRow.Cells(10).Value) Or Val(Dgv_QC_Lab.CurrentRow.Cells(4).Value) > Val(Dgv_QC_Lab.CurrentRow.Cells(11).Value) Then
                Dgv_QC_Lab.CurrentRow.Cells(4).Value = ""
                MessageBox.Show("Value Tidak Boleh Lebih atau Kurang dari Range", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

        End If

    End Sub

    'Private Sub Dgv_QC_Lab_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Dgv_QC_Lab.CellFormatting

    '    If Dgv_QC_Lab.Rows(e.RowIndex).Cells(4).ReadOnly Then
    '        Dgv_QC_Lab.Rows(e.RowIndex).Cells(5).Style.BackColor = Color.LightGray
    '    Else
    '        Dgv_QC_Lab.Rows(e.RowIndex).Cells(5).Style.BackColor = Color.White
    '    End If
    'End Sub

    'FUNCTION HANDLE BUTTON
    Private Sub Btn_Diterima_Click(sender As Object, e As EventArgs) Handles Btn_Diterima.Click
        Btn_Peringatan.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Ditolak.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Diterima.BackColor = Color.FromArgb(75, 176, 80)
        warna = "Hijau"
    End Sub
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Btn_Peringatan.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Ditolak.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Diterima.BackColor = Color.FromArgb(75, 176, 80)
        warna = "Hijau"
    End Sub
    Private Sub Btn_Peringatan_Click(sender As Object, e As EventArgs) Handles Btn_Peringatan.Click
        Btn_Diterima.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Ditolak.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Peringatan.BackColor = Color.FromArgb(255, 206, 68)
        warna = "Kuning"
    End Sub
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Btn_Diterima.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Ditolak.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Peringatan.BackColor = Color.FromArgb(255, 206, 68)
        warna = "Kuning"
    End Sub
    Private Sub Btn_Ditolak_Click(sender As Object, e As EventArgs) Handles Btn_Ditolak.Click
        Btn_Diterima.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Peringatan.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Ditolak.BackColor = Color.FromArgb(217, 59, 46)
        warna = "Merah"
    End Sub
    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Btn_Diterima.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Peringatan.BackColor = Color.FromArgb(158, 158, 158)
        Btn_Ditolak.BackColor = Color.FromArgb(217, 59, 46)
        warna = "Merah"
    End Sub


    'HANDLE CURSOR MASUK
    Private Sub Btn_Diterima_MouseEnter(sender As Object, e As EventArgs) Handles Btn_Diterima.MouseEnter
        Btn_Diterima.Cursor = Cursors.Hand
    End Sub
    Private Sub Btn_Peringatan_MouseEnter(sender As Object, e As EventArgs) Handles Btn_Peringatan.MouseEnter
        Btn_Peringatan.Cursor = Cursors.Hand
    End Sub
    Private Sub Btn_Ditolak_MouseEnter(sender As Object, e As EventArgs) Handles Btn_Ditolak.MouseEnter
        Btn_Ditolak.Cursor = Cursors.Hand
    End Sub
    Private Sub Label4_MouseEnter(sender As Object, e As EventArgs) Handles Label4.MouseEnter
        Label4.Cursor = Cursors.Hand
    End Sub
    Private Sub Label6_MouseEnter(sender As Object, e As EventArgs) Handles Label6.MouseEnter
        Label6.Cursor = Cursors.Hand
    End Sub
    Private Sub Label7_MouseEnter(sender As Object, e As EventArgs) Handles Label7.MouseEnter
        Label7.Cursor = Cursors.Hand
    End Sub

    'HANDLE CURSOR KELUAR
    Private Sub Btn_Diterima_MouseLeave(sender As Object, e As EventArgs) Handles Btn_Diterima.MouseLeave
        Btn_Diterima.Cursor = Cursors.Default
    End Sub
    Private Sub Btn_Peringatan_MouseLeave(sender As Object, e As EventArgs) Handles Btn_Peringatan.MouseLeave
        Btn_Peringatan.Cursor = Cursors.Default
    End Sub
    Private Sub Btn_Ditolak_MouseLeave(sender As Object, e As EventArgs) Handles Btn_Ditolak.MouseLeave
        Btn_Ditolak.Cursor = Cursors.Default
    End Sub
    Private Sub Label4_MouseLeave(sender As Object, e As EventArgs) Handles Label4.MouseLeave
        Label4.Cursor = Cursors.Default
    End Sub
    Private Sub Label6_MouseLeave(sender As Object, e As EventArgs) Handles Label6.MouseLeave
        Label6.Cursor = Cursors.Default
    End Sub


    Private Sub Label7_MouseLeave(sender As Object, e As EventArgs) Handles Label7.MouseLeave
        Label7.Cursor = Cursors.Default
    End Sub



End Class