﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class EMI_Refraksi_Display

    Dim arrFilter As New ArrayList

    Dim Lv_NoPO, Lv_KdSO, Lv_KdBarang, Lv_NmBarang, Lv_JmlhPO, Lv_Satuan, Lv_HargaPO, Lv_HargaRefraksi, Lv_NoUrut, Lv_NilaiBarang, Lv_SatuanBarang As String

    Dim item_NoPO As Integer = 0
    Dim item_KdSO As Integer = 1
    Dim item_KdBarang As Integer = 2
    Dim item_NmBarang As Integer = 3
    Dim item_JmlhPO As Integer = 4
    Dim item_Satuan As Integer = 5
    Dim item_HargaPO As Integer = 6
    Dim item_HargaRefraksi As Integer = 7
    Dim item_NoUrut As Integer = 8
    Dim item_NilaiBarang As Integer = 9
    Dim item_SatuanBarang As Integer = 10

    Private Sub EMI_Refraksi_Display_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        initial_Lv_PO()
        kosong()

    End Sub

    Private Sub kosong()

        Lv_PO.Items.Clear()
        Lv_Detail.Items.Clear()

        Txt_ValueFilter.Text = ""
        Txt_NoPO.Text = ""
        Txt_HargaSebelum.Text = ""
        Txt_HargaRefraksi.Text = ""

        Cmb_Filter.Items.Clear()
        Cmb_Filter.Items.Add("No Po") : arrFilter.Add("a.no_faktur")
        Cmb_Filter.Items.Add("Lokasi") : arrFilter.Add("b.Kode_Stock_Owner")
        Cmb_Filter.Items.Add("Kode Barang") : arrFilter.Add("b.Kode_Barang")
        Cmb_Filter.Items.Add("Nama Barang") : arrFilter.Add("c.Nama")
        Cmb_Filter.SelectedIndex = -1

        Get_Data_PO()

    End Sub

    Private Sub initial_Lv_PO()

        Lv_PO.Columns.Clear()
        Lv_PO.Columns.Add("No PO", 130, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("Lokasi", 130, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("Kode Barang", 120, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("Nama", 230, HorizontalAlignment.Left)
        Lv_PO.Columns.Add("Jumlah", 90, HorizontalAlignment.Right)
        Lv_PO.Columns.Add("Satuan", 80, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("Harga", 0, HorizontalAlignment.Right)
        Lv_PO.Columns.Add("Harga Refraksi", 0, HorizontalAlignment.Right)

        'Hide
        Lv_PO.Columns.Add("no Urut", 0, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("Nilai Barang", 0, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("Satuan Barang", 0, HorizontalAlignment.Center)
        Lv_PO.View = View.Details

        '====================================================================================

        Lv_Detail.Columns.Clear()
        Lv_Detail.Columns.Add("Harga", 120, HorizontalAlignment.Center)
        Lv_Detail.Columns.Add("Satuan", 80, HorizontalAlignment.Center)
        Lv_Detail.Columns.Add("Harga Refraksi", 0, HorizontalAlignment.Center)
        Lv_Detail.View = View.Details

    End Sub

    Private Sub Get_Data_PO(ByVal index As Integer)

        Lv_NoPO = Lv_PO.Items(index).SubItems(item_NoPO).Text
        Lv_KdSO = Lv_PO.Items(index).SubItems(item_KdSO).Text
        Lv_KdBarang = Lv_PO.Items(index).SubItems(item_KdBarang).Text
        Lv_NmBarang = Lv_PO.Items(index).SubItems(item_NmBarang).Text
        Lv_JmlhPO = Lv_PO.Items(index).SubItems(item_JmlhPO).Text
        Lv_Satuan = Lv_PO.Items(index).SubItems(item_Satuan).Text
        Lv_HargaPO = Lv_PO.Items(index).SubItems(item_HargaPO).Text
        Lv_HargaRefraksi = Lv_PO.Items(index).SubItems(item_HargaRefraksi).Text
        Lv_NoUrut = Lv_PO.Items(index).SubItems(item_NoUrut).Text
        Lv_NilaiBarang = Lv_PO.Items(index).SubItems(item_NilaiBarang).Text
        Lv_SatuanBarang = Lv_PO.Items(index).SubItems(item_SatuanBarang).Text

    End Sub


    Private Sub Get_Data_PO(Optional filter As String = "")

        Try
            OpenConn()

            Lv_PO.Items.Clear()
            SQL = "select a.no_faktur, b.Kode_Stock_Owner, b.Kode_Barang, c.Nama, b.No_Urut, b.Jumlah, b.Satuan, Nilai_Barang, b.Satuan_Barang, b.Harga as Harga_Sebelum_Refraksi, b.Harga_Refraksi "
            SQL = SQL & "from EMI_Pembelian_PO a, EMI_Pembelian_PO_Detail b, Barang c "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and b.Kode_Perusahaan = c.Kode_Perusahaan "
            SQL = SQL & "and a.No_Faktur = b.No_Faktur "
            SQL = SQL & "and b.Kode_Stock_Owner = c.Kode_Stock_Owner and b.Kode_Barang = c.Kode_Barang "
            SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and Flag_Permintaan_Refraksi = 'Y' "
            SQL = SQL & "order by No_Urut "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read

                    Dim lv As ListViewItem
                    lv = Lv_PO.Items.Add(Dr("no_faktur"))
                    lv.SubItems.Add(Dr("Kode_Stock_Owner"))
                    lv.SubItems.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Format(Dr("Jumlah"), "N2"))
                    lv.SubItems.Add(Dr("Satuan"))
                    lv.SubItems.Add(Format(Dr("Harga_Sebelum_Refraksi"), "N2"))
                    If General_Class.CekNULL(Dr("Harga_Refraksi")) = "" Then
                        lv.SubItems.Add(0)
                    Else
                        lv.SubItems.Add(Dr("Harga_Refraksi"))
                    End If

                    'Hide
                    lv.SubItems.Add(Dr("No_Urut"))
                    lv.SubItems.Add(Dr("Nilai_Barang"))
                    lv.SubItems.Add(Dr("Satuan_Barang"))

                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Lv_PO_DoubleClick(sender As Object, e As EventArgs) Handles Lv_PO.DoubleClick

        If Lv_PO.Items.Count = 0 Then Exit Sub

        Get_Data_PO(Lv_PO.FocusedItem.Index)

        Try
            OpenConn()

            Lv_Detail.Items.Clear()
            SQL = "select no_faktur ,Nilai_Barang, Satuan_Barang, Harga, Total, Harga_Refraksi "
            SQL = SQL & "from EMI_Pembelian_PO_Detail "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and No_Faktur = '" & Lv_NoPO & "' and Kode_Stock_Owner = '" & Lv_KdSO & "' and Kode_Barang = '" & Lv_KdBarang & "' "
            SQL = SQL & "and No_Urut = '" & Lv_NoUrut & "'"
            Using Dr = OpenTrans(SQL)
                If Dr.Read Then

                    Dim lv As New ListViewItem(Format(Dr("Harga"), "N2"))
                    lv.SubItems.Add(Dr("Satuan_Barang"))

                    If General_Class.CekNULL(Dr("Harga_Refraksi")) = "" Then
                        lv.SubItems.Add("")
                    Else
                        lv.SubItems.Add(Dr("Harga_Refraksi"))
                    End If

                    Lv_Detail.Items.Add(lv)

                    '===========================
                    Txt_NoPO.Text = Dr("no_faktur")
                    Txt_HargaSebelum.Text = Format(Dr("Harga"), "N2")


                Else
                    CloseConn()
                    MessageBox.Show("Data Tidak Ditemukan", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            End Using


            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Btn_Refresh_Click(sender As Object, e As EventArgs) Handles Btn_Refresh.Click
        kosong()
    End Sub


    Private Sub Btn_Cari_Click(sender As Object, e As EventArgs) Handles Btn_Cari.Click

        If Not Txt_ValueFilter.Text.Trim.Length = 0 Then
            If Cmb_Filter.SelectedIndex <> 0 Then
                MessageBox.Show("Pilih Dahulu Jenis Filter", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_ValueFilter.Text = "" : Cmb_Filter.Focus()
                Exit Sub
            End If
        End If

        If Cmb_Filter.SelectedIndex > 0 Then
            If Txt_ValueFilter.Text.Trim.Length = 0 Then
                MessageBox.Show("Value Filter Tidak Boleh Kosong", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_ValueFilter.Focus()
                Exit Sub
            End If
        End If


        Try
            OpenConn()

            Dim asdasdas As Integer = Cmb_Filter.SelectedIndex

            Lv_PO.Items.Clear()
            SQL = "select a.no_faktur, b.Kode_Stock_Owner, b.Kode_Barang, c.Nama, b.No_Urut, b.Jumlah, b.Satuan, Nilai_Barang, b.Satuan_Barang, b.Harga as Harga_Sebelum_Refraksi, b.Harga_Refraksi "
            SQL = SQL & "from EMI_Pembelian_PO a, EMI_Pembelian_PO_Detail b, Barang c "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and b.Kode_Perusahaan = c.Kode_Perusahaan "
            SQL = SQL & "and a.No_Faktur = b.No_Faktur "
            SQL = SQL & "and b.Kode_Stock_Owner = c.Kode_Stock_Owner and b.Kode_Barang = c.Kode_Barang "
            SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and Flag_Permintaan_Refraksi = 'Y' "
            If Cmb_Filter.SelectedIndex <> -1 Then
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "
                SQL = SQL & arrFilter.Item(Cmb_Filter.SelectedIndex) & "  like  '%" & Trim(Txt_ValueFilter.Text) & "%' "
            End If
            SQL = SQL & "order by No_Urut "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read

                    Dim lv As ListViewItem
                    lv = Lv_PO.Items.Add(Dr("no_faktur"))
                    lv.SubItems.Add(Dr("Kode_Stock_Owner"))
                    lv.SubItems.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Format(Dr("Jumlah"), "N2"))
                    lv.SubItems.Add(Dr("Satuan"))
                    lv.SubItems.Add(Format(Dr("Harga_Sebelum_Refraksi"), "N2"))
                    If General_Class.CekNULL(Dr("Harga_Refraksi")) = "" Then
                        lv.SubItems.Add(0)
                    Else
                        lv.SubItems.Add(Dr("Harga_Refraksi"))
                    End If

                    'Hide
                    lv.SubItems.Add(Dr("No_Urut"))
                    lv.SubItems.Add(Dr("Nilai_Barang"))
                    lv.SubItems.Add(Dr("Satuan_Barang"))

                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub Btn_Simpan_Click(sender As Object, e As EventArgs) Handles Btn_Simpan.Click

        If Txt_NoPO.Text.Trim.Length = 0 Or Txt_HargaSebelum.Text.Trim.Length = 0 Or Txt_HargaRefraksi.Text.Trim.Length = 0 Then
            MessageBox.Show("Data Tidak Boleh Kosong", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If

        If Not IsNumeric(Txt_HargaRefraksi.Text) Then
            MessageBox.Show("Input Tidak Boleh Huruf ", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Txt_HargaRefraksi.Text = "" : Txt_HargaRefraksi.Focus()
            Exit Sub
        End If

        If Txt_HargaRefraksi.Text.Contains(",") Then
            MessageBox.Show("Input Tidak Boleh ',' ganti dengan ',' ", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Txt_HargaRefraksi.Text = "" : Txt_HargaRefraksi.Focus()
            Exit Sub
        End If


        Try
            OpenConn()
            Cmd.Transaction = Cn.BeginTransaction

            '==============================
            '=     UBAH HARGA BERUBAH     =
            '==============================
            Dim hargaInput As String = ""
            SQL = "select dbo.ubah_satuan('" & KodePerusahaan & "', 'UANG', '" & Lv_KdBarang & "', '" & Lv_Satuan & "', '" & Lv_SatuanBarang & "', "
            SQL = SQL & "'" & Val(HilangkanTanda(Txt_HargaRefraksi.Text)) & "') as harga_input "
            Using Dr = OpenTrans(SQL)
                If Dr.Read Then
                    hargaInput = Dr("harga_input")
                Else
                    CloseTrans()
                    CloseConn()
                    MessageBox.Show("Terjadi Kesalahan saat Ubah Harga", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            End Using

            '===============================================
            '=     UPDATE EMI_Pembelian_PO_Detail     =
            '===============================================
            SQL = "update EMI_Pembelian_PO_Detail set Flag_Permintaan_Refraksi = null, Flag_Refraksi='Y', Harga_Refraksi = '" & hargaInput & "' "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & Lv_NoPO & "' and Kode_Stock_Owner = '" & Lv_KdSO & "' "
            SQL = SQL & "and Kode_Barang = '" & Lv_KdBarang & "' and No_Urut = '" & Lv_NoUrut & "'"
            ExecuteTrans(SQL)



            Cmd.Transaction.Commit()
            CloseTrans()
            CloseConn()
            MessageBox.Show("Data Berhasil Disimpan", Judul, MessageBoxButtons.OK, MessageBoxIcon.Information)
            kosong()
        Catch ex As Exception
            CloseTrans()
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub





End Class