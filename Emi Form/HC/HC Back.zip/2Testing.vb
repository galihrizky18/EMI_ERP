﻿Imports CrystalDecisions.CrystalReports.ViewerObjectModel
Imports LovePdf
Imports LovePdf.Sign

Imports LovePdf.Sign.Signature
Imports LovePdf.Sign.SignatureElement
Imports LovePdf.Model.TaskParams.Sign.Elements
Imports LovePdf.Model.Task
Imports LovePdf.Core
Imports LovePdf.Model.TaskParams
Imports LovePdf.Core.Sign
Imports Microsoft.VisualBasic.ApplicationServices

Public Class Testing

    Dim arr As New ArrayList

    Dim PublicKey As String = "project_public_e4c20d1ff42102c0a1b1986880530890_TZwLt2e5b1568f99c733dcbe14f9a7f45c281"
    Dim SecretKey As String = "secret_key_2b16efaf46968a5011fda3ec2b914606_dwxr02fab3732f1f08d3aac26fcf8d60e6c32"

    'Dim PublicKey As String = "project_public_359975c88d0924734303ef91556255ab_wqTQYb8d591fb3b6d9c655ec7271a5fd64465"
    'Dim SecretKey As String = "secret_key_bc1b2ae6d361b74aa57c66b58718be1b_3Cnev65e98fa75dd7e2045e73164844da43ee"

    Dim FilePath As String = "F:\PEKERJAAN\MAIN\FormatHC\3_Format_Pengajuan_CnB_untuk_Pak_Hendri_IT.pdf"
    Dim userPengajuan As New Dictionary(Of String, List(Of String))
    Dim userApprov As New Dictionary(Of String, List(Of String))



    Private Sub Testing_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            OpenConn()

            SQL = "select No_Faktur, Nama from HRIS_Transaksi_Karyawan"
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    ComboBox1.Items.Add(Dr("Nama")) : arr.Add(Dr("No_Faktur"))
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try


        'ADD USER
        userApprov("1") = New List(Of String) From {"Andi", "akuntumbalunsri@gmail.com", "CMO", "a1b2c3"}
        userApprov("2") = New List(Of String) From {"Budi", "Tes1@gmail.com", "HCGA Div. Head", "a2gh6d"}

        'user pengajuan
        userPengajuan("1") = New List(Of String) From {"Donna Th. S", "galihrizkycode@gmail.com", "POD Dept. Head", "a23sfd"}


    End Sub

    Private Async Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Set API key dari iLovePDF
        Try
            Dim lovePdfAPi = New LovePdfApi(PublicKey, SecretKey)

            Dim task As SignTask = lovePdfAPi.CreateTask(Of SignTask)()

            ' Tambahkan file PDF yang akan ditandatangani
            Dim file = task.AddFile(FilePath)

            Dim signParams = New SignParams()
            signParams.SubjectSigner = "C&B Karyawan Baru"
            signParams.MessageSigner = "C&B Karyawan Baru"

            signParams.SignerReminderDaysCycle = 2
            signParams.SignerReminders = True
            signParams.ExpirationDays = 30

            signParams.VerifyEnabled = True
            signParams.LockOrder = True
            signParams.UuidVisible = True

            'Dim positionAwalX As Double = 48
            'Dim positionAwalY As Double = 739.2

            Dim positionAwalX As String = "148"
            Dim positionAwalY As String = "-538"



            ''' Tambah signer pertama
            'Dim signer1 = signParams.AddSigner(isiUserPengajuan(0), isiUserPengajuan(1))
            'signer1.AccessCode = isiUserPengajuan(3)


            'Dim signerFile1 = signer1.AddFile(file.ServerFileName)

            '' Tambah elemen tanda tangan untuk signer pertama
            'Dim signatureElement1 As SignatureElement = signerFile1.AddSignature()
            'signatureElement1.Position = New Position(positionAwalX, positionAwalY)
            'signatureElement1.Pages = "1"
            'signatureElement1.Size = 25



            'ADD SIGN USER PENGAJUAN 

            Dim isiUserPengajuan As List(Of String) = userPengajuan("1")

            Dim signerPengajuan = signParams.AddSigner(isiUserPengajuan(0), isiUserPengajuan(1))
            signerPengajuan.AccessCode = isiUserPengajuan(3)

            Dim signerFilePengajuan = signerPengajuan.AddFile(file.ServerFileName)

            ' Tambah elemen tanda tangan untuk signer pertama
            Dim signatureElement As SignatureElement = signerFilePengajuan.AddSignature()
            signatureElement.Position = New Position(positionAwalX, positionAwalY)
            signatureElement.Pages = "1"
            signatureElement.Size = 30

            'UNTUK PENAMBAHAN ELEMEN TEKS PENDEKUNG SEPERTI MENYETUJI, NAMA, JABATAN

            Dim generalTextElement As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFilePengajuan.AddText("Menyetujui")
            generalTextElement.Position = New Position("148", "300")
            generalTextElement.Size = 17
            generalTextElement.Pages = "1"

            Dim generaElementNama As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFilePengajuan.AddText(isiUserPengajuan(0))
            generaElementNama.Position = New Position("148", "210")
            generaElementNama.Size = 15
            generaElementNama.Pages = "1"

            Dim generaElementJabatan As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFilePengajuan.AddText(isiUserPengajuan(2))
            generaElementJabatan.Position = New Position("148", "200") ' Atur posisi sesuai kebutuhan
            generaElementJabatan.Size = 15
            generaElementJabatan.Pages = "1"

            '===========

            Dim signerPengajuan2 = signParams.AddSigner("Andi", "akuntumbalunsri@gmail.com")
            signerPengajuan2.AccessCode = isiUserPengajuan(3)

            Dim signerFilePengajuan2 = signerPengajuan2.AddFile(file.ServerFileName)

            ' Tambah elemen tanda tangan untuk signer pertama
            Dim signatureElement2 As SignatureElement = signerFilePengajuan2.AddSignature()
            signatureElement2.Position = New Position((Val(positionAwalX) + 140).ToString, positionAwalY)
            signatureElement2.Pages = "1"
            signatureElement2.Size = 30

            'UNTUK PENAMBAHAN ELEMEN TEKS PENDEKUNG SEPERTI MENYETUJI, NAMA, JABATAN

            Dim generalTextElement2 As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFilePengajuan.AddText("Menyetujui")
            generalTextElement2.Position = New Position((Val(positionAwalX) + 140).ToString, (Val(positionAwalY) + 830).ToString)
            generalTextElement2.Size = 17
            generalTextElement2.Pages = "1"

            Dim generaElementNama2 As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFilePengajuan.AddText(isiUserPengajuan(0))
            generaElementNama2.Position = New Position((Val(positionAwalX) + 140).ToString, (Val(positionAwalY) + 740).ToString)
            generaElementNama2.Size = 15
            generaElementNama2.Pages = "1"

            Dim generaElementJabatan2 As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFilePengajuan.AddText(isiUserPengajuan(2))
            generaElementJabatan2.Position = New Position((Val(positionAwalX) + 140).ToString, (Val(positionAwalY) + 730).ToString) ' Atur posisi sesuai kebutuhan
            generaElementJabatan2.Size = 15
            generaElementJabatan2.Pages = "1"




            ''LOOP USER MENYETUJUI
            'For Each User As KeyValuePair(Of String, List(Of String)) In userApprov

            '    positionAwalX = (Val(positionAwalX) + 153.6).ToString

            '    Dim isi As List(Of String) = User.Value

            '    Dim signer1 = signParams.AddSigner(isi(0), isi(1))
            '    signer1.AccessCode = isi(3)

            '    Dim signerFile1 = signer1.AddFile(file.ServerFileName)

            '    ' Tambah elemen tanda tangan untuk signer pertama
            '    Dim signatureElement1 As SignatureElement = signerFile1.AddSignature()
            '    signatureElement1.Position = New Position(positionAwalX, positionAwalY)
            '    signatureElement1.Pages = "1"
            '    signatureElement1.Size = 30

            '    'UNTUK PENAMBAHAN ELEMEN TEKS PENDEKUNG SEPERTI MENYETUJI, NAMA, JABATAN
            '    Dim generalTextElement1 As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFile1.AddText("Menyetujui")
            '    generalTextElement1.Position = New Position(positionAwalX, (Val(positionAwalY) + 830).ToString)
            '    generalTextElement1.Size = 17
            '    generalTextElement1.Pages = "1"

            '    Dim generalTextElement2 As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFile1.AddText(isi(0))
            '    generalTextElement1.Position = New Position(positionAwalX, (Val(positionAwalY) + 740).ToString) ' Atur posisi sesuai kebutuhan
            '    generalTextElement1.Size = 15
            '    generalTextElement1.Pages = "1"

            '    Dim generalTextElement3 As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFile1.AddText(isi(2))

            '    generalTextElement1.Position = New Position(positionAwalX, (Val(positionAwalY) + 730).ToString) ' Atur posisi sesuai kebutuhan
            '    generalTextElement1.Size = 15
            '    generalTextElement1.Pages = "1"
            'Next




            'Dim signature = task.RequestSignatureAsync(signParams)



            ' Kirim permintaan tanda tangan ke kedua signer dalam satu alur
            Dim signatureResponse As SignatureResponse = Await task.RequestSignatureAsync(signParams)

            ' Periksa apakah permintaan tanda tangan berhasil
            If signatureResponse IsNot Nothing Then
                Dim tokenRequester As String = signatureResponse.TokenRequester
                MessageBox.Show("Token Requester: " & tokenRequester)
            Else
                MessageBox.Show("Permintaan tanda tangan gagal.")
            End If

            MessageBox.Show("Berhasil")

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try




        'Try
        '    OpenConn()

        'QUERY AMBIL SIAPA YG APPROVE, SAMA SEPERTI FUNCTION Approval_Hierarchy
        '    SQL = "select a.No_Faktur, a.Nama, a.ID_Level_Jabatan, c.ID_Divisi, d.ID_Sub_Divisi, e.UserID_Approval, f.Nama as Nama_Approval, f.Email ,e.Jenis_Approval "
        '    SQL = SQL & "from HRIS_Transaksi_Karyawan a, HRIS_Divisi_Sub_Divisi b, HRIS_Divisi c, HRIS_Sub_Divisi d, HRIS_UserID_Approval_Karyawan e, Karyawan f "
        '    SQL = SQL & "where a.ID_Divisi_Sub_Divisi=b.ID_Divisi_Sub_Divisi "
        '    SQL = SQL & "and b.ID_Divisi=c.ID_Divisi and b.ID_Sub_Divisi=d.ID_Sub_Divisi and a.Kode_Perusahaan=e.Kode_Perusahaan "
        '    SQL = SQL & "and a.ID_Level_Jabatan = e.ID_Level and c.ID_Divisi=e.ID_Divisi "
        '    SQL = SQL & "and e.Kode_Perusahaan=f.Kode_Perusahaan and e.UserID_Approval=f.UserID "
        '    SQL = SQL & "and a.no_faktur='" & arr(ComboBox1.SelectedIndex) & "'"
        '    Using Dr = OpenTrans(SQL)
        '        Do While Dr.Read
        '            Dim lv As ListViewItem
        '            lv = ListView1.Items.Add(Dr("UserID_Approval"))
        '            lv.SubItems.Add(Dr("Email"))


        '            ' Tambah signer pertama
        '            Dim signer1 = signParams.AddSigner(Dr("Nama_Approval"), Dr("Email"))
        '            signer1.AccessCode = "a1b2c3"

        '            Dim signerFile1 = signer1.AddFile(file.ServerFileName)

        '            ' Tambah elemen tanda tangan untuk signer pertama
        '            Dim signatureElement1 As SignatureElement = signerFile1.AddSignature()
        '            signatureElement1.Position = New Position("left", "bottom")
        '            signatureElement1.Pages = "1"
        '            signatureElement1.Size = 60

        '            Dim generalTextElement As LovePdf.Model.TaskParams.Sign.Elements.TextElement = signerFile1.AddText("This is a general text field 1")
        '            generalTextElement.Position = New Position("100", "100") ' Atur posisi sesuai kebutuhan
        '            generalTextElement.Size = 18
        '            generalTextElement.Pages = "1"

        '        Loop
        '    End Using

        '    CloseConn()
        'Catch ex As Exception
        '    CloseConn()
        '    MessageBox.Show(ex.Message)
        '    Exit Sub
        'End Try




        '===========================


    End Sub

    'Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
    '    Try
    '        OpenConn()

    '        SQL = "select a.No_Faktur, a.Nama, a.ID_Level_Jabatan, c.ID_Divisi, d.ID_Sub_Divisi, e.UserID_Approval, f.Email ,e.Jenis_Approval "
    '        SQL = SQL & "from HRIS_Transaksi_Karyawan a, HRIS_Divisi_Sub_Divisi b, HRIS_Divisi c, HRIS_Sub_Divisi d, HRIS_UserID_Approval_Karyawan e, Karyawan f "
    '        SQL = SQL & "where a.ID_Divisi_Sub_Divisi=b.ID_Divisi_Sub_Divisi "
    '        SQL = SQL & "and b.ID_Divisi=c.ID_Divisi and b.ID_Sub_Divisi=d.ID_Sub_Divisi and a.Kode_Perusahaan=e.Kode_Perusahaan "
    '        SQL = SQL & "and a.ID_Level_Jabatan = e.ID_Level and c.ID_Divisi=e.ID_Divisi "
    '        SQL = SQL & "and e.Kode_Perusahaan=f.Kode_Perusahaan and e.UserID_Approval=f.UserID "
    '        SQL = SQL & "and a.no_faktur='" & arr(ComboBox1.SelectedIndex) & "'"
    '        Using Dr = OpenTrans(SQL)
    '            Do While Dr.Read
    '                Dim lv As ListViewItem
    '                lv = ListView1.Items.Add(Dr("UserID_Approval"))
    '                lv.SubItems.Add(Dr("Email"))
    '            Loop
    '        End Using

    '        CloseConn()
    '    Catch ex As Exception
    '        CloseConn()
    '        MessageBox.Show(ex.Message)
    '        Exit Sub
    '    End Try

    'End Sub
End Class