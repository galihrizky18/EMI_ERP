﻿Imports System.Drawing.Printing
Imports System.IO

Public Class EMI_Validasi_GR_Display

    Dim JudulForm As String = "Display Validasi Penerimaan Barang Hasil Produksi"

    Dim arrcari, arr_tgl, arr_Lain As New ArrayList

    Dim Lv_NoTransaksi, Lv_NoSplit, Lv_Tanggal, Lv_Jam, Lv_Keterangan, Lv_KdBarang, Lv_NmBarang, Lv_JmlhPO, Lv_JmlhValidasi, Lv_Satuan, Lv_User As String
    Dim LvDetail_NoTransaksi, LvDetail_LokasiTujuan, LvDetail_Barcode, LvDetail_Jenis, LvDetail_Jumlah, LvDetail_Satuan, LvDetail_Kualitas, LvDetail_Urut As String


    Private random As New Random()
    Private imageBytes1 As Byte = Nothing
    Private FileSize1 As UInt32
    Private rawData1() As Byte
    Private fs1 As FileStream


    Dim item_NoTransaksi As Integer = 0
    Dim item_NoSplit As Integer = 1
    Dim item_Tanggal As Integer = 2
    Dim item_Jam As Integer = 3
    Dim item_Keterangan As Integer = 4
    Dim item_KdBarang As Integer = 5
    Dim item_NmBarang As Integer = 6
    Dim item_JmlhPO As Integer = 7
    Dim item_JmlhValidasi As Integer = 8
    Dim item_Satuan As Integer = 9
    Dim item_User As Integer = 10


    Dim itemDetail_NoTransaksi As Integer = 0
    Dim itemDetail_LokasiTujuan As Integer = 1
    Dim itemDetail_Barode As Integer = 2
    Dim itemDetail_Jenis As Integer = 3
    Dim itemDetail_Jumlah As Integer = 4
    Dim itemDetail_Satuan As Integer = 5
    Dim itemDetail_Kualitas As Integer = 6
    Dim itemDetail_Urut As Integer = 7



    Private Sub EMI_Display_Validasi_GR_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Lv_Validation.Columns.Clear()
        Lv_Validation.Columns.Add("No Transaksi", 120, HorizontalAlignment.Left)
        Lv_Validation.Columns.Add("No Split", 120, HorizontalAlignment.Left)
        Lv_Validation.Columns.Add("Tanggal", 110, HorizontalAlignment.Center)
        Lv_Validation.Columns.Add("Jam", 90, HorizontalAlignment.Center)
        Lv_Validation.Columns.Add("Keterangan", 180, HorizontalAlignment.Left)
        Lv_Validation.Columns.Add("Kode Barang", 120, HorizontalAlignment.Left)
        Lv_Validation.Columns.Add("Nama Barang", 180, HorizontalAlignment.Left)
        Lv_Validation.Columns.Add("Jumlah PO", 0, HorizontalAlignment.Right)
        Lv_Validation.Columns.Add("Jumlah Validasi", 120, HorizontalAlignment.Right)
        Lv_Validation.Columns.Add("Satuan", 80, HorizontalAlignment.Center)
        Lv_Validation.Columns.Add("User", 100, HorizontalAlignment.Center)
        Lv_Validation.View = View.Details

        Lv_Detail.Columns.Clear()
        Lv_Detail.Columns.Add("No Transaksi", 0, HorizontalAlignment.Left)
        Lv_Detail.Columns.Add("Lokasi Tujuan", 110, HorizontalAlignment.Left)
        Lv_Detail.Columns.Add("Barcode", 180, HorizontalAlignment.Left)
        Lv_Detail.Columns.Add("Jenis", 120, HorizontalAlignment.Center)
        Lv_Detail.Columns.Add("Jumlah", 120, HorizontalAlignment.Right)
        Lv_Detail.Columns.Add("Satuan ", 80, HorizontalAlignment.Center)
        Lv_Detail.Columns.Add("Kualitas", 120, HorizontalAlignment.Center)
        Lv_Detail.Columns.Add("urut", 0, HorizontalAlignment.Center)
        Lv_Detail.View = View.Details

        Lv_Detail_Packaging.Columns.Clear()
        Lv_Detail_Packaging.Columns.Add("Lokasi", 100, HorizontalAlignment.Left)
        Lv_Detail_Packaging.Columns.Add("Kode Barang", 100, HorizontalAlignment.Left)
        Lv_Detail_Packaging.Columns.Add("Barang", 0, HorizontalAlignment.Left)
        Lv_Detail_Packaging.Columns.Add("Jumlah", 100, HorizontalAlignment.Right)
        Lv_Detail_Packaging.Columns.Add("Satuan", 80, HorizontalAlignment.Center)
        Lv_Detail_Packaging.View = View.Details


        arr_tgl.Clear() : Cmb_Tanggal.Items.Clear()
        Cmb_Tanggal.Items.Add("Tanggal Validasi") : arr_tgl.Add("a.Tanggal")

        arr_Lain.Clear() : Cmb_Lain.Items.Clear()
        Cmb_Lain.Items.Add("No Transaksi") : arr_Lain.Add("a.No_Transaksi")
        Cmb_Lain.Items.Add("No Split") : arr_Lain.Add("a.No_Production_Order")
        Cmb_Lain.Items.Add("Kode Barang") : arr_Lain.Add("b.Kode_Barang")
        Cmb_Lain.Items.Add("User") : arr_Lain.Add("a.UserID")

        Chk_HariIni.Focus()


        Kosong()
    End Sub

    Private Sub Kosong()


        Cmb_Tanggal.Enabled = False : DateTimePicker1.Enabled = False : DateTimePicker2.Enabled = False
        Cmb_Lain.Enabled = False : Txt_ValuLain.Enabled = False : Txt_ValuLain.Text = ""


        LoadDataValidation()



    End Sub


    Private Sub Get_Data_Validation(ByVal index As Integer)

        Lv_NoTransaksi = Lv_Validation.Items(index).SubItems(item_NoTransaksi).Text
        Lv_NoSplit = Lv_Validation.Items(index).SubItems(item_NoSplit).Text
        Lv_Tanggal = Lv_Validation.Items(index).SubItems(item_Tanggal).Text
        Lv_Jam = Lv_Validation.Items(index).SubItems(item_Jam).Text
        Lv_KdBarang = Lv_Validation.Items(index).SubItems(item_KdBarang).Text
        Lv_NmBarang = Lv_Validation.Items(index).SubItems(item_NmBarang).Text
        Lv_JmlhPO = Lv_Validation.Items(index).SubItems(item_JmlhPO).Text
        Lv_JmlhValidasi = Lv_Validation.Items(index).SubItems(item_JmlhValidasi).Text
        Lv_Satuan = Lv_Validation.Items(index).SubItems(item_Satuan).Text
        Lv_User = Lv_Validation.Items(index).SubItems(item_User).Text

    End Sub

    Private Sub Get_Data_ValidationDetail(ByVal index As Integer)

        LvDetail_NoTransaksi = Lv_Detail.Items(index).SubItems(itemDetail_NoTransaksi).Text
        LvDetail_LokasiTujuan = Lv_Detail.Items(index).SubItems(itemDetail_LokasiTujuan).Text
        LvDetail_Barcode = Lv_Detail.Items(index).SubItems(itemDetail_Barode).Text
        LvDetail_Jenis = Lv_Detail.Items(index).SubItems(itemDetail_Jenis).Text
        LvDetail_Jumlah = Lv_Detail.Items(index).SubItems(itemDetail_Jumlah).Text
        LvDetail_Satuan = Lv_Detail.Items(index).SubItems(itemDetail_Satuan).Text
        LvDetail_Kualitas = Lv_Detail.Items(index).SubItems(itemDetail_Kualitas).Text
        LvDetail_Urut = Lv_Detail.Items(index).SubItems(itemDetail_Urut).Text

    End Sub

    Private Sub LoadDataValidation()

        Try
            OpenConn()

            Lv_Validation.Items.Clear() : Lv_Detail.Items.Clear() : Lv_Detail_Packaging.Items.Clear()
            SQL = "select a.No_Transaksi, a.No_Production_Order, a.Tanggal, a.Jam, a.Keterangan, a.UserID, "
            SQL = SQL & "b.Kode_Stock_Owner, b.Kode_Barang, c.Nama as Nama_Barang, b.Jumlah as Jumlah_PO, b.Satuan, a.status, "
            SQL = SQL & "isnull(( (select sum(z.jumlah) from Emi_Production_Results_Validation_Detail z where z.Kode_Perusahaan = a.Kode_Perusahaan "
            SQL = SQL & "and a.No_Transaksi = z.No_Transaksi "
            SQL = SQL & "and z.Kode_Barang not in ( "
            SQL = SQL & "select distinct k.kode_barang_Scrap  "
            SQL = SQL & "from emi_binding_scrap k, barang l, barang_detail_satuan m "
            SQL = SQL & "where k.kode_Perusahaan=l.Kode_Perusahaan and k.Kode_Barang_scrap=l.Kode_Barang "
            SQL = SQL & "and l.kode_Perusahaan=m.Kode_Perusahaan and l.Kode_Barang=m.Kode_Barang "
            SQL = SQL & "and k.kode_perusahaan = a.Kode_perusahaan "
            SQL = SQL & "and l.kode_stock_Owner = b.Kode_Stock_Owner "
            SQL = SQL & "and m.flag_tampil_display = 'Y' "
            SQL = SQL & ")) + ( "
            SQL = SQL & "select ROUND(dbo.ubah_satuan(z.kode_perusahaan, 'masa', b.kode_barang, z.satuan, b.satuan, sum(z.jumlah)), 2) "
            SQL = SQL & "from Emi_Production_Results_Validation_Detail z "
            SQL = SQL & "where z.Kode_Perusahaan = a.Kode_Perusahaan "
            SQL = SQL & "and a.No_Transaksi = z.No_Transaksi "
            SQL = SQL & "and z.Kode_Barang in ( "
            SQL = SQL & "select distinct k.kode_barang_Scrap "
            SQL = SQL & "from emi_binding_scrap k, barang l, barang_detail_satuan m "
            SQL = SQL & "where k.kode_Perusahaan=l.Kode_Perusahaan and k.Kode_Barang_scrap=l.Kode_Barang "
            SQL = SQL & "and l.kode_Perusahaan=m.Kode_Perusahaan and l.Kode_Barang=m.Kode_Barang "
            SQL = SQL & "and k.kode_perusahaan = a.kode_perusahaan "
            SQL = SQL & "and l.kode_stock_Owner = b.Kode_Stock_Owner "
            SQL = SQL & "and m.flag_tampil_display = 'Y') group by z.kode_perusahaan, z.kode_barang, z.satuan ) ), 0) as Jumlah_Validasi "
            SQL = SQL & "from Emi_Production_Results_Validation a, Emi_Split_Production_Order b, barang c "
            SQL = SQL & "where a.kode_perusahaan = b.kode_perusahaan and b.Kode_Perusahaan = c.Kode_Perusahaan "
            SQL = SQL & "and a.no_production_order = b.No_Transaksi "
            SQL = SQL & "and b.Kode_Stock_Owner = c.Kode_Stock_Owner and b.Kode_Barang = c.Kode_Barang "

            If Chk_HariIni.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & "a.Tanggal between '"
                SQL = SQL & Format(CDate(FMenuDevFix.ToolStripStatusLabel3.Text), "yyyy-MM-dd") & "' and '" & Format(CDate(FMenuDevFix.ToolStripStatusLabel3.Text), "yyyy-MM-dd") & "' "
            End If

            If Chk_Tanggal.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & arr_tgl.Item(Cmb_Tanggal.SelectedIndex) & " between '"
                SQL = SQL & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "' and '" & Format(DateTimePicker2.Value, "yyyy-MM-dd") & "' "
            End If

            If Chk_Lain.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & arr_Lain.Item(Cmb_Lain.SelectedIndex) & " like '%" & Trim(Txt_ValuLain.Text) & "%' "
            End If

            SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by a.Tanggal, a.Jam "
            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then
                        For i As Integer = 0 To .Rows.Count - 1

                            Dim Lv As ListViewItem
                            Lv = Lv_Validation.Items.Add(.Rows(i).Item("No_Transaksi"))
                            Lv.SubItems.Add(.Rows(i).Item("No_Production_Order"))
                            Lv.SubItems.Add(Format(.Rows(i).Item("Tanggal"), "dd MMM yyyy"))
                            Lv.SubItems.Add(.Rows(i).Item("Jam"))
                            Lv.SubItems.Add(.Rows(i).Item("Keterangan"))
                            Lv.SubItems.Add(.Rows(i).Item("Kode_Barang"))
                            Lv.SubItems.Add(.Rows(i).Item("Nama_Barang"))
                            Lv.SubItems.Add(Format(.Rows(i).Item("Jumlah_PO"), "N2"))
                            Lv.SubItems.Add(Format(.Rows(i).Item("Jumlah_Validasi"), "N2"))
                            Lv.SubItems.Add(.Rows(i).Item("Satuan"))
                            Lv.SubItems.Add(.Rows(i).Item("UserID"))

                            If General_Class.CekNULL(.Rows(i).Item("status")) = "Y" Then
                                Lv.BackColor = Color.DarkRed
                                Lv.ForeColor = Color.White
                            End If

                        Next
                    End If
                End With
            End Using


            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Lv_Validation_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lv_Validation.SelectedIndexChanged
        If Lv_Validation.Items.Count = 0 Or Lv_Validation.FocusedItem Is Nothing Then Exit Sub

        Try
            OpenConn()

            Get_Data_Validation(Lv_Validation.FocusedItem.Index)



            Dim selectedSplit As String = Lv_Validation.FocusedItem.SubItems(item_NoSplit).Text
            Dim selectedFaktur As String = Lv_Validation.FocusedItem.SubItems(item_NoTransaksi).Text
            'Dim SelectedBarcode As String = Lv_Detail.FocusedItem.SubItems(itemDetail_Barode).Text

            Lv_Detail.Items.Clear() : Lv_Detail_Packaging.Items.Clear()
            SQL = "With cte As( "
            SQL = SQL & "select Distinct b.Kode_Perusahaan, b.no_Transaksi, b.No_Production_Order, c.Nomor, c.Kode_Barang, d.nama as Nama_Barang, c.Batch_Number, e.Qr_Code, e.Tgl_Produksi, c. Kode_Stock_Owner_Tujuan as Lokasi_Tujuan,  "
            SQL = SQL & "e.Tgl_Expired, c.Jumlah As jumlah, d.Satuan, "
            SQL = SQL & "case when c.jenis = 'REJECTED' then 'Disqualified ' else c.jenis end as Jenis, "
            SQL = SQL & "c.nomor as Number, "

            SQL = SQL & "e.Kode_Unik_Berjalan, f.Keterangan as Kualitas "

            SQL = SQL & "From Emi_Production_Results_Validation b, Emi_Production_Results_Validation_Detail c, Barang d, Barang_SN e, EMI_Master_Warna f "
            SQL = SQL & "Where b.Kode_Perusahaan = c.Kode_Perusahaan And c.Kode_Perusahaan = d.Kode_Perusahaan And b.Kode_Perusahaan = e.Kode_Perusahaan and c.Kode_Perusahaan = f.Kode_Perusahaan "
            SQL = SQL & "And b.No_Transaksi = c.No_Transaksi "
            SQL = SQL & "And c.Kode_Stock_Owner_Tujuan = d.Kode_Stock_Owner And c.Kode_Barang = d.Kode_Barang "
            SQL = SQL & "And c.Kode_Barang = e.Kode_Barang And c.Serial_Number_Tujuan=e.Serial_Number "
            SQL = SQL & "and c.Warna = f.Kode_Warna "
            SQL = SQL & "And b.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "And b.No_Production_Order = '" & selectedSplit & "' "
            SQL = SQL & "And b.No_Transaksi = '" & selectedFaktur & "'  and c.Jenis<>'Finished Good' "
            'SQL = SQL & "and (e.Qr_Code + '-' + e.Kode_Unik_Berjalan)  = '" & SelectedBarcode & "' "

            SQL = SQL & " union all "

            SQL = SQL & "select Distinct b.Kode_Perusahaan, b.no_Transaksi, b.No_Production_Order, c.Nomor, c.Kode_Barang, d.nama as Nama_Barang, c.Batch_Number, e.Qr_Code, e.Tgl_Produksi, c. Kode_Stock_Owner_Tujuan as Lokasi_Tujuan, "
            SQL = SQL & "e.Tgl_Expired, c.Jumlah As jumlah, d.Satuan, "
            SQL = SQL & "case when c.jenis = 'REJECTED' then 'Disqualified ' else c.jenis end as Jenis, "
            SQL = SQL & "c.nomor as Number, "

            SQL = SQL & "e.Kode_Unik_Berjalan, f.Keterangan as Kualitas "

            SQL = SQL & "From Emi_Production_Results_Validation b, Emi_Production_Results_Validation_Detail c, Barang d, Barang_SN_sementara e, EMI_Master_Warna f "
            SQL = SQL & "Where b.Kode_Perusahaan = c.Kode_Perusahaan And c.Kode_Perusahaan = d.Kode_Perusahaan And b.Kode_Perusahaan = e.Kode_Perusahaan and c.Kode_Perusahaan = f.Kode_Perusahaan "
            SQL = SQL & "And b.No_Transaksi = c.No_Transaksi "
            SQL = SQL & "And c.Kode_Stock_Owner_Tujuan = d.Kode_Stock_Owner And c.Kode_Barang = d.Kode_Barang "
            SQL = SQL & "And c.Kode_Barang = e.Kode_Barang And c.Serial_Number_Tujuan=e.Serial_Number "
            SQL = SQL & "and c.Warna = f.Kode_Warna "
            SQL = SQL & "And b.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "And b.No_Production_Order = '" & selectedSplit & "' "
            SQL = SQL & "And b.No_Transaksi = '" & selectedFaktur & "'  and c.Jenis='Finished Good' "
            'SQL = SQL & "and (e.Qr_Code + '-' + e.Kode_Unik_Berjalan)  = '" & SelectedBarcode & "' "

            SQL = SQL & ") select kode_perusahaan, no_production_order, no_Transaksi, Lokasi_Tujuan, Kode_Barang, Nama_Barang, Kode_Unik_Berjalan, Batch_Number, Qr_Code, Tgl_Produksi, Tgl_Expired, sum(Jumlah) as Jumlah, Satuan, Jenis, Number, Kualitas "
            SQL = SQL & "From cte "
            SQL = SQL & "Group By kode_perusahaan, no_production_order, no_Transaksi, Lokasi_Tujuan, Kode_Barang, Nama_Barang, Kode_Unik_Berjalan, Batch_Number, Qr_Code, Tgl_Produksi, Tgl_Expired, Satuan, Jenis, Number, Nomor, Kualitas "

            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim Lv As ListViewItem
                    Lv = Lv_Detail.Items.Add(Dr("No_Transaksi"))
                    Lv.SubItems.Add(Dr("Lokasi_Tujuan"))
                    Lv.SubItems.Add(Dr("Qr_Code") & "-" & Dr("Kode_Unik_Berjalan"))
                    Lv.SubItems.Add(Dr("Jenis"))
                    Lv.SubItems.Add(Format(Dr("Jumlah"), "N2"))
                    Lv.SubItems.Add(Dr("Satuan"))
                    Lv.SubItems.Add(If(General_Class.CekNULL(Dr("Kualitas")) = "", "-", Dr("Kualitas")))
                    Lv.SubItems.Add("X")
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Lv_Detail_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lv_Detail.SelectedIndexChanged
        If Lv_Detail.Items.Count = 0 Or Lv_Detail.FocusedItem Is Nothing Then Exit Sub

        Try
            OpenConn()

            Get_Data_ValidationDetail(Lv_Detail.FocusedItem.Index)

            Lv_Detail_Packaging.Items.Clear()

            SQL = "select C.Kode_Stock_Owner, c.Kode_Barang, d.Nama as Nama_Barang, sum(c.Jumlah) as  Jumlah, c.Satuan "
            SQL = SQL & "from Emi_Production_Results_Validation a, Emi_Production_Results_Validation_Detail b, Emi_Production_Results_Validation_Packaging_Detail c, Barang_SN_sementara e, Barang d "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and b.kode_perusahaan = c.Kode_Perusahaan and b.Kode_Perusahaan = e.Kode_Perusahaan and c.Kode_Perusahaan = d.Kode_Perusahaan "
            SQL = SQL & "and a.No_Transaksi = b.No_Transaksi "
            SQL = SQL & "and b.No_Transaksi = c.No_Transaksi and b.Urut = c.Urut_Detail "
            SQL = SQL & "and b.Kode_Stock_Owner_Tujuan = e.Kode_Stock_Owner and b.Kode_Barang = e.Kode_Barang and b.Serial_Number_Tujuan = e.Serial_Number "
            SQL = SQL & "and c.Kode_Stock_Owner= d.Kode_Stock_Owner and c.Kode_Barang = d.Kode_Barang "
            SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.No_Transaksi = '" & LvDetail_NoTransaksi & "' "
            SQL = SQL & "and (e.Qr_Code + '-' + e.Kode_Unik_Berjalan) = '" & LvDetail_Barcode & "' "
            SQL = SQL & "group by c.Kode_Stock_Owner, c.Kode_Barang, d.Nama, c.Satuan "
            SQL = SQL & ""
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim Lv As ListViewItem
                    Lv = Lv_Detail_Packaging.Items.Add(Dr("Kode_Stock_Owner"))
                    Lv.SubItems.Add(Dr("Kode_Barang"))
                    Lv.SubItems.Add(Dr("Nama_Barang"))
                    Lv.SubItems.Add(Format(Dr("Jumlah"), "N2"))
                    Lv.SubItems.Add(Dr("Satuan"))
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub


    Private Sub Chk_HariIni_CheckedChanged(sender As Object, e As EventArgs) Handles Chk_HariIni.CheckedChanged
        If Chk_HariIni.Checked = True Then
            Chk_Tanggal.Checked = False
            Cmb_Tanggal.SelectedIndex = -1
            Cmb_Tanggal.Enabled = False
            DateTimePicker1.Enabled = False
            DateTimePicker2.Enabled = False
            DateTimePicker1.Value = Now
            DateTimePicker2.Value = Now

            If Chk_Lain.Checked Then
                If Cmb_Lain.SelectedIndex = -1 Then
                    MessageBox.Show("Pilih Dahulu FIlter", JudulForm)
                    Cmb_Lain.Focus() : Cmb_Lain.DroppedDown = True : Exit Sub
                ElseIf Txt_ValuLain.Text.Trim.Length = 0 Then
                    MessageBox.Show("Value FIlter Tidak Boleh Kosong", JudulForm)
                    Txt_ValuLain.Focus() : Exit Sub
                End If
            End If

            LoadDataValidation()
        End If
    End Sub

    Private Sub Chk_Tanggal_CheckedChanged(sender As Object, e As EventArgs) Handles Chk_Tanggal.CheckedChanged
        If Chk_Tanggal.Checked = True Then
            Chk_HariIni.Checked = False
            Cmb_Tanggal.Enabled = True
            Cmb_Tanggal.DroppedDown = True
            DateTimePicker1.Enabled = True
            DateTimePicker2.Enabled = True
        Else
            Cmb_Tanggal.SelectedIndex = -1
            Cmb_Tanggal.Enabled = False
            Cmb_Tanggal.DroppedDown = False
            DateTimePicker1.Enabled = False
            DateTimePicker2.Enabled = False
            DateTimePicker1.Value = Now
            DateTimePicker2.Value = Now
        End If
    End Sub

    Private Sub Chk_Lain_CheckedChanged(sender As Object, e As EventArgs) Handles Chk_Lain.CheckedChanged
        If Chk_Lain.Checked = True Then
            Cmb_Lain.Enabled = True
            Cmb_Lain.DroppedDown = True
            Txt_ValuLain.Enabled = True
        Else
            Cmb_Lain.Enabled = False
            Cmb_Lain.DroppedDown = False
            Txt_ValuLain.Enabled = False
            Cmb_Lain.SelectedIndex = -1
            Txt_ValuLain.Text = ""
        End If
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Btn_Cari.Click
        If Chk_Tanggal.Checked = False And Chk_Lain.Checked = False And Chk_HariIni.Checked = False Then
            MessageBox.Show("Pilih Dahulu Filter")
            Chk_Tanggal.Focus() : Exit Sub
        End If
        If Chk_Tanggal.Checked Then
            If Cmb_Tanggal.SelectedIndex = -1 Then
                MessageBox.Show("Pilih Dahulu Filter Tanggal", JudulForm)
                Cmb_Tanggal.Focus() : Cmb_Tanggal.DroppedDown = True : Exit Sub
            ElseIf DateTimePicker1.Value > DateTimePicker2.Value Then
                MessageBox.Show("Tanggal Awal dan Akhir tidak Boleh Sama", JudulForm)
                DateTimePicker1.Value = Now : DateTimePicker2.Value = Now
                Exit Sub
            End If
        End If
        If Chk_Lain.Checked Then
            If Cmb_Lain.SelectedIndex = -1 Then
                MessageBox.Show("Pilih Dahulu FIlter", JudulForm)
                Cmb_Lain.Focus() : Cmb_Lain.DroppedDown = True : Exit Sub
            ElseIf Txt_ValuLain.Text.Trim.Length = 0 Then
                MessageBox.Show("Value FIlter Tidak Boleh Kosong", JudulForm)
                Txt_ValuLain.Focus() : Exit Sub
            End If
        End If

        LoadDataValidation()
    End Sub

    Private Sub SalinNoTransaksiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalinNoTransaksiToolStripMenuItem.Click
        If Lv_Validation.Items.Count = 0 Or Lv_Validation.SelectedItems.Count = 0 Then
            MessageBox.Show("Pilih Dahulu No Transaksi yang Ingin Disalin!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If

        Clipboard.SetText(Lv_Validation.FocusedItem.Text)
    End Sub

    Private Sub CetakUlangBarcodeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CetakUlangBarcodeToolStripMenuItem.Click
        If Lv_Detail.Items.Count = 0 Or Lv_Detail.FocusedItem Is Nothing Then Exit Sub

        Dim SelectedTransaksi As String = Lv_Detail.FocusedItem.Text

        Dim kode_unik_print As String = ""

        Try
            OpenConn()
            Cmd.Transaction = Cn.BeginTransaction

            Dim selectedSplit As String = Lv_Validation.FocusedItem.SubItems(item_NoSplit).Text
            Dim selectedFaktur As String = Lv_Validation.FocusedItem.SubItems(item_NoTransaksi).Text
            Dim SelectedBarcode As String = Lv_Detail.FocusedItem.SubItems(itemDetail_Barode).Text

            SQL = "Truncate Table N_EMI_Barcode_Label_Barcode_GR_2"
            ExecuteTrans(SQL)


            SQL = "With cte As( "
            SQL = SQL & "select Distinct b.Kode_Perusahaan, b.no_Transaksi, b.No_Production_Order, c.Nomor, c.Kode_Barang, d.nama as Nama_Barang, c.Batch_Number, e.Qr_Code, e.Tgl_Produksi, c. Kode_Stock_Owner_Tujuan as Lokasi_Tujuan,  "
            SQL = SQL & "e.Tgl_Expired, c.Jumlah As jumlah, d.Satuan, "
            SQL = SQL & "case when c.jenis = 'REJECTED' then 'Disqualified ' else c.jenis end as Jenis, "
            SQL = SQL & "c.nomor as Number, "

            SQL = SQL & "e.Kode_Unik_Berjalan, f.Keterangan as Kualitas "

            SQL = SQL & "From Emi_Production_Results_Validation b, Emi_Production_Results_Validation_Detail c, Barang d, Barang_SN e, EMI_Master_Warna f "
            SQL = SQL & "Where b.Kode_Perusahaan = c.Kode_Perusahaan And c.Kode_Perusahaan = d.Kode_Perusahaan And b.Kode_Perusahaan = e.Kode_Perusahaan and c.Kode_Perusahaan = f.Kode_Perusahaan "
            SQL = SQL & "And b.No_Transaksi = c.No_Transaksi "
            SQL = SQL & "And c.Kode_Stock_Owner_Tujuan = d.Kode_Stock_Owner And c.Kode_Barang = d.Kode_Barang "
            SQL = SQL & "And c.Kode_Barang = e.Kode_Barang And c.Serial_Number_Tujuan=e.Serial_Number "
            SQL = SQL & "and c.Warna = f.Kode_Warna "
            SQL = SQL & "And b.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "And b.No_Production_Order = '" & selectedSplit & "' "
            SQL = SQL & "And b.No_Transaksi = '" & selectedFaktur & "'  and c.Jenis<>'Finished Good' "
            SQL = SQL & "and (e.Qr_Code + '-' + e.Kode_Unik_Berjalan) = '" & SelectedBarcode & "' "

            SQL = SQL & " union all "

            SQL = SQL & "select Distinct b.Kode_Perusahaan, b.no_Transaksi, b.No_Production_Order, c.Nomor, c.Kode_Barang, d.nama as Nama_Barang, c.Batch_Number, e.Qr_Code, e.Tgl_Produksi, c. Kode_Stock_Owner_Tujuan as Lokasi_Tujuan, "
            SQL = SQL & "e.Tgl_Expired, c.Jumlah As jumlah, d.Satuan, "
            SQL = SQL & "case when c.jenis = 'REJECTED' then 'Disqualified ' else c.jenis end as Jenis, "
            SQL = SQL & "c.nomor as Number, "

            SQL = SQL & "e.Kode_Unik_Berjalan, f.Keterangan as Kualitas "

            SQL = SQL & "From Emi_Production_Results_Validation b, Emi_Production_Results_Validation_Detail c, Barang d, Barang_SN_sementara e, EMI_Master_Warna f "
            SQL = SQL & "Where b.Kode_Perusahaan = c.Kode_Perusahaan And c.Kode_Perusahaan = d.Kode_Perusahaan And b.Kode_Perusahaan = e.Kode_Perusahaan and c.Kode_Perusahaan = f.Kode_Perusahaan "
            SQL = SQL & "And b.No_Transaksi = c.No_Transaksi "
            SQL = SQL & "And c.Kode_Stock_Owner_Tujuan = d.Kode_Stock_Owner And c.Kode_Barang = d.Kode_Barang "
            SQL = SQL & "And c.Kode_Barang = e.Kode_Barang And c.Serial_Number_Tujuan=e.Serial_Number "
            SQL = SQL & "and c.Warna = f.Kode_Warna "
            SQL = SQL & "And b.Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "And b.No_Production_Order = '" & selectedSplit & "' "
            SQL = SQL & "And b.No_Transaksi = '" & selectedFaktur & "'  and c.Jenis='Finished Good' "
            SQL = SQL & "and (e.Qr_Code + '-' + e.Kode_Unik_Berjalan) = '" & SelectedBarcode & "' "

            SQL = SQL & ") select kode_perusahaan, no_production_order, no_Transaksi, Lokasi_Tujuan, Kode_Barang, Nama_Barang, Kode_Unik_Berjalan, Batch_Number, Qr_Code, Tgl_Produksi, Tgl_Expired, sum(Jumlah) as Jumlah, Satuan, Jenis, Number, Kualitas "
            SQL = SQL & "From cte "
            SQL = SQL & "Group By kode_perusahaan, no_production_order, no_Transaksi, Lokasi_Tujuan, Kode_Barang, Nama_Barang, Kode_Unik_Berjalan, Batch_Number, Qr_Code, Tgl_Produksi, Tgl_Expired, Satuan, Jenis, Number, Nomor, Kualitas "
            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then
                        For i As Integer = 0 To .Rows.Count - 1

                            kode_unik_print = Format(tgl_skg, "MMddHHmmss") & Format(Random.Next(0, 10000), "00000")

                            Dim fullNewQrScrap As String = .Rows(i).Item("Qr_Code") & "-" & .Rows(i).Item("Kode_Unik_Berjalan")

                            Barcode.Image = Nothing

                            Barcode.Image = Generate_QR_NoPadding(fullNewQrScrap)

                            Dim FileToSaveAs1 As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp, "newBarcodeTfStock" & kode_unik_print & ".jpg")

                            '   Dim FileToSaveAs1 As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp, "newBarcodeFinishGood.jpg")

                            'If Not (System.IO.File.Exists(FileToSaveAs1)) Then
                            Barcode.Image.Save(FileToSaveAs1, System.Drawing.Imaging.ImageFormat.Jpeg)
                            'End If

                            fs1 = New FileStream(FileToSaveAs1, FileMode.Open, FileAccess.Read)
                            FileSize1 = fs1.Length
                            rawData1 = New Byte(FileSize1) {}
                            fs1.Read(rawData1, 0, FileSize1)
                            fs1.Close()
                            Cmd.Parameters.Add("@newBarcode" & kode_unik_print, SqlDbType.Image).Value = rawData1



                            SQL = "insert into N_EMI_Barcode_Label_Barcode_GR_2 (Kode_Perusahaan, No_Split, Kode_Barang, Barcode, Nama_Barang, Batch_Number, QrUtuh, Qr, Tgl_Produksi, Jam_Produksi, Tgl_Expired, Jam_Expired, Jumlah, Satuan, Jenis, Number, Kode_Unik_Print) "
                            SQL = SQL & "values ('" & KodePerusahaan & "', '" & .Rows(i).Item("no_production_order") & "', '" & .Rows(i).Item("Kode_Barang") & "', @newBarcode" & kode_unik_print & ", "
                            SQL = SQL & "'" & .Rows(i).Item("Nama_Barang") & "', '" & .Rows(i).Item("Batch_Number") & "', '" & fullNewQrScrap & "', '" & .Rows(i).Item("Qr_Code") & "', '" & .Rows(i).Item("Tgl_Produksi") & "', "
                            SQL = SQL & "'" & Format(tgl_skg, "HH:mm:ss") & "', '" & .Rows(i).Item("Tgl_Expired") & "', '" & Format(tgl_skg, "HH:mm:ss") & "', '" & .Rows(i).Item("Jumlah") & "', '" & .Rows(i).Item("Satuan") & "', "
                            SQL = SQL & "'" & .Rows(i).Item("Jenis") & "', '" & .Rows(i).Item("Number") & "', '" & kode_unik_print & "') "
                            ExecuteTrans(SQL)



                        Next
                    End If
                End With
            End Using





            Cmd.Transaction.Commit()
            CloseTrans()
            CloseConn()
        Catch ex As Exception
            CloseTrans()
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

        Try
            OpenConn()

            Dim CrDoc As New Object

            Dim KertasBesar As String = "BarcodeFG"
            Dim KertasKecil As String = "BarcodeQC"

            SQL = "select kode_perusahaan from N_EMI_Barcode_Label_Barcode_GR_2 where kode_perusahaan = '" & KodePerusahaan & "' and Kode_Unik_Print = '" & kode_unik_print & "'"
            Using Ds = BindingTrans(SQL)
                If Ds.Tables("MyTable").Rows.Count <> 0 Then

                    '==========================
                    '=     BARCODEE BESAR     =
                    '==========================
                    Dim printerDitemukan As Boolean = False
                    For Each printer As String In PrinterSettings.InstalledPrinters
                        If printer.ToLower() = PrinterBarcode.ToLower() Then
                            printerDitemukan = True
                            Exit For
                        End If
                    Next

                    If printerDitemukan Then

                        CrDoc = New N_EMI_Label_Barcode_GR_2

                        With A_Place_For_Printing2
                            CrDoc.SetDataSource(Ds)
                            CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                            CrDoc.PrintOptions.PrinterName = ""
                            CrDoc.RecordSelectionFormula = "{N_EMI_Barcode_Label_Barcode_GR_2.Kode_Perusahaan} = '" & KodePerusahaan & "'and {N_EMI_Barcode_Label_Barcode_GR_2.Kode_Unik_Print} = '" & kode_unik_print & "' "
                            CrDoc.SummaryInfo.ReportTitle = "Label Good Received 2"
                            .Text = "Label Good Received 2"
                            .CrystalReportViewer1.ReportSource = CrDoc
                            .Refresh()
                            .Show()
                        End With

                        '=====================================================

                        '    Dim doctoprint As New System.Drawing.Printing.PrintDocument()
                        '    CrDoc.SetDataSource(Ds)
                        '    CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                        '    CrDoc.RecordSelectionFormula = "{N_EMI_Barcode_Label_Barcode_GR_2.Kode_Perusahaan} = '" & KodePerusahaan & "'and {N_EMI_Barcode_Label_Barcode_GR_2.Kode_Unik_Print} = '" & Kkode_unik_print & "' "
                        '    CrDoc.PrintOptions.PrinterName = PrinterBarcode

                        '    doctoprint.PrinterSettings.PrinterName = PrinterBarcode

                        '    Dim rawKind As Integer
                        '    Dim foundPaper As Boolean = False
                        '    CrDoc.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.DefaultPaperSize
                        '    For j = 0 To doctoprint.PrinterSettings.PaperSizes.Count - 1
                        '        If doctoprint.PrinterSettings.PaperSizes(j).PaperName = KertasBesar Then
                        '            rawKind = CInt(doctoprint.PrinterSettings.PaperSizes(j).GetType().GetField("kind", Reflection.BindingFlags.Instance Or Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes(j)))
                        '            CrDoc.PrintOptions.PaperSize = rawKind
                        '            foundPaper = True
                        '            Exit For
                        '        End If
                        '    Next

                        '    If Not foundPaper Then
                        '        CrDoc.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.DefaultPaperSize
                        '        MessageBox.Show("Kertas Tidak Ditemukan, Menggunakan Kertas Default", "Cetak Ulang Barcode", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                        '    End If

                        '    CrDoc.PrintToPrinter(1, False, 1, 2500)

                    Else
                        MessageBox.Show("Printer FG Tidak ditemukan", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    End If

                    printerDitemukan = False


                Else
                    MessageBox.Show("Printer Q Tidak ditemukan", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                End If


            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try



    End Sub

    Private Function Generate_QR_NoPadding(ByVal isi As String)

        Dim options As New ZXing.QrCode.QrCodeEncodingOptions()

        options.DisableECI = True
        options.CharacterSet = "UTF-8"
        options.Width = 80
        options.Height = 80
        options.Margin = 0

        Dim qr As New ZXing.BarcodeWriter()
        qr.Format = ZXing.BarcodeFormat.QR_CODE
        qr.Options = options

        Dim result As New Bitmap(qr.Write(isi))
        Return result
    End Function



End Class