﻿Public Class Display_Summary_POInduk

    Dim arrFilterTanggal, arrFilterLain, arrFilterStatus As New ArrayList

    Dim Lv_NoFak, Lv_Supplier, Lv_PoCreated, Lv_PoReleased, Lv_ETD, Lv_StatusPO, Lv_UserID As String

    Dim item_NoFak As Integer = 0
    Dim item_Supplier As Integer = 1
    Dim item_PoCreated As Integer = 2
    Dim item_PoReleased As Integer = 3
    Dim item_ETD As Integer = 4
    Dim item_Status As Integer = 5
    Dim item_UserID As Integer = 6



    Private Sub Display_Laporan_PurchaseOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Kosong()
    End Sub

    Private Sub CetakUlangToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CetakUlangToolStripMenuItem.Click
        If Lv_PO.Items.Count = 0 Or Lv_PO.SelectedItems.Count = 0 Then
            Exit Sub
        End If

        Try
            OpenConn()

            '==================================
            '=     UPDATE JUMLAH CETAK PO     =
            '==================================
            SQL = "update EMI_Pembelian_PO_Induk set Jumlah_Print = isnull(Jumlah_Print,0) + 1 where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & Lv_PO.FocusedItem.Text & "'"
            ExecuteTrans(SQL)


            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try


        Try
            OpenConn()

            SQL = "select Kode_Perusahaan, No_Faktur from View_Laporan_PO2_Induk "
            SQL = SQL & "where Kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and No_Faktur = '" & Lv_PO.FocusedItem.Text & "' "

            Using Ds = BindingTrans(SQL)
                If Ds.Tables("MyTable").Rows.Count <> 0 Then
                    With Ds.Tables(0)
                        Dim CrDoc As New Faktur_Purchase_Order2_Induk
                        With A_Place_For_Printing2
                            CrDoc.SetDataSource(Ds)
                            CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                            CrDoc.SummaryInfo.ReportTitle = "Laporan Faktur Purchase Order"
                            CrDoc.RecordSelectionFormula = " {View_Laporan_PO2_Induk.Kode_Perusahaan} = '" & KodePerusahaan & "' and {View_Laporan_PO2_Induk.No_Faktur} = '" & Ds.Tables("MyTable").Rows(0).Item("No_Faktur") & "'"

                            .Text = "Laporan Faktur Purchase Order"
                            .CrystalReportViewer1.ReportSource = CrDoc
                            .CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                            .Refresh()
                            .Show()
                        End With
                    End With
                Else
                    MessageBox.Show("Data tidak ditemukan!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If

            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub Kosong()

        Try
            OpenConn()

            Base_Language.Get_Languages(Bahasa_Pilihan, "GLOBAL")
            Base_Language.Get_Languages(Bahasa_Pilihan, "Display_Barang_Masuk")
            Base_Language.Get_Languages(Bahasa_Pilihan, "Pembelian_Barang_Masuk")

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

        Lv_PO.Columns.Clear()
        Lv_PO.Columns.Add("No Faktur", 150, HorizontalAlignment.Left)
        Lv_PO.Columns.Add("Supplier", 230, HorizontalAlignment.Left)
        Lv_PO.Columns.Add("Po Created", 130, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("PO Released", 130, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("ETD", 130, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("Status PO", 140, HorizontalAlignment.Center)
        Lv_PO.Columns.Add("User Id", 150, HorizontalAlignment.Center)
        Lv_PO.View = View.Details


        Lv_PO_Detail.Columns.Clear()
        Lv_PO_Detail.Columns.Add(Base_Language.Lang_Global_KodeBarang, 110, HorizontalAlignment.Left) '
        Lv_PO_Detail.Columns.Add(Base_Language.Lang_Global_NamaBarang, 250, HorizontalAlignment.Left) '
        Lv_PO_Detail.Columns.Add(Base_Language.Lang_Global_Jumlah, 130, HorizontalAlignment.Right) '
        Lv_PO_Detail.Columns.Add("Jumlah PO", 130, HorizontalAlignment.Right)
        Lv_PO_Detail.Columns.Add("Sisa", 130, HorizontalAlignment.Right)
        Lv_PO_Detail.Columns.Add(Base_Language.Lang_Global_Satuan, 80, HorizontalAlignment.Center)
        Lv_PO_Detail.Columns.Add("%Complete", 130, HorizontalAlignment.Center)
        Lv_PO_Detail.Columns.Add(Base_Language.Lang_Global_Harga, 130, HorizontalAlignment.Right) '
        Lv_PO_Detail.View = View.Details

        Try
            OpenConn()

            Cmb_Lokasi.Items.Clear()

            Cmb_Lokasi.Items.Add(Base_Language.Lang_Global_SeluruhCombobox)
            SQL = "Select kode_stock_owner From "
            SQL = SQL & "stock_owner where kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by kode_stock_owner"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    Cmb_Lokasi.Items.Add(dr("kode_stock_owner"))
                Loop
                Cmb_Lokasi.Text = Lokasi
            End Using

            If CekButtonRole("Ganti_Lokasi_Display_Penjualan") = "T" Then
                Cmb_Lokasi.Enabled = False
            Else
                Cmb_Lokasi.Enabled = True
            End If


            Cmb_FIlter_Tanggal.Items.Clear() : arrFilterTanggal.Clear()
            Cmb_FIlter_Tanggal.Items.Add("Tanggal") : arrFilterTanggal.Add("a.Tanggal")
            Cmb_FIlter_Tanggal.Items.Add("Tanggal Release") : arrFilterTanggal.Add("a.tanggal_release")
            Cmb_FIlter_Tanggal.Items.Add("Tanggal Keberangkatan") : arrFilterTanggal.Add("a.ETD_Simulasi")

            Cmb_FIlter_Tanggal.Enabled = False : Cmb_Filter_Lain.Enabled = False
            DateTimePicker1.Enabled = False : DateTimePicker2.Enabled = False
            Txt_Filter_Lain.Enabled = False : Cmb_Filter_Status.Enabled = False

            Cmb_Filter_Lain.Items.Clear() : Cmb_Filter_Lain.Text = "" : arrFilterLain.Clear()
            Cmb_Filter_Lain.Items.Add("No Faktur") : arrFilterLain.Add("a.no_faktur")
            Cmb_Filter_Lain.Items.Add("Supplier") : arrFilterLain.Add("b.Nama")
            Cmb_Filter_Lain.Items.Add("User ID") : arrFilterLain.Add("a.userid")


            Cmb_Filter_Status.Items.Clear() : Cmb_Filter_Status.Text = "" : arrFilterStatus.Clear()
            Cmb_Filter_Status.Items.Add("SUBMITTED") : arrFilterStatus.Add("a.Flag_Release = 'Y'")
            Cmb_Filter_Status.Items.Add("UNSUBMITTED") : arrFilterStatus.Add("a.Flag_Release is null")



            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Btn_Cari_Click(sender As Object, e As EventArgs) Handles Btn_Cari.Click

        Try
            OpenConn()

            Lv_PO.Items.Clear()
            Lv_PO_Detail.Items.Clear()

            SQL = "select a.No_Faktur,b.kode_supplier,b.Nama,a.tanggal,a.tanggal_release, a.ETD_Simulasi, a.userid, Flag_Release "
            SQL = SQL & "from EMI_Pembelian_PO_Induk a, Suppliers b  "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Kode_Supplier = b.Kode_Supplier "
            SQL = SQL & "and a.Status is null "

            If Chk_Status.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & arrFilterStatus(Cmb_Filter_Status.SelectedIndex) & " "
            End If

            If Chk1.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & " a.tanggal between '"
                SQL = SQL & Format(Now, "yyyy-MM-dd") & "' and '" & Format(Now, "yyyy-MM-dd") & "' "
            End If

            If Chk2.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & arrFilterTanggal.Item(Cmb_FIlter_Tanggal.SelectedIndex) & " between '"
                SQL = SQL & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "' and '" & Format(DateTimePicker2.Value, "yyyy-MM-dd") & "' "
            End If

            If Chk3.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & arrFilterLain.Item(Cmb_Filter_Lain.SelectedIndex) & " like '%" & Trim(Txt_Filter_Lain.Text) & "%' "
            End If


            If Cmb_Lokasi.SelectedIndex = 0 Then
                SQL = SQL & " and a.Lokasi in("
                Dim list_kota As String = ""
                For x As Integer = 1 To Cmb_Lokasi.Items.Count - 1
                    list_kota = list_kota & "'" & Cmb_Lokasi.Items(x).ToString & "', "
                Next

                list_kota = Strings.Left(list_kota, Len(list_kota) - 2)

                SQL = SQL & list_kota & ")"
            Else
                SQL = SQL & " and a.Lokasi = '" & Cmb_Lokasi.Text & "' "
            End If

            SQL = SQL & "order by a.tanggal , a.jam"
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim Lv As ListViewItem
                    Lv = Lv_PO.Items.Add(Dr("No_Faktur"))
                    Lv.SubItems.Add(Dr("Nama"))
                    Lv.SubItems.Add(Format(Dr("tanggal"), "dd MMM yyyy"))
                    Lv.SubItems.Add(Format(Dr("tanggal_release"), "dd MMM yyyy"))
                    Lv.SubItems.Add(Format(Dr("ETD_Simulasi"), "dd MMM yyyy"))

                    If General_Class.CekNULL(Dr("Flag_release")) = "Y" Then
                        Lv.SubItems.Add("SUBMITTED")
                    Else
                        Lv.SubItems.Add("UNSUBMITTED")
                    End If

                    Lv.SubItems.Add(Dr("userid"))

                Loop
            End Using


            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try


    End Sub


    Private Sub Lv_PO_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lv_PO.SelectedIndexChanged

        If Lv_PO.Items.Count = 0 Then Exit Sub

        Try
            OpenConn()

            GetDataPO(Lv_PO.FocusedItem.Index)


            Lv_PO_Detail.Items.Clear()
            SQL = "SELECT a.kode_stock_owner, a.Kode_Barang, b.Nama, a.harga, a.jumlah, a.Satuan, "

            SQL = SQL & "ISNULL(( "
            SQL = SQL & "SELECT SUM(x.Jumlah) "
            SQL = SQL & "FROM EMI_Pembelian_PO z, EMI_Pembelian_PO_Detail x "
            SQL = SQL & "WHERE a.Kode_Perusahaan = z.Kode_Perusahaan and z.Kode_Perusahaan = x.Kode_Perusahaan "
            SQL = SQL & "AND a.No_Faktur = z.No_Faktur_Induk "
            SQL = SQL & "and z.No_Faktur = x.No_Faktur "
            SQL = SQL & "AND a.Kode_Stock_Owner = x.Kode_Stock_Owner AND a.Kode_Barang = x.Kode_Barang and z.status is null "
            SQL = SQL & "GROUP BY z.Kode_Perusahaan, x.Kode_Barang, x.Satuan_Barang "
            SQL = SQL & "), 0) AS jumlah_masuk, "

            SQL = SQL & "(a.jumlah - ISNULL(( "
            SQL = SQL & "SELECT SUM(x.Jumlah) "
            SQL = SQL & "FROM EMI_Pembelian_PO z, EMI_Pembelian_PO_Detail x "
            SQL = SQL & "WHERE a.Kode_Perusahaan = z.Kode_Perusahaan and z.Kode_Perusahaan = x.Kode_Perusahaan "
            SQL = SQL & "AND a.No_Faktur = z.No_Faktur_Induk  "
            SQL = SQL & "and z.No_Faktur = x.No_Faktur "
            SQL = SQL & "AND a.Kode_Stock_Owner = x.Kode_Stock_Owner AND a.Kode_Barang = x.Kode_Barang and z.status is null "
            SQL = SQL & "GROUP BY z.Kode_Perusahaan, x.Kode_Barang, x.Satuan_Barang "
            SQL = SQL & "), 0)) AS sisa, "

            SQL = SQL & "CASE "
            SQL = SQL & "WHEN ISNULL(( "
            SQL = SQL & "SELECT SUM(x.Jumlah) "
            SQL = SQL & "FROM EMI_Pembelian_PO z, EMI_Pembelian_PO_Detail x "
            SQL = SQL & "WHERE a.Kode_Perusahaan = z.Kode_Perusahaan and z.Kode_Perusahaan = x.Kode_Perusahaan "
            SQL = SQL & "AND a.No_Faktur = z.No_Faktur_Induk  "
            SQL = SQL & "and z.No_Faktur = x.No_Faktur "
            SQL = SQL & "AND a.Kode_Stock_Owner = x.Kode_Stock_Owner AND a.Kode_Barang = x.Kode_Barang "
            SQL = SQL & "GROUP BY z.Kode_Perusahaan, x.Kode_Barang, x.Satuan_Barang "
            SQL = SQL & "), 0) = 0 THEN 0 "
            SQL = SQL & "ELSE ROUND(( "
            SQL = SQL & "(ISNULL(( "
            SQL = SQL & "SELECT SUM(x.Jumlah) "
            SQL = SQL & "FROM EMI_Pembelian_PO z, EMI_Pembelian_PO_Detail x "
            SQL = SQL & "WHERE a.Kode_Perusahaan = z.Kode_Perusahaan and z.Kode_Perusahaan = x.Kode_Perusahaan "
            SQL = SQL & "AND a.No_Faktur = z.No_Faktur_Induk  "
            SQL = SQL & "and z.No_Faktur = x.No_Faktur "
            SQL = SQL & "AND a.Kode_Stock_Owner = x.Kode_Stock_Owner AND a.Kode_Barang = x.Kode_Barang "
            SQL = SQL & "GROUP BY z.Kode_Perusahaan, x.Kode_Barang, x.Satuan_Barang "
            SQL = SQL & "), 0))/a.jumlah  * 100 ), 2) END AS percentComplete "

            SQL = SQL & "FROM EMI_Pembelian_PO_Detail_Induk a, barang b "
            SQL = SQL & "WHERE a.Kode_Perusahaan = b.Kode_Perusahaan  "
            SQL = SQL & "AND a.Kode_Stock_Owner = b.Kode_Stock_Owner  "
            SQL = SQL & "AND a.Kode_Barang = b.Kode_Barang  "
            SQL = SQL & "and a.kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.no_faktur = '" & Lv_NoFak & "' "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim lvw As ListViewItem
                    lvw = Lv_PO_Detail.Items.Add(Dr("kode_barang"))
                    lvw.SubItems.Add(Dr("nama"))
                    lvw.SubItems.Add(Format(Dr("jumlah"), "N0"))
                    lvw.SubItems.Add(Format(Dr("jumlah_masuk"), "N0"))
                    lvw.SubItems.Add(Format(Dr("sisa"), "N0"))
                    lvw.SubItems.Add(Dr("satuan"))
                    lvw.SubItems.Add(Format(Dr("percentComplete"), "N1") & " %")
                    lvw.SubItems.Add(Format(Dr("harga"), "N2"))
                Loop
            End Using
            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub


    Private Sub GetDataPO(ByVal index As Integer)
        Lv_NoFak = Lv_PO.Items(index).SubItems(item_NoFak).Text
        Lv_Supplier = Lv_PO.Items(index).SubItems(item_Supplier).Text
        Lv_PoCreated = Lv_PO.Items(index).SubItems(item_PoCreated).Text
        Lv_PoReleased = Lv_PO.Items(index).SubItems(item_PoReleased).Text
        Lv_ETD = Lv_PO.Items(index).SubItems(item_ETD).Text
        Lv_StatusPO = Lv_PO.Items(index).SubItems(item_Status).Text
        Lv_UserID = Lv_PO.Items(index).SubItems(item_UserID).Text
    End Sub
















    Private Sub Chk1_CheckedChanged(sender As Object, e As EventArgs) Handles Chk1.CheckedChanged
        If Chk1.Checked = True Then
            Chk2.Checked = False
            Btn_Cari_Click(Chk1, e)
        End If
    End Sub

    Private Sub Chk2_CheckedChanged(sender As Object, e As EventArgs) Handles Chk2.CheckedChanged
        If Chk2.Checked Then
            Cmb_FIlter_Tanggal.Enabled = True : DateTimePicker1.Enabled = True : DateTimePicker2.Enabled = True
            Chk1.Checked = False
        Else
            Cmb_FIlter_Tanggal.Enabled = False : DateTimePicker1.Enabled = False : DateTimePicker2.Enabled = False
            Cmb_FIlter_Tanggal.SelectedIndex = -1 : DateTimePicker1.Value = Now.Date : DateTimePicker2.Value = Now.Date
        End If
    End Sub

    Private Sub Chk3_CheckedChanged(sender As Object, e As EventArgs) Handles Chk3.CheckedChanged
        If Chk3.Checked Then
            Cmb_Filter_Lain.Enabled = True : Txt_Filter_Lain.Enabled = True
        Else
            Cmb_Filter_Lain.Enabled = False : Txt_Filter_Lain.Enabled = False
            Cmb_Filter_Lain.SelectedIndex = -1 : Txt_Filter_Lain.Text = ""
        End If
    End Sub

    Private Sub Chk_Status_CheckedChanged(sender As Object, e As EventArgs) Handles Chk_Status.CheckedChanged
        If Chk_Status.Checked Then
            Cmb_Filter_Status.Enabled = True
        Else
            Cmb_Filter_Status.Enabled = False
            Cmb_Filter_Status.SelectedIndex = -1
        End If
    End Sub


End Class