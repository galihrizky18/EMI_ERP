﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EMI_PO_Pembelian_Sub
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EMI_PO_Pembelian_Sub))
        Me.LblPO_TotalBiaya = New System.Windows.Forms.Label()
        Me.ket = New System.Windows.Forms.TextBox()
        Me.CmbPO_Lokasi = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.sat = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TxtPO_NmSupplier = New System.Windows.Forms.TextBox()
        Me.LblPO_NoPO = New System.Windows.Forms.Label()
        Me.DtpPO_ETD = New System.Windows.Forms.DateTimePicker()
        Me.LblPO_ETD = New System.Windows.Forms.Label()
        Me.TxtPO_NoPO = New System.Windows.Forms.TextBox()
        Me.btnRelease = New System.Windows.Forms.Button()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.LblPO_NoNota = New System.Windows.Forms.Label()
        Me.LblPO_Tgl = New System.Windows.Forms.Label()
        Me.TxtPO_NoNota = New System.Windows.Forms.TextBox()
        Me.DtpPO_Tgl = New System.Windows.Forms.DateTimePicker()
        Me.TxtPO_KdSupplier = New System.Windows.Forms.TextBox()
        Me.LblPO_Supplier = New System.Windows.Forms.Label()
        Me.CmbPO_MataUang = New System.Windows.Forms.ComboBox()
        Me.LblPO_MataUang = New System.Windows.Forms.Label()
        Me.DtpPO_TglBayar = New System.Windows.Forms.DateTimePicker()
        Me.CmbPO_JnsBayar = New System.Windows.Forms.ComboBox()
        Me.LblPO_Pembayaran = New System.Windows.Forms.Label()
        Me.LvSupplier = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TxtPPN = New System.Windows.Forms.TextBox()
        Me.discz = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ListView10 = New System.Windows.Forms.ListView()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Discx = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.LblPO_Judul = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PanelGradient1 = New ERP_EMI.CustomControl.PanelGradient()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.LblPO_satBarang = New System.Windows.Forms.Label()
        Me.TxtPO_SatuanBarang = New System.Windows.Forms.TextBox()
        Me.Groupbox = New System.Windows.Forms.GroupBox()
        Me.LvPO_DataPO = New System.Windows.Forms.DataGridView()
        Me.lokasi = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.kode_barang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.nama_barang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.harga = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.jumlah_po = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.sisa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Jumlah = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Satuan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Harga_SB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Jumlah_SB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Satuan_SB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.No_PEnawaran = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.urut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NoPR = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TempoBayar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.jatuhTempo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.noFakPenawaran = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.HapusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtJatuhTempo = New System.Windows.Forms.TextBox()
        Me.Txt_GrandPPH = New System.Windows.Forms.TextBox()
        Me.cmbJenisPengiriman = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSatuanSisa = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtSisaPr = New System.Windows.Forms.TextBox()
        Me.cmb_pr = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Lbl_BiayaEkspedisi = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Txt_BiayaEkspedisi = New System.Windows.Forms.TextBox()
        Me.TxtPO_Berat = New System.Windows.Forms.TextBox()
        Me.LblPO_Berat = New System.Windows.Forms.Label()
        Me.TxtPO_Biaya = New System.Windows.Forms.TextBox()
        Me.LblPO_biaya = New System.Windows.Forms.Label()
        Me.CmbPO_JnsEkspedisi = New System.Windows.Forms.ComboBox()
        Me.LblPO_Ekspedisi = New System.Windows.Forms.Label()
        Me.CmbPO_Harga = New System.Windows.Forms.ComboBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.CmbPO_Satuan = New System.Windows.Forms.ComboBox()
        Me.Cmb_Ekspedisi = New System.Windows.Forms.ComboBox()
        Me.LblPO_Satuan = New System.Windows.Forms.Label()
        Me.LblPO_TotalMUA = New System.Windows.Forms.Label()
        Me.TxtPO_Total = New System.Windows.Forms.TextBox()
        Me.TxtPO_Kurs = New System.Windows.Forms.TextBox()
        Me.LblPO_Kurs = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.LblPO_TotalSblmPPN = New System.Windows.Forms.Label()
        Me.TxtPO_TotalSblmPPN = New System.Windows.Forms.TextBox()
        Me.ChkPO_PPN = New System.Windows.Forms.CheckBox()
        Me.TxtPO_PersenPPN = New System.Windows.Forms.TextBox()
        Me.LblPO_PPN = New System.Windows.Forms.Label()
        Me.TxtPO_NilaiPPN = New System.Windows.Forms.TextBox()
        Me.LblPO_CaraBayar = New System.Windows.Forms.Label()
        Me.CmbPO_CaraBayar = New System.Windows.Forms.ComboBox()
        Me.TxtPO_GrandTotal = New System.Windows.Forms.TextBox()
        Me.LblPO_GrandTotal = New System.Windows.Forms.Label()
        Me.TxtPO_NmBrg = New System.Windows.Forms.TextBox()
        Me.LblPO_Diskon = New System.Windows.Forms.Label()
        Me.LblPO_Jml = New System.Windows.Forms.Label()
        Me.LblPO_NmBarang = New System.Windows.Forms.Label()
        Me.LblPO_Hrg = New System.Windows.Forms.Label()
        Me.LblPO_KdBarang = New System.Windows.Forms.Label()
        Me.RdoPO_Persen = New System.Windows.Forms.RadioButton()
        Me.RdoPO_Rp = New System.Windows.Forms.RadioButton()
        Me.BtnPO_Clear = New System.Windows.Forms.Button()
        Me.TxtPO_KdBrg = New System.Windows.Forms.TextBox()
        Me.Btn_Ekspedisi = New System.Windows.Forms.Button()
        Me.BtnPO_Ok = New System.Windows.Forms.Button()
        Me.TxtPO_Diskon = New System.Windows.Forms.TextBox()
        Me.TxtPO_Jml = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnPO_Refresh = New System.Windows.Forms.Button()
        Me.BtnPO_Simpan = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.CmbPO_LokasiGudang = New System.Windows.Forms.ComboBox()
        Me.TxtPO_NoFaktur = New System.Windows.Forms.TextBox()
        Me.LvSupplier2 = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Txt_Faktur_Induk = New System.Windows.Forms.TextBox()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DtpPO_ETA = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Groupbox.SuspendLayout()
        CType(Me.LvPO_DataPO, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblPO_TotalBiaya
        '
        Me.LblPO_TotalBiaya.BackColor = System.Drawing.Color.Transparent
        Me.LblPO_TotalBiaya.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.0!, System.Drawing.FontStyle.Bold)
        Me.LblPO_TotalBiaya.ForeColor = System.Drawing.Color.Red
        Me.LblPO_TotalBiaya.Location = New System.Drawing.Point(979, 68)
        Me.LblPO_TotalBiaya.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblPO_TotalBiaya.Name = "LblPO_TotalBiaya"
        Me.LblPO_TotalBiaya.Size = New System.Drawing.Size(264, 52)
        Me.LblPO_TotalBiaya.TabIndex = 50
        Me.LblPO_TotalBiaya.Text = "0"
        Me.LblPO_TotalBiaya.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ket
        '
        Me.ket.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ket.Location = New System.Drawing.Point(420, 714)
        Me.ket.Margin = New System.Windows.Forms.Padding(2)
        Me.ket.MaxLength = 100
        Me.ket.Name = "ket"
        Me.ket.Size = New System.Drawing.Size(122, 19)
        Me.ket.TabIndex = 3
        Me.ket.Text = "Keterangan. . ."
        Me.ket.Visible = False
        '
        'CmbPO_Lokasi
        '
        Me.CmbPO_Lokasi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_Lokasi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.CmbPO_Lokasi.FormattingEnabled = True
        Me.CmbPO_Lokasi.Location = New System.Drawing.Point(482, 67)
        Me.CmbPO_Lokasi.Name = "CmbPO_Lokasi"
        Me.CmbPO_Lokasi.Size = New System.Drawing.Size(339, 23)
        Me.CmbPO_Lokasi.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1233, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 16)
        Me.Label1.TabIndex = 54
        Me.Label1.Text = "Label1x"
        Me.Label1.Visible = False
        '
        'ListView2
        '
        Me.ListView2.FullRowSelect = True
        Me.ListView2.GridLines = True
        Me.ListView2.HideSelection = False
        Me.ListView2.Location = New System.Drawing.Point(1750, 217)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(1052, 267)
        Me.ListView2.TabIndex = 59
        Me.ListView2.UseCompatibleStateImageBehavior = False
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(41, 704)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 25)
        Me.Label3.TabIndex = 217
        Me.Label3.Text = "Satuan"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label3.Visible = False
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(420, 729)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(122, 25)
        Me.Label7.TabIndex = 214
        Me.Label7.Text = "Keterangan"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label7.Visible = False
        '
        'sat
        '
        Me.sat.Enabled = False
        Me.sat.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sat.Location = New System.Drawing.Point(103, 704)
        Me.sat.Margin = New System.Windows.Forms.Padding(2)
        Me.sat.Name = "sat"
        Me.sat.Size = New System.Drawing.Size(55, 19)
        Me.sat.TabIndex = 6
        Me.sat.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DtpPO_ETA)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.TxtPO_NmSupplier)
        Me.GroupBox1.Controls.Add(Me.LblPO_NoPO)
        Me.GroupBox1.Controls.Add(Me.DtpPO_ETD)
        Me.GroupBox1.Controls.Add(Me.LblPO_ETD)
        Me.GroupBox1.Controls.Add(Me.TxtPO_NoPO)
        Me.GroupBox1.Controls.Add(Me.btnRelease)
        Me.GroupBox1.Controls.Add(Me.TextBox9)
        Me.GroupBox1.Controls.Add(Me.LblPO_NoNota)
        Me.GroupBox1.Controls.Add(Me.LblPO_Tgl)
        Me.GroupBox1.Controls.Add(Me.TxtPO_NoNota)
        Me.GroupBox1.Controls.Add(Me.DtpPO_Tgl)
        Me.GroupBox1.Controls.Add(Me.TxtPO_KdSupplier)
        Me.GroupBox1.Controls.Add(Me.LblPO_Supplier)
        Me.GroupBox1.Controls.Add(Me.LblPO_TotalBiaya)
        Me.GroupBox1.Controls.Add(Me.CmbPO_MataUang)
        Me.GroupBox1.Controls.Add(Me.LblPO_MataUang)
        Me.GroupBox1.Location = New System.Drawing.Point(19, 92)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1280, 122)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(580, 63)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 24)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Pilih Data"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TxtPO_NmSupplier
        '
        Me.TxtPO_NmSupplier.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_NmSupplier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_NmSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_NmSupplier.Location = New System.Drawing.Point(306, 66)
        Me.TxtPO_NmSupplier.MaxLength = 30
        Me.TxtPO_NmSupplier.Name = "TxtPO_NmSupplier"
        Me.TxtPO_NmSupplier.Size = New System.Drawing.Size(269, 21)
        Me.TxtPO_NmSupplier.TabIndex = 1
        '
        'LblPO_NoPO
        '
        Me.LblPO_NoPO.AutoSize = True
        Me.LblPO_NoPO.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_NoPO.Location = New System.Drawing.Point(986, 13)
        Me.LblPO_NoPO.Name = "LblPO_NoPO"
        Me.LblPO_NoPO.Size = New System.Drawing.Size(63, 17)
        Me.LblPO_NoPO.TabIndex = 316
        Me.LblPO_NoPO.Text = "No PO X"
        Me.LblPO_NoPO.Visible = False
        '
        'DtpPO_ETD
        '
        Me.DtpPO_ETD.CustomFormat = "dd MMMM yyyy"
        Me.DtpPO_ETD.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DtpPO_ETD.Location = New System.Drawing.Point(113, 38)
        Me.DtpPO_ETD.Margin = New System.Windows.Forms.Padding(2)
        Me.DtpPO_ETD.Name = "DtpPO_ETD"
        Me.DtpPO_ETD.Size = New System.Drawing.Size(192, 21)
        Me.DtpPO_ETD.TabIndex = 315
        '
        'LblPO_ETD
        '
        Me.LblPO_ETD.AutoSize = True
        Me.LblPO_ETD.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_ETD.Location = New System.Drawing.Point(4, 39)
        Me.LblPO_ETD.Name = "LblPO_ETD"
        Me.LblPO_ETD.Size = New System.Drawing.Size(42, 17)
        Me.LblPO_ETD.TabIndex = 314
        Me.LblPO_ETD.Text = "ETDx"
        '
        'TxtPO_NoPO
        '
        Me.TxtPO_NoPO.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_NoPO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_NoPO.Enabled = False
        Me.TxtPO_NoPO.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_NoPO.Location = New System.Drawing.Point(1058, 14)
        Me.TxtPO_NoPO.MaxLength = 75
        Me.TxtPO_NoPO.Name = "TxtPO_NoPO"
        Me.TxtPO_NoPO.ReadOnly = True
        Me.TxtPO_NoPO.Size = New System.Drawing.Size(185, 21)
        Me.TxtPO_NoPO.TabIndex = 313
        Me.TxtPO_NoPO.Visible = False
        '
        'btnRelease
        '
        Me.btnRelease.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnRelease.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnRelease.ForeColor = System.Drawing.Color.White
        Me.btnRelease.Location = New System.Drawing.Point(971, 39)
        Me.btnRelease.Margin = New System.Windows.Forms.Padding(2)
        Me.btnRelease.Name = "btnRelease"
        Me.btnRelease.Size = New System.Drawing.Size(83, 27)
        Me.btnRelease.TabIndex = 312
        Me.btnRelease.Text = "Cari POx"
        Me.btnRelease.UseVisualStyleBackColor = False
        Me.btnRelease.Visible = False
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox9.Enabled = False
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TextBox9.Location = New System.Drawing.Point(1059, 41)
        Me.TextBox9.MaxLength = 30
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(184, 21)
        Me.TextBox9.TabIndex = 295
        Me.TextBox9.Visible = False
        '
        'LblPO_NoNota
        '
        Me.LblPO_NoNota.AutoSize = True
        Me.LblPO_NoNota.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_NoNota.Location = New System.Drawing.Point(308, 14)
        Me.LblPO_NoNota.Name = "LblPO_NoNota"
        Me.LblPO_NoNota.Size = New System.Drawing.Size(82, 17)
        Me.LblPO_NoNota.TabIndex = 219
        Me.LblPO_NoNota.Text = "Keterangan"
        '
        'LblPO_Tgl
        '
        Me.LblPO_Tgl.AutoSize = True
        Me.LblPO_Tgl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Tgl.Location = New System.Drawing.Point(4, 13)
        Me.LblPO_Tgl.Name = "LblPO_Tgl"
        Me.LblPO_Tgl.Size = New System.Drawing.Size(66, 17)
        Me.LblPO_Tgl.TabIndex = 218
        Me.LblPO_Tgl.Text = "Tanggalx"
        '
        'TxtPO_NoNota
        '
        Me.TxtPO_NoNota.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_NoNota.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_NoNota.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_NoNota.Location = New System.Drawing.Point(396, 13)
        Me.TxtPO_NoNota.MaxLength = 75
        Me.TxtPO_NoNota.Name = "TxtPO_NoNota"
        Me.TxtPO_NoNota.Size = New System.Drawing.Size(192, 21)
        Me.TxtPO_NoNota.TabIndex = 2
        '
        'DtpPO_Tgl
        '
        Me.DtpPO_Tgl.CustomFormat = "dd MMMM yyyy"
        Me.DtpPO_Tgl.Enabled = False
        Me.DtpPO_Tgl.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DtpPO_Tgl.Location = New System.Drawing.Point(113, 13)
        Me.DtpPO_Tgl.Margin = New System.Windows.Forms.Padding(2)
        Me.DtpPO_Tgl.Name = "DtpPO_Tgl"
        Me.DtpPO_Tgl.Size = New System.Drawing.Size(192, 21)
        Me.DtpPO_Tgl.TabIndex = 0
        '
        'TxtPO_KdSupplier
        '
        Me.TxtPO_KdSupplier.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_KdSupplier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_KdSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_KdSupplier.Location = New System.Drawing.Point(113, 66)
        Me.TxtPO_KdSupplier.MaxLength = 30
        Me.TxtPO_KdSupplier.Name = "TxtPO_KdSupplier"
        Me.TxtPO_KdSupplier.Size = New System.Drawing.Size(192, 21)
        Me.TxtPO_KdSupplier.TabIndex = 0
        '
        'LblPO_Supplier
        '
        Me.LblPO_Supplier.AutoSize = True
        Me.LblPO_Supplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Supplier.Location = New System.Drawing.Point(5, 67)
        Me.LblPO_Supplier.Name = "LblPO_Supplier"
        Me.LblPO_Supplier.Size = New System.Drawing.Size(66, 17)
        Me.LblPO_Supplier.TabIndex = 215
        Me.LblPO_Supplier.Text = "Supplierx"
        '
        'CmbPO_MataUang
        '
        Me.CmbPO_MataUang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_MataUang.DropDownWidth = 150
        Me.CmbPO_MataUang.Enabled = False
        Me.CmbPO_MataUang.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.CmbPO_MataUang.FormattingEnabled = True
        Me.CmbPO_MataUang.Location = New System.Drawing.Point(113, 92)
        Me.CmbPO_MataUang.Margin = New System.Windows.Forms.Padding(2)
        Me.CmbPO_MataUang.Name = "CmbPO_MataUang"
        Me.CmbPO_MataUang.Size = New System.Drawing.Size(112, 23)
        Me.CmbPO_MataUang.TabIndex = 3
        '
        'LblPO_MataUang
        '
        Me.LblPO_MataUang.AutoSize = True
        Me.LblPO_MataUang.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_MataUang.Location = New System.Drawing.Point(4, 94)
        Me.LblPO_MataUang.Name = "LblPO_MataUang"
        Me.LblPO_MataUang.Size = New System.Drawing.Size(83, 17)
        Me.LblPO_MataUang.TabIndex = 334
        Me.LblPO_MataUang.Text = "Mata Uangx"
        '
        'DtpPO_TglBayar
        '
        Me.DtpPO_TglBayar.CustomFormat = "dd MMMM yyyy"
        Me.DtpPO_TglBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.DtpPO_TglBayar.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DtpPO_TglBayar.Location = New System.Drawing.Point(1321, 454)
        Me.DtpPO_TglBayar.Margin = New System.Windows.Forms.Padding(2)
        Me.DtpPO_TglBayar.Name = "DtpPO_TglBayar"
        Me.DtpPO_TglBayar.Size = New System.Drawing.Size(168, 21)
        Me.DtpPO_TglBayar.TabIndex = 6
        Me.DtpPO_TglBayar.Visible = False
        '
        'CmbPO_JnsBayar
        '
        Me.CmbPO_JnsBayar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_JnsBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.CmbPO_JnsBayar.FormattingEnabled = True
        Me.CmbPO_JnsBayar.Items.AddRange(New Object() {"Tunai", "Non-Tunai"})
        Me.CmbPO_JnsBayar.Location = New System.Drawing.Point(134, 285)
        Me.CmbPO_JnsBayar.Margin = New System.Windows.Forms.Padding(2)
        Me.CmbPO_JnsBayar.Name = "CmbPO_JnsBayar"
        Me.CmbPO_JnsBayar.Size = New System.Drawing.Size(192, 23)
        Me.CmbPO_JnsBayar.TabIndex = 1
        '
        'LblPO_Pembayaran
        '
        Me.LblPO_Pembayaran.AutoSize = True
        Me.LblPO_Pembayaran.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Pembayaran.Location = New System.Drawing.Point(5, 286)
        Me.LblPO_Pembayaran.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblPO_Pembayaran.Name = "LblPO_Pembayaran"
        Me.LblPO_Pembayaran.Size = New System.Drawing.Size(94, 17)
        Me.LblPO_Pembayaran.TabIndex = 213
        Me.LblPO_Pembayaran.Text = "Pembayaranx"
        '
        'LvSupplier
        '
        Me.LvSupplier.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.LvSupplier.FullRowSelect = True
        Me.LvSupplier.GridLines = True
        Me.LvSupplier.HideSelection = False
        Me.LvSupplier.Location = New System.Drawing.Point(1516, 267)
        Me.LvSupplier.Name = "LvSupplier"
        Me.LvSupplier.Size = New System.Drawing.Size(462, 150)
        Me.LvSupplier.TabIndex = 351
        Me.LvSupplier.UseCompatibleStateImageBehavior = False
        Me.LvSupplier.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Kode Supplier"
        Me.ColumnHeader1.Width = 102
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Nama"
        Me.ColumnHeader2.Width = 280
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Enabled = False
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(178, 708)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(32, 13)
        Me.Label17.TabIndex = 225
        Me.Label17.Text = "PPN"
        Me.Label17.Visible = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(1746, 115)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(49, 13)
        Me.Label19.TabIndex = 222
        Me.Label19.Text = "Disc(%)"
        Me.Label19.Visible = False
        '
        'TxtPPN
        '
        Me.TxtPPN.Enabled = False
        Me.TxtPPN.Location = New System.Drawing.Point(222, 719)
        Me.TxtPPN.Name = "TxtPPN"
        Me.TxtPPN.Size = New System.Drawing.Size(61, 21)
        Me.TxtPPN.TabIndex = 230
        Me.TxtPPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TxtPPN.Visible = False
        '
        'discz
        '
        Me.discz.Location = New System.Drawing.Point(1844, 113)
        Me.discz.Margin = New System.Windows.Forms.Padding(2)
        Me.discz.MaxLength = 5
        Me.discz.Name = "discz"
        Me.discz.Size = New System.Drawing.Size(73, 21)
        Me.discz.TabIndex = 231
        Me.discz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.discz.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(1919, 113)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(116, 21)
        Me.TextBox1.TabIndex = 234
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox1.Visible = False
        '
        'ListView10
        '
        Me.ListView10.FullRowSelect = True
        Me.ListView10.GridLines = True
        Me.ListView10.HideSelection = False
        Me.ListView10.Location = New System.Drawing.Point(289, 715)
        Me.ListView10.Name = "ListView10"
        Me.ListView10.Size = New System.Drawing.Size(966, 211)
        Me.ListView10.TabIndex = 235
        Me.ListView10.UseCompatibleStateImageBehavior = False
        Me.ListView10.View = System.Windows.Forms.View.Details
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(1821, 117)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox1.TabIndex = 237
        Me.CheckBox1.UseVisualStyleBackColor = True
        Me.CheckBox1.Visible = False
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(1821, 140)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox2.TabIndex = 238
        Me.CheckBox2.UseVisualStyleBackColor = True
        Me.CheckBox2.Visible = False
        '
        'Discx
        '
        Me.Discx.Location = New System.Drawing.Point(1844, 136)
        Me.Discx.Margin = New System.Windows.Forms.Padding(2)
        Me.Discx.MaxLength = 8
        Me.Discx.Name = "Discx"
        Me.Discx.Size = New System.Drawing.Size(191, 21)
        Me.Discx.TabIndex = 239
        Me.Discx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Discx.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(1746, 138)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 240
        Me.Label5.Text = "Disc(Rp.)"
        Me.Label5.Visible = False
        '
        'Label24
        '
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(289, 715)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(107, 25)
        Me.Label24.TabIndex = 250
        Me.Label24.Text = "Serial Number"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label24.Visible = False
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(289, 742)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(107, 19)
        Me.TextBox4.TabIndex = 2
        Me.TextBox4.Visible = False
        '
        'LblPO_Judul
        '
        Me.LblPO_Judul.AutoSize = True
        Me.LblPO_Judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPO_Judul.Location = New System.Drawing.Point(13, 9)
        Me.LblPO_Judul.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblPO_Judul.Name = "LblPO_Judul"
        Me.LblPO_Judul.Size = New System.Drawing.Size(216, 25)
        Me.LblPO_Judul.TabIndex = 0
        Me.LblPO_Judul.Text = "Sub PO Pembelian "
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.PanelGradient1)
        Me.Panel1.Controls.Add(Me.LblPO_Judul)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1314, 51)
        Me.Panel1.TabIndex = 1
        '
        'PanelGradient1
        '
        Me.PanelGradient1.cuteColor1 = System.Drawing.Color.FromArgb(CType(CType(95, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(185, Byte), Integer))
        Me.PanelGradient1.cuteColor2 = System.Drawing.Color.LightGreen
        Me.PanelGradient1.cuteTransparent1 = 100
        Me.PanelGradient1.cuteTransparent2 = 64
        Me.PanelGradient1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelGradient1.Location = New System.Drawing.Point(0, 49)
        Me.PanelGradient1.Margin = New System.Windows.Forms.Padding(1)
        Me.PanelGradient1.Name = "PanelGradient1"
        Me.PanelGradient1.Size = New System.Drawing.Size(1314, 2)
        Me.PanelGradient1.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Red
        Me.Panel5.Location = New System.Drawing.Point(16, 51)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1214, 12)
        Me.Panel5.TabIndex = 303
        Me.Panel5.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Red
        Me.Panel3.Location = New System.Drawing.Point(0, 51)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(16, 649)
        Me.Panel3.TabIndex = 304
        Me.Panel3.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Red
        Me.Panel2.Controls.Add(Me.LblPO_satBarang)
        Me.Panel2.Controls.Add(Me.TxtPO_SatuanBarang)
        Me.Panel2.Location = New System.Drawing.Point(1300, 67)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(16, 649)
        Me.Panel2.TabIndex = 305
        Me.Panel2.Visible = False
        '
        'LblPO_satBarang
        '
        Me.LblPO_satBarang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblPO_satBarang.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_satBarang.Location = New System.Drawing.Point(17, 180)
        Me.LblPO_satBarang.Name = "LblPO_satBarang"
        Me.LblPO_satBarang.Size = New System.Drawing.Size(115, 25)
        Me.LblPO_satBarang.TabIndex = 346
        Me.LblPO_satBarang.Text = "Satuan Barangx"
        Me.LblPO_satBarang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblPO_satBarang.Visible = False
        '
        'TxtPO_SatuanBarang
        '
        Me.TxtPO_SatuanBarang.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_SatuanBarang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_SatuanBarang.Enabled = False
        Me.TxtPO_SatuanBarang.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_SatuanBarang.Location = New System.Drawing.Point(17, 209)
        Me.TxtPO_SatuanBarang.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtPO_SatuanBarang.Name = "TxtPO_SatuanBarang"
        Me.TxtPO_SatuanBarang.Size = New System.Drawing.Size(115, 21)
        Me.TxtPO_SatuanBarang.TabIndex = 345
        Me.TxtPO_SatuanBarang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TxtPO_SatuanBarang.Visible = False
        '
        'Groupbox
        '
        Me.Groupbox.Controls.Add(Me.LvPO_DataPO)
        Me.Groupbox.Controls.Add(Me.Label8)
        Me.Groupbox.Controls.Add(Me.txtJatuhTempo)
        Me.Groupbox.Controls.Add(Me.Txt_GrandPPH)
        Me.Groupbox.Controls.Add(Me.cmbJenisPengiriman)
        Me.Groupbox.Controls.Add(Me.Label6)
        Me.Groupbox.Controls.Add(Me.txtSatuanSisa)
        Me.Groupbox.Controls.Add(Me.Label4)
        Me.Groupbox.Controls.Add(Me.txtSisaPr)
        Me.Groupbox.Controls.Add(Me.cmb_pr)
        Me.Groupbox.Controls.Add(Me.Label2)
        Me.Groupbox.Controls.Add(Me.Lbl_BiayaEkspedisi)
        Me.Groupbox.Controls.Add(Me.Label9)
        Me.Groupbox.Controls.Add(Me.Txt_BiayaEkspedisi)
        Me.Groupbox.Controls.Add(Me.TxtPO_Berat)
        Me.Groupbox.Controls.Add(Me.LblPO_Berat)
        Me.Groupbox.Controls.Add(Me.TxtPO_Biaya)
        Me.Groupbox.Controls.Add(Me.LblPO_biaya)
        Me.Groupbox.Controls.Add(Me.CmbPO_JnsEkspedisi)
        Me.Groupbox.Controls.Add(Me.LblPO_Ekspedisi)
        Me.Groupbox.Controls.Add(Me.CmbPO_Harga)
        Me.Groupbox.Controls.Add(Me.ListView1)
        Me.Groupbox.Controls.Add(Me.CmbPO_Satuan)
        Me.Groupbox.Controls.Add(Me.Cmb_Ekspedisi)
        Me.Groupbox.Controls.Add(Me.CmbPO_JnsBayar)
        Me.Groupbox.Controls.Add(Me.LblPO_Satuan)
        Me.Groupbox.Controls.Add(Me.LblPO_Pembayaran)
        Me.Groupbox.Controls.Add(Me.LblPO_TotalMUA)
        Me.Groupbox.Controls.Add(Me.TxtPO_Total)
        Me.Groupbox.Controls.Add(Me.TxtPO_Kurs)
        Me.Groupbox.Controls.Add(Me.LblPO_Kurs)
        Me.Groupbox.Controls.Add(Me.Label25)
        Me.Groupbox.Controls.Add(Me.LblPO_TotalSblmPPN)
        Me.Groupbox.Controls.Add(Me.TxtPO_TotalSblmPPN)
        Me.Groupbox.Controls.Add(Me.ChkPO_PPN)
        Me.Groupbox.Controls.Add(Me.TxtPO_PersenPPN)
        Me.Groupbox.Controls.Add(Me.LblPO_PPN)
        Me.Groupbox.Controls.Add(Me.TxtPO_NilaiPPN)
        Me.Groupbox.Controls.Add(Me.LblPO_CaraBayar)
        Me.Groupbox.Controls.Add(Me.CmbPO_CaraBayar)
        Me.Groupbox.Controls.Add(Me.TxtPO_GrandTotal)
        Me.Groupbox.Controls.Add(Me.LblPO_GrandTotal)
        Me.Groupbox.Controls.Add(Me.TxtPO_NmBrg)
        Me.Groupbox.Controls.Add(Me.LblPO_Diskon)
        Me.Groupbox.Controls.Add(Me.LblPO_Jml)
        Me.Groupbox.Controls.Add(Me.LblPO_NmBarang)
        Me.Groupbox.Controls.Add(Me.LblPO_Hrg)
        Me.Groupbox.Controls.Add(Me.LblPO_KdBarang)
        Me.Groupbox.Controls.Add(Me.RdoPO_Persen)
        Me.Groupbox.Controls.Add(Me.RdoPO_Rp)
        Me.Groupbox.Controls.Add(Me.BtnPO_Clear)
        Me.Groupbox.Controls.Add(Me.TxtPO_KdBrg)
        Me.Groupbox.Controls.Add(Me.Btn_Ekspedisi)
        Me.Groupbox.Controls.Add(Me.BtnPO_Ok)
        Me.Groupbox.Controls.Add(Me.TxtPO_Diskon)
        Me.Groupbox.Controls.Add(Me.TxtPO_Jml)
        Me.Groupbox.Location = New System.Drawing.Point(19, 215)
        Me.Groupbox.Name = "Groupbox"
        Me.Groupbox.Size = New System.Drawing.Size(1280, 432)
        Me.Groupbox.TabIndex = 1
        Me.Groupbox.TabStop = False
        '
        'LvPO_DataPO
        '
        Me.LvPO_DataPO.AllowUserToAddRows = False
        Me.LvPO_DataPO.AllowUserToDeleteRows = False
        Me.LvPO_DataPO.AllowUserToResizeColumns = False
        Me.LvPO_DataPO.AllowUserToResizeRows = False
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.LvPO_DataPO.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.LvPO_DataPO.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.LvPO_DataPO.BackgroundColor = System.Drawing.Color.White
        Me.LvPO_DataPO.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.LvPO_DataPO.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.LvPO_DataPO.ColumnHeadersHeight = 30
        Me.LvPO_DataPO.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.lokasi, Me.kode_barang, Me.nama_barang, Me.harga, Me.jumlah_po, Me.sisa, Me.Jumlah, Me.Satuan, Me.Harga_SB, Me.Jumlah_SB, Me.Satuan_SB, Me.No_PEnawaran, Me.ID, Me.Total, Me.urut, Me.NoPR, Me.TempoBayar, Me.jatuhTempo, Me.noFakPenawaran, Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8})
        Me.LvPO_DataPO.ContextMenuStrip = Me.ContextMenuStrip1
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.LvPO_DataPO.DefaultCellStyle = DataGridViewCellStyle18
        Me.LvPO_DataPO.Location = New System.Drawing.Point(2, 70)
        Me.LvPO_DataPO.MultiSelect = False
        Me.LvPO_DataPO.Name = "LvPO_DataPO"
        Me.LvPO_DataPO.RowHeadersWidth = 21
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.LvPO_DataPO.RowsDefaultCellStyle = DataGridViewCellStyle19
        Me.LvPO_DataPO.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.LvPO_DataPO.Size = New System.Drawing.Size(1272, 208)
        Me.LvPO_DataPO.TabIndex = 0
        '
        'lokasi
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.lokasi.DefaultCellStyle = DataGridViewCellStyle3
        Me.lokasi.HeaderText = "Lokasi"
        Me.lokasi.Name = "lokasi"
        Me.lokasi.ReadOnly = True
        Me.lokasi.Width = 130
        '
        'kode_barang
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.kode_barang.DefaultCellStyle = DataGridViewCellStyle4
        Me.kode_barang.HeaderText = "Kode Barang"
        Me.kode_barang.Name = "kode_barang"
        Me.kode_barang.ReadOnly = True
        Me.kode_barang.Width = 130
        '
        'nama_barang
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.nama_barang.DefaultCellStyle = DataGridViewCellStyle5
        Me.nama_barang.HeaderText = "Nama Barang"
        Me.nama_barang.Name = "nama_barang"
        Me.nama_barang.ReadOnly = True
        Me.nama_barang.Width = 200
        '
        'harga
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.harga.DefaultCellStyle = DataGridViewCellStyle6
        Me.harga.HeaderText = "Harga Input"
        Me.harga.Name = "harga"
        Me.harga.ReadOnly = True
        Me.harga.Visible = False
        Me.harga.Width = 130
        '
        'jumlah_po
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.jumlah_po.DefaultCellStyle = DataGridViewCellStyle7
        Me.jumlah_po.HeaderText = "Jumlah PO"
        Me.jumlah_po.Name = "jumlah_po"
        Me.jumlah_po.ReadOnly = True
        Me.jumlah_po.Visible = False
        Me.jumlah_po.Width = 120
        '
        'sisa
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.sisa.DefaultCellStyle = DataGridViewCellStyle8
        Me.sisa.HeaderText = "Sisa"
        Me.sisa.Name = "sisa"
        Me.sisa.ReadOnly = True
        Me.sisa.Visible = False
        Me.sisa.Width = 120
        '
        'Jumlah
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Jumlah.DefaultCellStyle = DataGridViewCellStyle9
        Me.Jumlah.HeaderText = "Jumlah"
        Me.Jumlah.Name = "Jumlah"
        Me.Jumlah.Width = 120
        '
        'Satuan
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Satuan.DefaultCellStyle = DataGridViewCellStyle10
        Me.Satuan.HeaderText = "Satuan Input"
        Me.Satuan.Name = "Satuan"
        Me.Satuan.ReadOnly = True
        Me.Satuan.Visible = False
        Me.Satuan.Width = 80
        '
        'Harga_SB
        '
        Me.Harga_SB.HeaderText = "Harga SB"
        Me.Harga_SB.Name = "Harga_SB"
        Me.Harga_SB.ReadOnly = True
        Me.Harga_SB.Visible = False
        '
        'Jumlah_SB
        '
        Me.Jumlah_SB.HeaderText = "Jumlah SB"
        Me.Jumlah_SB.Name = "Jumlah_SB"
        Me.Jumlah_SB.ReadOnly = True
        Me.Jumlah_SB.Visible = False
        '
        'Satuan_SB
        '
        Me.Satuan_SB.HeaderText = "Satuan SB"
        Me.Satuan_SB.Name = "Satuan_SB"
        Me.Satuan_SB.ReadOnly = True
        Me.Satuan_SB.Visible = False
        '
        'No_PEnawaran
        '
        Me.No_PEnawaran.HeaderText = "No Penawaran"
        Me.No_PEnawaran.Name = "No_PEnawaran"
        Me.No_PEnawaran.ReadOnly = True
        Me.No_PEnawaran.Visible = False
        Me.No_PEnawaran.Width = 150
        '
        'ID
        '
        Me.ID.HeaderText = "ID"
        Me.ID.Name = "ID"
        Me.ID.ReadOnly = True
        Me.ID.Visible = False
        '
        'Total
        '
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Total.DefaultCellStyle = DataGridViewCellStyle11
        Me.Total.HeaderText = "Total"
        Me.Total.Name = "Total"
        Me.Total.ReadOnly = True
        Me.Total.Width = 130
        '
        'urut
        '
        Me.urut.HeaderText = "Urut"
        Me.urut.Name = "urut"
        Me.urut.ReadOnly = True
        Me.urut.Visible = False
        '
        'NoPR
        '
        Me.NoPR.HeaderText = "NoPR"
        Me.NoPR.Name = "NoPR"
        Me.NoPR.ReadOnly = True
        Me.NoPR.Visible = False
        '
        'TempoBayar
        '
        Me.TempoBayar.HeaderText = "Tempo Pembayaran"
        Me.TempoBayar.Name = "TempoBayar"
        Me.TempoBayar.ReadOnly = True
        Me.TempoBayar.Visible = False
        '
        'jatuhTempo
        '
        Me.jatuhTempo.HeaderText = "Jatuh Tempo"
        Me.jatuhTempo.Name = "jatuhTempo"
        Me.jatuhTempo.ReadOnly = True
        Me.jatuhTempo.Visible = False
        '
        'noFakPenawaran
        '
        Me.noFakPenawaran.HeaderText = "Fak Penawaran"
        Me.noFakPenawaran.Name = "noFakPenawaran"
        Me.noFakPenawaran.ReadOnly = True
        Me.noFakPenawaran.Visible = False
        '
        'Column1
        '
        Me.Column1.HeaderText = "Faktur Induk"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 120
        '
        'Column2
        '
        Me.Column2.HeaderText = "urut_det"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Visible = False
        '
        'Column3
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column3.DefaultCellStyle = DataGridViewCellStyle12
        Me.Column3.HeaderText = "Jenis Kategori"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 150
        '
        'Column4
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column4.DefaultCellStyle = DataGridViewCellStyle13
        Me.Column4.HeaderText = "Jumlah PO"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 120
        '
        'Column5
        '
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column5.DefaultCellStyle = DataGridViewCellStyle14
        Me.Column5.HeaderText = "Satuan"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 80
        '
        'Column6
        '
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column6.DefaultCellStyle = DataGridViewCellStyle15
        Me.Column6.HeaderText = "Harga Penawaran"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Visible = False
        Me.Column6.Width = 130
        '
        'Column7
        '
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column7.DefaultCellStyle = DataGridViewCellStyle16
        Me.Column7.HeaderText = "Sisa"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 120
        '
        'Column8
        '
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column8.DefaultCellStyle = DataGridViewCellStyle17
        Me.Column8.HeaderText = "Harga"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.Width = 130
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HapusToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(109, 26)
        '
        'HapusToolStripMenuItem
        '
        Me.HapusToolStripMenuItem.Name = "HapusToolStripMenuItem"
        Me.HapusToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.HapusToolStripMenuItem.Text = "Hapus"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label8.Location = New System.Drawing.Point(944, 340)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 17)
        Me.Label8.TabIndex = 459
        Me.Label8.Text = "Grand PPH"
        '
        'txtJatuhTempo
        '
        Me.txtJatuhTempo.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtJatuhTempo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtJatuhTempo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.txtJatuhTempo.Location = New System.Drawing.Point(428, 286)
        Me.txtJatuhTempo.MaxLength = 30
        Me.txtJatuhTempo.Name = "txtJatuhTempo"
        Me.txtJatuhTempo.Size = New System.Drawing.Size(94, 21)
        Me.txtJatuhTempo.TabIndex = 361
        Me.txtJatuhTempo.Visible = False
        '
        'Txt_GrandPPH
        '
        Me.Txt_GrandPPH.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.Txt_GrandPPH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_GrandPPH.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.Txt_GrandPPH.Location = New System.Drawing.Point(1048, 338)
        Me.Txt_GrandPPH.Name = "Txt_GrandPPH"
        Me.Txt_GrandPPH.ReadOnly = True
        Me.Txt_GrandPPH.Size = New System.Drawing.Size(227, 21)
        Me.Txt_GrandPPH.TabIndex = 460
        Me.Txt_GrandPPH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmbJenisPengiriman
        '
        Me.cmbJenisPengiriman.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbJenisPengiriman.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.cmbJenisPengiriman.FormattingEnabled = True
        Me.cmbJenisPengiriman.Items.AddRange(New Object() {"Tunai", "Non-Tunai"})
        Me.cmbJenisPengiriman.Location = New System.Drawing.Point(329, 285)
        Me.cmbJenisPengiriman.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbJenisPengiriman.Name = "cmbJenisPengiriman"
        Me.cmbJenisPengiriman.Size = New System.Drawing.Size(94, 23)
        Me.cmbJenisPengiriman.TabIndex = 360
        Me.cmbJenisPengiriman.Visible = False
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label6.Location = New System.Drawing.Point(861, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(115, 25)
        Me.Label6.TabIndex = 359
        Me.Label6.Text = "Satuan Sisa"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtSatuanSisa
        '
        Me.txtSatuanSisa.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtSatuanSisa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSatuanSisa.Enabled = False
        Me.txtSatuanSisa.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSatuanSisa.Location = New System.Drawing.Point(861, 42)
        Me.txtSatuanSisa.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSatuanSisa.Name = "txtSatuanSisa"
        Me.txtSatuanSisa.Size = New System.Drawing.Size(115, 21)
        Me.txtSatuanSisa.TabIndex = 358
        Me.txtSatuanSisa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label4.Location = New System.Drawing.Point(743, 13)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 25)
        Me.Label4.TabIndex = 357
        Me.Label4.Text = "Sisa"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtSisaPr
        '
        Me.txtSisaPr.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtSisaPr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSisaPr.Enabled = False
        Me.txtSisaPr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSisaPr.Location = New System.Drawing.Point(743, 42)
        Me.txtSisaPr.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSisaPr.Name = "txtSisaPr"
        Me.txtSisaPr.ReadOnly = True
        Me.txtSisaPr.Size = New System.Drawing.Size(115, 21)
        Me.txtSisaPr.TabIndex = 356
        Me.txtSisaPr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmb_pr
        '
        Me.cmb_pr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_pr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cmb_pr.FormattingEnabled = True
        Me.cmb_pr.Location = New System.Drawing.Point(610, 41)
        Me.cmb_pr.Name = "cmb_pr"
        Me.cmb_pr.Size = New System.Drawing.Size(130, 23)
        Me.cmb_pr.TabIndex = 355
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label2.Location = New System.Drawing.Point(610, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(130, 25)
        Me.Label2.TabIndex = 354
        Me.Label2.Text = "PR"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Lbl_BiayaEkspedisi
        '
        Me.Lbl_BiayaEkspedisi.AutoSize = True
        Me.Lbl_BiayaEkspedisi.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Lbl_BiayaEkspedisi.Location = New System.Drawing.Point(6, 373)
        Me.Lbl_BiayaEkspedisi.Name = "Lbl_BiayaEkspedisi"
        Me.Lbl_BiayaEkspedisi.Size = New System.Drawing.Size(107, 17)
        Me.Lbl_BiayaEkspedisi.TabIndex = 353
        Me.Lbl_BiayaEkspedisi.Text = "Biaya Ekspedisi"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label9.Location = New System.Drawing.Point(6, 340)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 17)
        Me.Label9.TabIndex = 353
        Me.Label9.Text = "Expedisi"
        '
        'Txt_BiayaEkspedisi
        '
        Me.Txt_BiayaEkspedisi.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.Txt_BiayaEkspedisi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BiayaEkspedisi.Enabled = False
        Me.Txt_BiayaEkspedisi.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.Txt_BiayaEkspedisi.Location = New System.Drawing.Point(134, 369)
        Me.Txt_BiayaEkspedisi.MaxLength = 30
        Me.Txt_BiayaEkspedisi.Name = "Txt_BiayaEkspedisi"
        Me.Txt_BiayaEkspedisi.Size = New System.Drawing.Size(192, 21)
        Me.Txt_BiayaEkspedisi.TabIndex = 352
        Me.Txt_BiayaEkspedisi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtPO_Berat
        '
        Me.TxtPO_Berat.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_Berat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_Berat.Enabled = False
        Me.TxtPO_Berat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_Berat.Location = New System.Drawing.Point(134, 313)
        Me.TxtPO_Berat.MaxLength = 30
        Me.TxtPO_Berat.Name = "TxtPO_Berat"
        Me.TxtPO_Berat.Size = New System.Drawing.Size(192, 21)
        Me.TxtPO_Berat.TabIndex = 352
        Me.TxtPO_Berat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblPO_Berat
        '
        Me.LblPO_Berat.AutoSize = True
        Me.LblPO_Berat.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Berat.Location = New System.Drawing.Point(6, 313)
        Me.LblPO_Berat.Name = "LblPO_Berat"
        Me.LblPO_Berat.Size = New System.Drawing.Size(42, 17)
        Me.LblPO_Berat.TabIndex = 353
        Me.LblPO_Berat.Text = "Berat"
        '
        'TxtPO_Biaya
        '
        Me.TxtPO_Biaya.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_Biaya.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_Biaya.Enabled = False
        Me.TxtPO_Biaya.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_Biaya.Location = New System.Drawing.Point(809, 287)
        Me.TxtPO_Biaya.MaxLength = 30
        Me.TxtPO_Biaya.Name = "TxtPO_Biaya"
        Me.TxtPO_Biaya.Size = New System.Drawing.Size(58, 21)
        Me.TxtPO_Biaya.TabIndex = 314
        Me.TxtPO_Biaya.Visible = False
        '
        'LblPO_biaya
        '
        Me.LblPO_biaya.AutoSize = True
        Me.LblPO_biaya.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_biaya.Location = New System.Drawing.Point(758, 289)
        Me.LblPO_biaya.Name = "LblPO_biaya"
        Me.LblPO_biaya.Size = New System.Drawing.Size(49, 17)
        Me.LblPO_biaya.TabIndex = 315
        Me.LblPO_biaya.Text = "Biayax"
        Me.LblPO_biaya.Visible = False
        '
        'CmbPO_JnsEkspedisi
        '
        Me.CmbPO_JnsEkspedisi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_JnsEkspedisi.DropDownWidth = 150
        Me.CmbPO_JnsEkspedisi.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.CmbPO_JnsEkspedisi.FormattingEnabled = True
        Me.CmbPO_JnsEkspedisi.Location = New System.Drawing.Point(684, 287)
        Me.CmbPO_JnsEkspedisi.Margin = New System.Windows.Forms.Padding(2)
        Me.CmbPO_JnsEkspedisi.Name = "CmbPO_JnsEkspedisi"
        Me.CmbPO_JnsEkspedisi.Size = New System.Drawing.Size(58, 23)
        Me.CmbPO_JnsEkspedisi.TabIndex = 350
        Me.CmbPO_JnsEkspedisi.Visible = False
        '
        'LblPO_Ekspedisi
        '
        Me.LblPO_Ekspedisi.AutoSize = True
        Me.LblPO_Ekspedisi.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Ekspedisi.Location = New System.Drawing.Point(597, 289)
        Me.LblPO_Ekspedisi.Name = "LblPO_Ekspedisi"
        Me.LblPO_Ekspedisi.Size = New System.Drawing.Size(74, 17)
        Me.LblPO_Ekspedisi.TabIndex = 349
        Me.LblPO_Ekspedisi.Text = "Ekspedisix"
        Me.LblPO_Ekspedisi.Visible = False
        '
        'CmbPO_Harga
        '
        Me.CmbPO_Harga.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_Harga.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.CmbPO_Harga.FormattingEnabled = True
        Me.CmbPO_Harga.Location = New System.Drawing.Point(477, 41)
        Me.CmbPO_Harga.Name = "CmbPO_Harga"
        Me.CmbPO_Harga.Size = New System.Drawing.Size(130, 23)
        Me.CmbPO_Harga.TabIndex = 344
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.SystemColors.Window
        Me.ListView1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.ListView1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(1269, 66)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(471, 132)
        Me.ListView1.TabIndex = 343
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'CmbPO_Satuan
        '
        Me.CmbPO_Satuan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_Satuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.CmbPO_Satuan.FormattingEnabled = True
        Me.CmbPO_Satuan.Location = New System.Drawing.Point(1081, 41)
        Me.CmbPO_Satuan.Name = "CmbPO_Satuan"
        Me.CmbPO_Satuan.Size = New System.Drawing.Size(100, 23)
        Me.CmbPO_Satuan.TabIndex = 340
        '
        'Cmb_Ekspedisi
        '
        Me.Cmb_Ekspedisi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Ekspedisi.Enabled = False
        Me.Cmb_Ekspedisi.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.Cmb_Ekspedisi.FormattingEnabled = True
        Me.Cmb_Ekspedisi.Items.AddRange(New Object() {"Tunai", "Non-Tunai"})
        Me.Cmb_Ekspedisi.Location = New System.Drawing.Point(134, 340)
        Me.Cmb_Ekspedisi.Margin = New System.Windows.Forms.Padding(2)
        Me.Cmb_Ekspedisi.Name = "Cmb_Ekspedisi"
        Me.Cmb_Ekspedisi.Size = New System.Drawing.Size(192, 23)
        Me.Cmb_Ekspedisi.TabIndex = 2
        '
        'LblPO_Satuan
        '
        Me.LblPO_Satuan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblPO_Satuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Satuan.Location = New System.Drawing.Point(1081, 13)
        Me.LblPO_Satuan.Name = "LblPO_Satuan"
        Me.LblPO_Satuan.Size = New System.Drawing.Size(100, 25)
        Me.LblPO_Satuan.TabIndex = 342
        Me.LblPO_Satuan.Text = "Satuanx"
        Me.LblPO_Satuan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblPO_TotalMUA
        '
        Me.LblPO_TotalMUA.AutoSize = True
        Me.LblPO_TotalMUA.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_TotalMUA.Location = New System.Drawing.Point(945, 285)
        Me.LblPO_TotalMUA.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblPO_TotalMUA.Name = "LblPO_TotalMUA"
        Me.LblPO_TotalMUA.Size = New System.Drawing.Size(80, 17)
        Me.LblPO_TotalMUA.TabIndex = 341
        Me.LblPO_TotalMUA.Text = "Total MUAx"
        '
        'TxtPO_Total
        '
        Me.TxtPO_Total.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_Total.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_Total.Enabled = False
        Me.TxtPO_Total.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_Total.Location = New System.Drawing.Point(1047, 284)
        Me.TxtPO_Total.Name = "TxtPO_Total"
        Me.TxtPO_Total.Size = New System.Drawing.Size(228, 21)
        Me.TxtPO_Total.TabIndex = 340
        Me.TxtPO_Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtPO_Kurs
        '
        Me.TxtPO_Kurs.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_Kurs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_Kurs.Enabled = False
        Me.TxtPO_Kurs.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_Kurs.Location = New System.Drawing.Point(639, 441)
        Me.TxtPO_Kurs.MaxLength = 30
        Me.TxtPO_Kurs.Name = "TxtPO_Kurs"
        Me.TxtPO_Kurs.Size = New System.Drawing.Size(228, 21)
        Me.TxtPO_Kurs.TabIndex = 336
        Me.TxtPO_Kurs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TxtPO_Kurs.Visible = False
        '
        'LblPO_Kurs
        '
        Me.LblPO_Kurs.AutoSize = True
        Me.LblPO_Kurs.Enabled = False
        Me.LblPO_Kurs.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Kurs.Location = New System.Drawing.Point(552, 441)
        Me.LblPO_Kurs.Name = "LblPO_Kurs"
        Me.LblPO_Kurs.Size = New System.Drawing.Size(43, 17)
        Me.LblPO_Kurs.TabIndex = 337
        Me.LblPO_Kurs.Text = "Kursx"
        Me.LblPO_Kurs.Visible = False
        '
        'Label25
        '
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(687, 203)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(412, 25)
        Me.Label25.TabIndex = 333
        Me.Label25.Text = "Diskon per bahan baku jangan dipake lagi"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label25.Visible = False
        '
        'LblPO_TotalSblmPPN
        '
        Me.LblPO_TotalSblmPPN.AutoSize = True
        Me.LblPO_TotalSblmPPN.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_TotalSblmPPN.Location = New System.Drawing.Point(879, 311)
        Me.LblPO_TotalSblmPPN.Name = "LblPO_TotalSblmPPN"
        Me.LblPO_TotalSblmPPN.Size = New System.Drawing.Size(145, 17)
        Me.LblPO_TotalSblmPPN.TabIndex = 332
        Me.LblPO_TotalSblmPPN.Text = "Grand Sebelum PPNx"
        '
        'TxtPO_TotalSblmPPN
        '
        Me.TxtPO_TotalSblmPPN.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_TotalSblmPPN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_TotalSblmPPN.Enabled = False
        Me.TxtPO_TotalSblmPPN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_TotalSblmPPN.Location = New System.Drawing.Point(1047, 311)
        Me.TxtPO_TotalSblmPPN.Name = "TxtPO_TotalSblmPPN"
        Me.TxtPO_TotalSblmPPN.Size = New System.Drawing.Size(228, 21)
        Me.TxtPO_TotalSblmPPN.TabIndex = 331
        Me.TxtPO_TotalSblmPPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ChkPO_PPN
        '
        Me.ChkPO_PPN.AutoSize = True
        Me.ChkPO_PPN.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.ChkPO_PPN.Location = New System.Drawing.Point(948, 369)
        Me.ChkPO_PPN.Name = "ChkPO_PPN"
        Me.ChkPO_PPN.Size = New System.Drawing.Size(15, 14)
        Me.ChkPO_PPN.TabIndex = 330
        Me.ChkPO_PPN.UseVisualStyleBackColor = False
        Me.ChkPO_PPN.Visible = False
        '
        'TxtPO_PersenPPN
        '
        Me.TxtPO_PersenPPN.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_PersenPPN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_PersenPPN.Enabled = False
        Me.TxtPO_PersenPPN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_PersenPPN.Location = New System.Drawing.Point(1048, 365)
        Me.TxtPO_PersenPPN.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtPO_PersenPPN.MaxLength = 5
        Me.TxtPO_PersenPPN.Name = "TxtPO_PersenPPN"
        Me.TxtPO_PersenPPN.Size = New System.Drawing.Size(91, 21)
        Me.TxtPO_PersenPPN.TabIndex = 328
        Me.TxtPO_PersenPPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblPO_PPN
        '
        Me.LblPO_PPN.AutoSize = True
        Me.LblPO_PPN.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_PPN.Location = New System.Drawing.Point(981, 367)
        Me.LblPO_PPN.Name = "LblPO_PPN"
        Me.LblPO_PPN.Size = New System.Drawing.Size(42, 17)
        Me.LblPO_PPN.TabIndex = 327
        Me.LblPO_PPN.Text = "PPNx"
        '
        'TxtPO_NilaiPPN
        '
        Me.TxtPO_NilaiPPN.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_NilaiPPN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_NilaiPPN.Enabled = False
        Me.TxtPO_NilaiPPN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_NilaiPPN.Location = New System.Drawing.Point(1144, 365)
        Me.TxtPO_NilaiPPN.Name = "TxtPO_NilaiPPN"
        Me.TxtPO_NilaiPPN.Size = New System.Drawing.Size(130, 21)
        Me.TxtPO_NilaiPPN.TabIndex = 329
        Me.TxtPO_NilaiPPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblPO_CaraBayar
        '
        Me.LblPO_CaraBayar.AutoSize = True
        Me.LblPO_CaraBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_CaraBayar.Location = New System.Drawing.Point(596, 318)
        Me.LblPO_CaraBayar.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblPO_CaraBayar.Name = "LblPO_CaraBayar"
        Me.LblPO_CaraBayar.Size = New System.Drawing.Size(85, 17)
        Me.LblPO_CaraBayar.TabIndex = 326
        Me.LblPO_CaraBayar.Text = "Cara Bayarx"
        Me.LblPO_CaraBayar.Visible = False
        '
        'CmbPO_CaraBayar
        '
        Me.CmbPO_CaraBayar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_CaraBayar.DropDownWidth = 150
        Me.CmbPO_CaraBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.CmbPO_CaraBayar.FormattingEnabled = True
        Me.CmbPO_CaraBayar.Location = New System.Drawing.Point(684, 316)
        Me.CmbPO_CaraBayar.Margin = New System.Windows.Forms.Padding(2)
        Me.CmbPO_CaraBayar.Name = "CmbPO_CaraBayar"
        Me.CmbPO_CaraBayar.Size = New System.Drawing.Size(183, 23)
        Me.CmbPO_CaraBayar.TabIndex = 325
        Me.CmbPO_CaraBayar.Visible = False
        '
        'TxtPO_GrandTotal
        '
        Me.TxtPO_GrandTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_GrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_GrandTotal.Enabled = False
        Me.TxtPO_GrandTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TxtPO_GrandTotal.Location = New System.Drawing.Point(1046, 393)
        Me.TxtPO_GrandTotal.Name = "TxtPO_GrandTotal"
        Me.TxtPO_GrandTotal.Size = New System.Drawing.Size(228, 21)
        Me.TxtPO_GrandTotal.TabIndex = 321
        Me.TxtPO_GrandTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblPO_GrandTotal
        '
        Me.LblPO_GrandTotal.AutoSize = True
        Me.LblPO_GrandTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_GrandTotal.Location = New System.Drawing.Point(933, 394)
        Me.LblPO_GrandTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblPO_GrandTotal.Name = "LblPO_GrandTotal"
        Me.LblPO_GrandTotal.Size = New System.Drawing.Size(90, 17)
        Me.LblPO_GrandTotal.TabIndex = 319
        Me.LblPO_GrandTotal.Text = "Grand Totalx"
        '
        'TxtPO_NmBrg
        '
        Me.TxtPO_NmBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_NmBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_NmBrg.Enabled = False
        Me.TxtPO_NmBrg.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_NmBrg.Location = New System.Drawing.Point(156, 42)
        Me.TxtPO_NmBrg.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtPO_NmBrg.Name = "TxtPO_NmBrg"
        Me.TxtPO_NmBrg.Size = New System.Drawing.Size(318, 21)
        Me.TxtPO_NmBrg.TabIndex = 303
        '
        'LblPO_Diskon
        '
        Me.LblPO_Diskon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblPO_Diskon.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Diskon.Location = New System.Drawing.Point(409, 443)
        Me.LblPO_Diskon.Name = "LblPO_Diskon"
        Me.LblPO_Diskon.Size = New System.Drawing.Size(161, 25)
        Me.LblPO_Diskon.TabIndex = 317
        Me.LblPO_Diskon.Text = "Diskon"
        Me.LblPO_Diskon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblPO_Diskon.Visible = False
        '
        'LblPO_Jml
        '
        Me.LblPO_Jml.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblPO_Jml.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Jml.Location = New System.Drawing.Point(979, 13)
        Me.LblPO_Jml.Name = "LblPO_Jml"
        Me.LblPO_Jml.Size = New System.Drawing.Size(99, 25)
        Me.LblPO_Jml.TabIndex = 316
        Me.LblPO_Jml.Text = "Jumlahx"
        Me.LblPO_Jml.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblPO_NmBarang
        '
        Me.LblPO_NmBarang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblPO_NmBarang.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_NmBarang.Location = New System.Drawing.Point(156, 13)
        Me.LblPO_NmBarang.Name = "LblPO_NmBarang"
        Me.LblPO_NmBarang.Size = New System.Drawing.Size(318, 25)
        Me.LblPO_NmBarang.TabIndex = 314
        Me.LblPO_NmBarang.Text = "Nama Barangx"
        Me.LblPO_NmBarang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblPO_Hrg
        '
        Me.LblPO_Hrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblPO_Hrg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_Hrg.Location = New System.Drawing.Point(477, 13)
        Me.LblPO_Hrg.Name = "LblPO_Hrg"
        Me.LblPO_Hrg.Size = New System.Drawing.Size(130, 25)
        Me.LblPO_Hrg.TabIndex = 315
        Me.LblPO_Hrg.Text = "Hargax"
        Me.LblPO_Hrg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblPO_KdBarang
        '
        Me.LblPO_KdBarang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblPO_KdBarang.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.LblPO_KdBarang.Location = New System.Drawing.Point(3, 13)
        Me.LblPO_KdBarang.Name = "LblPO_KdBarang"
        Me.LblPO_KdBarang.Size = New System.Drawing.Size(150, 25)
        Me.LblPO_KdBarang.TabIndex = 313
        Me.LblPO_KdBarang.Text = "Kode Barangx"
        Me.LblPO_KdBarang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RdoPO_Persen
        '
        Me.RdoPO_Persen.AutoSize = True
        Me.RdoPO_Persen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.RdoPO_Persen.Location = New System.Drawing.Point(358, 442)
        Me.RdoPO_Persen.Margin = New System.Windows.Forms.Padding(2)
        Me.RdoPO_Persen.Name = "RdoPO_Persen"
        Me.RdoPO_Persen.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.RdoPO_Persen.Size = New System.Drawing.Size(33, 17)
        Me.RdoPO_Persen.TabIndex = 307
        Me.RdoPO_Persen.Text = "%"
        Me.RdoPO_Persen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RdoPO_Persen.UseVisualStyleBackColor = True
        Me.RdoPO_Persen.Visible = False
        '
        'RdoPO_Rp
        '
        Me.RdoPO_Rp.AutoSize = True
        Me.RdoPO_Rp.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.RdoPO_Rp.Location = New System.Drawing.Point(396, 442)
        Me.RdoPO_Rp.Margin = New System.Windows.Forms.Padding(2)
        Me.RdoPO_Rp.Name = "RdoPO_Rp"
        Me.RdoPO_Rp.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.RdoPO_Rp.Size = New System.Drawing.Size(43, 17)
        Me.RdoPO_Rp.TabIndex = 308
        Me.RdoPO_Rp.Text = ".RP"
        Me.RdoPO_Rp.UseVisualStyleBackColor = True
        Me.RdoPO_Rp.Visible = False
        '
        'BtnPO_Clear
        '
        Me.BtnPO_Clear.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.BtnPO_Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.BtnPO_Clear.ForeColor = System.Drawing.Color.White
        Me.BtnPO_Clear.Location = New System.Drawing.Point(1185, 10)
        Me.BtnPO_Clear.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnPO_Clear.Name = "BtnPO_Clear"
        Me.BtnPO_Clear.Size = New System.Drawing.Size(90, 28)
        Me.BtnPO_Clear.TabIndex = 312
        Me.BtnPO_Clear.Text = "Clearx"
        Me.BtnPO_Clear.UseVisualStyleBackColor = False
        '
        'TxtPO_KdBrg
        '
        Me.TxtPO_KdBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_KdBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_KdBrg.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_KdBrg.Location = New System.Drawing.Point(4, 42)
        Me.TxtPO_KdBrg.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtPO_KdBrg.Name = "TxtPO_KdBrg"
        Me.TxtPO_KdBrg.Size = New System.Drawing.Size(150, 21)
        Me.TxtPO_KdBrg.TabIndex = 0
        '
        'Btn_Ekspedisi
        '
        Me.Btn_Ekspedisi.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.Btn_Ekspedisi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_Ekspedisi.ForeColor = System.Drawing.Color.White
        Me.Btn_Ekspedisi.Location = New System.Drawing.Point(333, 336)
        Me.Btn_Ekspedisi.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Ekspedisi.Name = "Btn_Ekspedisi"
        Me.Btn_Ekspedisi.Size = New System.Drawing.Size(125, 28)
        Me.Btn_Ekspedisi.TabIndex = 311
        Me.Btn_Ekspedisi.Text = "Pilih Ekspedisi"
        Me.Btn_Ekspedisi.UseVisualStyleBackColor = False
        '
        'BtnPO_Ok
        '
        Me.BtnPO_Ok.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.BtnPO_Ok.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.BtnPO_Ok.ForeColor = System.Drawing.Color.White
        Me.BtnPO_Ok.Location = New System.Drawing.Point(1185, 37)
        Me.BtnPO_Ok.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnPO_Ok.Name = "BtnPO_Ok"
        Me.BtnPO_Ok.Size = New System.Drawing.Size(90, 28)
        Me.BtnPO_Ok.TabIndex = 311
        Me.BtnPO_Ok.Text = "OKx"
        Me.BtnPO_Ok.UseVisualStyleBackColor = False
        '
        'TxtPO_Diskon
        '
        Me.TxtPO_Diskon.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_Diskon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_Diskon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_Diskon.Location = New System.Drawing.Point(442, 441)
        Me.TxtPO_Diskon.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtPO_Diskon.MaxLength = 7
        Me.TxtPO_Diskon.Name = "TxtPO_Diskon"
        Me.TxtPO_Diskon.Size = New System.Drawing.Size(77, 21)
        Me.TxtPO_Diskon.TabIndex = 309
        Me.TxtPO_Diskon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TxtPO_Diskon.Visible = False
        '
        'TxtPO_Jml
        '
        Me.TxtPO_Jml.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TxtPO_Jml.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPO_Jml.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_Jml.Location = New System.Drawing.Point(980, 42)
        Me.TxtPO_Jml.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtPO_Jml.Name = "TxtPO_Jml"
        Me.TxtPO_Jml.Size = New System.Drawing.Size(99, 21)
        Me.TxtPO_Jml.TabIndex = 306
        Me.TxtPO_Jml.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(205, 653)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(84, 36)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Release"
        Me.Button2.UseVisualStyleBackColor = False
        Me.Button2.Visible = False
        '
        'BtnPO_Refresh
        '
        Me.BtnPO_Refresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.BtnPO_Refresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.BtnPO_Refresh.ForeColor = System.Drawing.Color.White
        Me.BtnPO_Refresh.Location = New System.Drawing.Point(115, 653)
        Me.BtnPO_Refresh.Name = "BtnPO_Refresh"
        Me.BtnPO_Refresh.Size = New System.Drawing.Size(84, 36)
        Me.BtnPO_Refresh.TabIndex = 3
        Me.BtnPO_Refresh.Text = "&Refresh"
        Me.BtnPO_Refresh.UseVisualStyleBackColor = False
        '
        'BtnPO_Simpan
        '
        Me.BtnPO_Simpan.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(86, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.BtnPO_Simpan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.BtnPO_Simpan.ForeColor = System.Drawing.Color.White
        Me.BtnPO_Simpan.Location = New System.Drawing.Point(25, 653)
        Me.BtnPO_Simpan.Name = "BtnPO_Simpan"
        Me.BtnPO_Simpan.Size = New System.Drawing.Size(84, 36)
        Me.BtnPO_Simpan.TabIndex = 2
        Me.BtnPO_Simpan.Text = "&Simpan"
        Me.BtnPO_Simpan.UseVisualStyleBackColor = False
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label27.Location = New System.Drawing.Point(464, 738)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(68, 17)
        Me.Label27.TabIndex = 339
        Me.Label27.Text = "Sisa Kurs"
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox13.Enabled = False
        Me.TextBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!)
        Me.TextBox13.Location = New System.Drawing.Point(547, 737)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(228, 21)
        Me.TextBox13.TabIndex = 338
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Red
        Me.Panel4.Location = New System.Drawing.Point(16, 689)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1247, 14)
        Me.Panel4.TabIndex = 307
        Me.Panel4.Visible = False
        '
        'CmbPO_LokasiGudang
        '
        Me.CmbPO_LokasiGudang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbPO_LokasiGudang.Enabled = False
        Me.CmbPO_LokasiGudang.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.CmbPO_LokasiGudang.FormattingEnabled = True
        Me.CmbPO_LokasiGudang.Location = New System.Drawing.Point(1176, 69)
        Me.CmbPO_LokasiGudang.Name = "CmbPO_LokasiGudang"
        Me.CmbPO_LokasiGudang.Size = New System.Drawing.Size(41, 23)
        Me.CmbPO_LokasiGudang.TabIndex = 2
        Me.CmbPO_LokasiGudang.Visible = False
        '
        'TxtPO_NoFaktur
        '
        Me.TxtPO_NoFaktur.BackColor = System.Drawing.Color.Goldenrod
        Me.TxtPO_NoFaktur.Enabled = False
        Me.TxtPO_NoFaktur.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPO_NoFaktur.ForeColor = System.Drawing.SystemColors.Window
        Me.TxtPO_NoFaktur.Location = New System.Drawing.Point(18, 65)
        Me.TxtPO_NoFaktur.MaxLength = 30
        Me.TxtPO_NoFaktur.Name = "TxtPO_NoFaktur"
        Me.TxtPO_NoFaktur.Size = New System.Drawing.Size(227, 21)
        Me.TxtPO_NoFaktur.TabIndex = 390
        '
        'LvSupplier2
        '
        Me.LvSupplier2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3, Me.ColumnHeader4})
        Me.LvSupplier2.FullRowSelect = True
        Me.LvSupplier2.GridLines = True
        Me.LvSupplier2.HideSelection = False
        Me.LvSupplier2.Location = New System.Drawing.Point(1350, 179)
        Me.LvSupplier2.Name = "LvSupplier2"
        Me.LvSupplier2.Size = New System.Drawing.Size(462, 150)
        Me.LvSupplier2.TabIndex = 352
        Me.LvSupplier2.UseCompatibleStateImageBehavior = False
        Me.LvSupplier2.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Kode Supplier"
        Me.ColumnHeader3.Width = 102
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Nama"
        Me.ColumnHeader4.Width = 280
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Red
        Me.Panel6.Location = New System.Drawing.Point(15, 641)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1247, 12)
        Me.Panel6.TabIndex = 308
        Me.Panel6.Visible = False
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Red
        Me.Panel7.Location = New System.Drawing.Point(18, 215)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1247, 12)
        Me.Panel7.TabIndex = 308
        Me.Panel7.Visible = False
        '
        'Txt_Faktur_Induk
        '
        Me.Txt_Faktur_Induk.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.Txt_Faktur_Induk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Faktur_Induk.Enabled = False
        Me.Txt_Faktur_Induk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Faktur_Induk.ForeColor = System.Drawing.Color.Black
        Me.Txt_Faktur_Induk.Location = New System.Drawing.Point(250, 67)
        Me.Txt_Faktur_Induk.MaxLength = 30
        Me.Txt_Faktur_Induk.Name = "Txt_Faktur_Induk"
        Me.Txt_Faktur_Induk.Size = New System.Drawing.Size(227, 21)
        Me.Txt_Faktur_Induk.TabIndex = 390
        '
        'DataGridViewTextBoxColumn1
        '
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle20
        Me.DataGridViewTextBoxColumn1.HeaderText = "Lokasi"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 130
        '
        'DataGridViewTextBoxColumn2
        '
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.DataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle21
        Me.DataGridViewTextBoxColumn2.HeaderText = "Kode Barang"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 130
        '
        'DataGridViewTextBoxColumn3
        '
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.DataGridViewTextBoxColumn3.DefaultCellStyle = DataGridViewCellStyle22
        Me.DataGridViewTextBoxColumn3.HeaderText = "Nama Barang"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 200
        '
        'DataGridViewTextBoxColumn4
        '
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle23
        Me.DataGridViewTextBoxColumn4.HeaderText = "Harga Input"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Visible = False
        Me.DataGridViewTextBoxColumn4.Width = 130
        '
        'DataGridViewTextBoxColumn5
        '
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn5.DefaultCellStyle = DataGridViewCellStyle24
        Me.DataGridViewTextBoxColumn5.HeaderText = "Jumlah PO"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Visible = False
        Me.DataGridViewTextBoxColumn5.Width = 120
        '
        'DataGridViewTextBoxColumn6
        '
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn6.DefaultCellStyle = DataGridViewCellStyle25
        Me.DataGridViewTextBoxColumn6.HeaderText = "Sisa"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Visible = False
        Me.DataGridViewTextBoxColumn6.Width = 120
        '
        'DataGridViewTextBoxColumn7
        '
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn7.DefaultCellStyle = DataGridViewCellStyle26
        Me.DataGridViewTextBoxColumn7.HeaderText = "Jumlah"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 120
        '
        'DataGridViewTextBoxColumn8
        '
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn8.DefaultCellStyle = DataGridViewCellStyle27
        Me.DataGridViewTextBoxColumn8.HeaderText = "Satuan Input"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Visible = False
        Me.DataGridViewTextBoxColumn8.Width = 80
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Harga SB"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Visible = False
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Jumlah SB"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Visible = False
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Satuan SB"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.Visible = False
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "No Penawaran"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.Visible = False
        Me.DataGridViewTextBoxColumn12.Width = 150
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Visible = False
        '
        'DataGridViewTextBoxColumn14
        '
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn14.DefaultCellStyle = DataGridViewCellStyle28
        Me.DataGridViewTextBoxColumn14.HeaderText = "Total"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 130
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Urut"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Visible = False
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "NoPR"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.Visible = False
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Tempo Pembayaran"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Visible = False
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Jatuh Tempo"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        Me.DataGridViewTextBoxColumn18.Visible = False
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.HeaderText = "Fak Penawaran"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        Me.DataGridViewTextBoxColumn19.Visible = False
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "Faktur Induk"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.Width = 120
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "urut_det"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        Me.DataGridViewTextBoxColumn21.Visible = False
        '
        'DataGridViewTextBoxColumn22
        '
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn22.DefaultCellStyle = DataGridViewCellStyle29
        Me.DataGridViewTextBoxColumn22.HeaderText = "Jenis Kategori"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Width = 150
        '
        'DataGridViewTextBoxColumn23
        '
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn23.DefaultCellStyle = DataGridViewCellStyle30
        Me.DataGridViewTextBoxColumn23.HeaderText = "Jumlah PO"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        Me.DataGridViewTextBoxColumn23.Width = 120
        '
        'DataGridViewTextBoxColumn24
        '
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn24.DefaultCellStyle = DataGridViewCellStyle31
        Me.DataGridViewTextBoxColumn24.HeaderText = "Satuan"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.ReadOnly = True
        Me.DataGridViewTextBoxColumn24.Width = 80
        '
        'DataGridViewTextBoxColumn25
        '
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn25.DefaultCellStyle = DataGridViewCellStyle32
        Me.DataGridViewTextBoxColumn25.HeaderText = "Harga"
        Me.DataGridViewTextBoxColumn25.Name = "DataGridViewTextBoxColumn25"
        Me.DataGridViewTextBoxColumn25.ReadOnly = True
        Me.DataGridViewTextBoxColumn25.Width = 130
        '
        'DataGridViewTextBoxColumn26
        '
        DataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn26.DefaultCellStyle = DataGridViewCellStyle33
        Me.DataGridViewTextBoxColumn26.HeaderText = "Sisa"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        Me.DataGridViewTextBoxColumn26.ReadOnly = True
        Me.DataGridViewTextBoxColumn26.Width = 120
        '
        'DtpPO_ETA
        '
        Me.DtpPO_ETA.CustomFormat = "dd MMMM yyyy"
        Me.DtpPO_ETA.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DtpPO_ETA.Location = New System.Drawing.Point(396, 38)
        Me.DtpPO_ETA.Margin = New System.Windows.Forms.Padding(2)
        Me.DtpPO_ETA.Name = "DtpPO_ETA"
        Me.DtpPO_ETA.Size = New System.Drawing.Size(192, 21)
        Me.DtpPO_ETA.TabIndex = 338
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label10.Location = New System.Drawing.Point(310, 39)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 17)
        Me.Label10.TabIndex = 337
        Me.Label10.Text = "ETA"
        '
        'EMI_PO_Pembelian_Sub
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1314, 701)
        Me.Controls.Add(Me.LvSupplier2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.LvSupplier)
        Me.Controls.Add(Me.Txt_Faktur_Induk)
        Me.Controls.Add(Me.TxtPO_NoFaktur)
        Me.Controls.Add(Me.CmbPO_LokasiGudang)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.DtpPO_TglBayar)
        Me.Controls.Add(Me.BtnPO_Refresh)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BtnPO_Simpan)
        Me.Controls.Add(Me.ListView10)
        Me.Controls.Add(Me.ListView2)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Discx)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.CmbPO_Lokasi)
        Me.Controls.Add(Me.discz)
        Me.Controls.Add(Me.TxtPPN)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.sat)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ket)
        Me.Controls.Add(Me.Groupbox)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "EMI_PO_Pembelian_Sub"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Groupbox.ResumeLayout(False)
        Me.Groupbox.PerformLayout()
        CType(Me.LvPO_DataPO, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblPO_TotalBiaya As System.Windows.Forms.Label
    Friend WithEvents ket As System.Windows.Forms.TextBox
    Friend WithEvents CmbPO_Lokasi As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ListView2 As System.Windows.Forms.ListView
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents sat As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents LblPO_Supplier As System.Windows.Forms.Label
    Friend WithEvents LblPO_Pembayaran As System.Windows.Forms.Label
    Friend WithEvents CmbPO_JnsBayar As System.Windows.Forms.ComboBox
    Friend WithEvents DtpPO_TglBayar As System.Windows.Forms.DateTimePicker
    Friend WithEvents TxtPO_KdSupplier As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TxtPPN As System.Windows.Forms.TextBox
    Friend WithEvents discz As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ListView10 As System.Windows.Forms.ListView
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents Discx As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DtpPO_Tgl As System.Windows.Forms.DateTimePicker
    Friend WithEvents TxtPO_NoNota As System.Windows.Forms.TextBox
    Friend WithEvents LblPO_Tgl As System.Windows.Forms.Label
    Friend WithEvents LblPO_NoNota As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents LblPO_Judul As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PanelGradient1 As CustomControl.PanelGradient
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Groupbox As GroupBox
    Friend WithEvents LblPO_TotalMUA As Label
    Friend WithEvents TxtPO_Total As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TxtPO_Kurs As TextBox
    Friend WithEvents LblPO_Kurs As Label
    Friend WithEvents CmbPO_MataUang As ComboBox
    Friend WithEvents LblPO_MataUang As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents LblPO_TotalSblmPPN As Label
    Friend WithEvents TxtPO_TotalSblmPPN As TextBox
    Friend WithEvents ChkPO_PPN As CheckBox
    Friend WithEvents TxtPO_PersenPPN As TextBox
    Friend WithEvents LblPO_PPN As Label
    Friend WithEvents TxtPO_NilaiPPN As TextBox
    Friend WithEvents LblPO_CaraBayar As Label
    Friend WithEvents CmbPO_CaraBayar As ComboBox
    Friend WithEvents TxtPO_GrandTotal As TextBox
    Friend WithEvents LblPO_GrandTotal As Label
    Friend WithEvents TxtPO_NmBrg As TextBox
    Friend WithEvents LblPO_Diskon As Label
    Friend WithEvents LblPO_Jml As Label
    Friend WithEvents LblPO_NmBarang As Label
    Friend WithEvents LblPO_Hrg As Label
    Friend WithEvents LblPO_KdBarang As Label
    Friend WithEvents RdoPO_Persen As RadioButton
    Friend WithEvents RdoPO_Rp As RadioButton
    Friend WithEvents BtnPO_Clear As Button
    Friend WithEvents TxtPO_KdBrg As TextBox
    Friend WithEvents BtnPO_Ok As Button
    Friend WithEvents TxtPO_Diskon As TextBox
    Friend WithEvents TxtPO_Jml As TextBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents CmbPO_Satuan As ComboBox
    Friend WithEvents LblPO_Satuan As Label
    Public WithEvents ListView1 As ListView
    Friend WithEvents TxtPO_NoPO As TextBox
    Friend WithEvents btnRelease As Button
    Friend WithEvents CmbPO_LokasiGudang As ComboBox
    Friend WithEvents CmbPO_Harga As ComboBox
    Friend WithEvents LblPO_satBarang As Label
    Friend WithEvents TxtPO_SatuanBarang As TextBox
    Friend WithEvents BtnPO_Refresh As Button
    Friend WithEvents BtnPO_Simpan As Button
    Friend WithEvents TxtPO_Biaya As TextBox
    Friend WithEvents LblPO_biaya As Label
    Friend WithEvents CmbPO_JnsEkspedisi As ComboBox
    Friend WithEvents LblPO_Ekspedisi As Label
    Friend WithEvents LvSupplier As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents TxtPO_Berat As TextBox
    Friend WithEvents LblPO_Berat As Label
    Friend WithEvents LblPO_NoPO As Label
    Friend WithEvents DtpPO_ETD As DateTimePicker
    Friend WithEvents LblPO_ETD As Label
    Friend WithEvents cmb_pr As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtSisaPr As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtSatuanSisa As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents TxtPO_NmSupplier As TextBox
    Friend WithEvents TxtPO_NoFaktur As TextBox
    Friend WithEvents LvSupplier2 As ListView
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents cmbJenisPengiriman As ComboBox
    Friend WithEvents txtJatuhTempo As TextBox
    Friend WithEvents Txt_Faktur_Induk As TextBox
    Friend WithEvents LvPO_DataPO As DataGridView
    Friend WithEvents Label8 As Label
    Friend WithEvents Txt_GrandPPH As TextBox
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents HapusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label9 As Label
    Friend WithEvents Cmb_Ekspedisi As ComboBox
    Friend WithEvents Btn_Ekspedisi As Button
    Friend WithEvents Lbl_BiayaEkspedisi As Label
    Friend WithEvents Txt_BiayaEkspedisi As TextBox
    Friend WithEvents lokasi As DataGridViewTextBoxColumn
    Friend WithEvents kode_barang As DataGridViewTextBoxColumn
    Friend WithEvents nama_barang As DataGridViewTextBoxColumn
    Friend WithEvents harga As DataGridViewTextBoxColumn
    Friend WithEvents jumlah_po As DataGridViewTextBoxColumn
    Friend WithEvents sisa As DataGridViewTextBoxColumn
    Friend WithEvents Jumlah As DataGridViewTextBoxColumn
    Friend WithEvents Satuan As DataGridViewTextBoxColumn
    Friend WithEvents Harga_SB As DataGridViewTextBoxColumn
    Friend WithEvents Jumlah_SB As DataGridViewTextBoxColumn
    Friend WithEvents Satuan_SB As DataGridViewTextBoxColumn
    Friend WithEvents No_PEnawaran As DataGridViewTextBoxColumn
    Friend WithEvents ID As DataGridViewTextBoxColumn
    Friend WithEvents Total As DataGridViewTextBoxColumn
    Friend WithEvents urut As DataGridViewTextBoxColumn
    Friend WithEvents NoPR As DataGridViewTextBoxColumn
    Friend WithEvents TempoBayar As DataGridViewTextBoxColumn
    Friend WithEvents jatuhTempo As DataGridViewTextBoxColumn
    Friend WithEvents noFakPenawaran As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn25 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As DataGridViewTextBoxColumn
    Friend WithEvents DtpPO_ETA As DateTimePicker
    Friend WithEvents Label10 As Label
End Class
