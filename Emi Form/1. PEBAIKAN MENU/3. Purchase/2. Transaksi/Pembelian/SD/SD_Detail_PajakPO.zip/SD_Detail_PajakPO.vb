﻿Public Class SD_Detail_PajakPO

    Dim tempDataPajak As New List(Of (Pajak As String, Nilai As String)) From {
        ("PPH21", "11"),
        ("PPH22", "15")
    }


    Private Sub SD_Detail_PajakPO_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Kosong()
    End Sub

    Private Sub Kosong()

        Lv_Data.Columns.Clear() : Lv_Data.Items.Clear()
        Lv_Data.Columns.Add("Pajak", 150, HorizontalAlignment.Left)
        Lv_Data.Columns.Add("Persen", 120, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Nilai", 250, HorizontalAlignment.Right)
        Lv_Data.View = View.Details

        GetData()
    End Sub

    Private Sub GetData()

        Dim TotalPPH As Double = 0

        Lv_Data.Items.Clear()
        For i As Integer = 0 To tempDataPajak.Count - 1
            Dim Lv As ListViewItem
            Lv = Lv_Data.Items.Add(tempDataPajak(i).Pajak)
            Lv.SubItems.Add(tempDataPajak(i).Nilai & " %")

            Dim NilaiPajak As Double = (Val(tempDataPajak(i).Nilai) / 100) * HilangkanTanda(TxtPO_GrandTotal.Text)
            Lv.SubItems.Add(Format(NilaiPajak, "N2"))

            TotalPPH += NilaiPajak
        Next

        Txt_TotalPPH.Text = Format(TotalPPH, "N2")

    End Sub
End Class