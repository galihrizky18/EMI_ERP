﻿Imports System.Globalization

Public Class EMI_Budgeting_Work_Center

    Dim arrBulan, arrBulanMM, arrSelectedRouting As New ArrayList

    Dim ColDinamis As Integer = 4
    Dim isDataRelease As Boolean

    Dim DgvRouting_IDRouting, DgvRouting_Keterangan, DgvRouting_CheckBox, DgvRouting_KdRouting, DgvRouting_PrefixCode, DgvRouting_IdJenisProduk As String
    Dim DgvWork_IDRouting, DgvWork_IDWorkCenter, DgvWork_Routing, DgvWork_Mesin As String

    Dim item_DgvRouting_IDRouting As Integer = 0
    Dim item_DgvRouting_Keterangan As Integer = 1
    Dim item_DgvRouting_CheckBox As Integer = 2
    Dim item_DgvRouting_KodeRouting As Integer = 3
    Dim item_DgvRouting_PrefixCode As Integer = 4
    Dim item_DgvRouting_IDJenisProduk As Integer = 5

    Dim item_DGVWork_IDRouting As Integer = 0
    Dim item_DGVWork_IDWorkCenter As Integer = 1
    Dim item_DGVWork_Routing As Integer = 2
    Dim item_DGVWork_Mesin As Integer = 3

    Private Sub EMI_Budgeting_Work_Center_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")
    End Sub

    Private Sub EMI_Transaksi_Work_Center2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")

        Kosong()

    End Sub

    Private Sub BtnRefresh_Click(sender As Object, e As EventArgs) Handles BtnRefresh.Click
        Kosong()
    End Sub

    Private Sub dgv_workcenter_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_workcenter.CellEndEdit

        If dgv_workcenter.Rows.Count = 0 Then Exit Sub

        If Not IsNumeric(dgv_workcenter.CurrentCell.Value) Then
            dgv_workcenter.CurrentCell.Value = 0
        End If

        If Not dgv_workcenter.Rows.Count = 0 Then
            '======================
            '=     SET FORMAT     =
            '======================
            Dim culture As CultureInfo = CultureInfo.CurrentCulture

            If Not {0, 1, 2, 3}.Contains(dgv_workcenter.CurrentCell.ColumnIndex) Then

                Dim cellKuantity As String = dgv_workcenter.CurrentCell.Value

                If cellKuantity.Contains(",") Then
                    MessageBox.Show("Kuantity Tidak Boleh Koma, Ganti dengan Titik", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    dgv_workcenter.CurrentCell.Value = Format(0, "N2")
                    Exit Sub
                End If

                Dim nilai As Decimal = Decimal.Parse(cellKuantity)
                Dim formattedValue As String = nilai.ToString("N2", culture)

                dgv_workcenter.CurrentCell.Value = formattedValue
            End If
        End If

    End Sub

    Private Sub dgv_workcenter_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_workcenter.CellEnter
        If Not dgv_workcenter.Rows.Count = 0 Then
            '======================
            '=     SET FORMAT     =
            '======================

            If Not {0, 1, 2, 3}.Contains(dgv_workcenter.CurrentCell.ColumnIndex) Then
                Dim cellKuantity As String = dgv_workcenter.CurrentCell.Value

                If cellKuantity = "" Then
                    Exit Sub
                End If

                Dim cleanedStr As String = HilangkanTanda(cellKuantity) ' Menghapus titik
                Dim nilai As Decimal = Decimal.Parse(cleanedStr)

                dgv_workcenter.CurrentCell.Value = nilai
            End If
        End If
    End Sub

    Private Sub dgv_workcenter_CellLeave(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_workcenter.CellLeave
        If Not dgv_workcenter.Rows.Count = 0 Then

            '======================
            '=     SET FORMAT     =
            '======================
            Dim culture As CultureInfo = CultureInfo.CurrentCulture

            If Not {0, 1, 2, 3}.Contains(dgv_workcenter.CurrentCell.ColumnIndex) Then
                Dim cellKuantity As String = dgv_workcenter.CurrentCell.Value

                If cellKuantity = "" Then
                    Exit Sub
                End If


                Dim nilai As Decimal = Decimal.Parse(cellKuantity)
                Dim formattedValue As String = nilai.ToString("N2", culture)

                dgv_workcenter.CurrentCell.Value = formattedValue

            End If
        End If
    End Sub

    Private Sub Btn_release_Click(sender As Object, e As EventArgs) Handles Btn_release.Click

        If Txt_NoFak.Text.Trim.Length = 0 Or dgv_workcenter.Rows.Count = 0 Then Exit Sub

        Try
            OpenConn()
            Cmd.Transaction = Cn.BeginTransaction

            '===============================
            '=     CEK APAKAH ADA DATA     =
            '===============================
            SQL = "select No_Faktur from Emi_Budgeting_Work_Center where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & Txt_NoFak.Text & "'"
            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then
                        For i As Integer = 0 To .Rows.Count - 1

                            SQL = "update Emi_Budgeting_Work_Center set Flag_Release = 'Y' where No_Faktur = '" & .Rows(i).Item("No_Faktur") & "'"
                            ExecuteTrans(SQL)

                        Next
                    Else
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("Data Belum Disimpan", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Exit Sub
                    End If
                End With
            End Using

            Cmd.Transaction.Commit()
            CloseTrans()
            CloseConn()
            MessageBox.Show("Data Berhasil di release", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Kosong()
            Exit Sub
        Catch ex As Exception
            CloseTrans()
            CloseConn()
            MessageBox.Show(ex.Message)
            Kosong()
            Exit Sub
        End Try

    End Sub

    Private Sub Kosong()

        get_jam()

        Try
            OpenConn()

            dgv_routing.Rows.Clear()
            dgv_workcenter.Rows.Clear()

            arrSelectedRouting.Clear()

            Txt_NoFak.Text = ""
            isDataRelease = False
            Btn_release.Enabled = True
            Btn_release.Visible = False
            BtnSimpan.Enabled = True

            Cmbsatuan.Items.Clear()
            SQL = "select Satuan from EMI_Satuan where kode_perusahaan = '" & KodePerusahaan & "'  "
            SQL = SQL & "order by Satuan"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    Cmbsatuan.Items.Add(dr("Satuan"))
                Loop
            End Using
            Cmbsatuan.Text = "KG"
            Cmbsatuan.Enabled = False
            '======================
            '=     GET LOKASI     =
            '======================
            CmbLokasi.Items.Clear()
            SQL = "select Kode_Stock_Owner from Stock_Owner "
            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    For i As Integer = 0 To .Rows.Count - 1
                        CmbLokasi.Items.Add(.Rows(i).Item("Kode_Stock_Owner"))
                    Next
                End With
            End Using
            CmbLokasi.Enabled = True : CmbLokasi.Text = Lokasi

            '=====================
            '=     GET BULAN     =
            '=====================
            CmbBulan.Items.Clear() : arrBulan.Clear() : arrBulanMM.Clear()
            CmbBulan.Items.Add("January") : arrBulan.Add("1") : arrBulanMM.Add("01")
            CmbBulan.Items.Add("February") : arrBulan.Add("2") : arrBulanMM.Add("02")
            CmbBulan.Items.Add("Maret") : arrBulan.Add("3") : arrBulanMM.Add("03")
            CmbBulan.Items.Add("April") : arrBulan.Add("4") : arrBulanMM.Add("04")
            CmbBulan.Items.Add("Mei") : arrBulan.Add("5") : arrBulanMM.Add("05")
            CmbBulan.Items.Add("Juni") : arrBulan.Add("6") : arrBulanMM.Add("06")
            CmbBulan.Items.Add("Juli") : arrBulan.Add("7") : arrBulanMM.Add("07")
            CmbBulan.Items.Add("Agustus") : arrBulan.Add("8") : arrBulanMM.Add("08")
            CmbBulan.Items.Add("September") : arrBulan.Add("9") : arrBulanMM.Add("09")
            CmbBulan.Items.Add("Oktober") : arrBulan.Add("10") : arrBulanMM.Add("10")
            CmbBulan.Items.Add("November") : arrBulan.Add("11") : arrBulanMM.Add("11")
            CmbBulan.Items.Add("Desember") : arrBulan.Add("12") : arrBulanMM.Add("12")

            CmbBulan.SelectedIndex = CInt(Format(Now.Date, "MM")) - 1
            CmbBulan.Enabled = True

            '=====================
            '=     GET TAHUN     =
            '=====================
            CmbTahun.Items.Clear()
            Dim tahun_awal As Integer = Date.Now.Year - 2
            Dim tahun_akhir As Integer = Date.Now.Year + 2
            For a As Integer = tahun_awal To tahun_akhir
                CmbTahun.Items.Add(a)
            Next
            CmbTahun.Text = Format(Now.Date, "yyyy")
            CmbTahun.Enabled = True

            Get_Data_Routing()

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub



    Private Sub Kosong_DGVWorkCenter()
        '=================================================
        '=     MENGHAPUS KOLOM MULAI DARI INDEX KE 4     =
        '=================================================
        For i As Integer = dgv_workcenter.Columns.Count - 1 To ColDinamis Step -1
            dgv_workcenter.Columns.RemoveAt(i)
        Next
    End Sub



    Private Sub Get_Data_DGVRouting(ByVal index As Integer)

        DgvRouting_IDRouting = dgv_routing.Rows(index).Cells(item_DgvRouting_IDRouting).Value
        DgvRouting_Keterangan = dgv_routing.Rows(index).Cells(item_DgvRouting_Keterangan).Value
        DgvRouting_CheckBox = dgv_routing.Rows(index).Cells(item_DgvRouting_CheckBox).Value
        DgvRouting_KdRouting = dgv_routing.Rows(index).Cells(item_DgvRouting_KodeRouting).Value
        DgvRouting_PrefixCode = dgv_routing.Rows(index).Cells(item_DgvRouting_PrefixCode).Value
        DgvRouting_IdJenisProduk = dgv_routing.Rows(index).Cells(item_DgvRouting_IDJenisProduk).Value

    End Sub

    Private Sub Get_data_DGVWorkCenter(ByVal index As Integer)

        DgvWork_IDRouting = dgv_workcenter.Rows(index).Cells(item_DGVWork_IDRouting).Value
        DgvWork_IDWorkCenter = dgv_workcenter.Rows(index).Cells(item_DGVWork_IDWorkCenter).Value
        DgvWork_Routing = dgv_workcenter.Rows(index).Cells(item_DGVWork_Routing).Value
        DgvWork_Mesin = dgv_workcenter.Rows(index).Cells(item_DGVWork_Mesin).Value

    End Sub

    Private Sub get_no_faktur(ByVal BulanTahun As String)
        Dim FPro_Results As String = "BWC"
        Txt_NoFak.Text = FPro_Results & BulanTahun & "-" &
                             General_Class.Get_Last_Number2("Emi_Budgeting_Work_Center", "No_Faktur", 5,
                             "Kode_perusahaan", KodePerusahaan,
                             "And", "substring(No_Faktur, 1, " & Len(FPro_Results) + 4 & ")", FPro_Results & BulanTahun)
    End Sub

    Private Sub BtnCari_Click(sender As Object, e As EventArgs) Handles BtnCari.Click
        If CmbLokasi.SelectedIndex = -1 Then
            MessageBox.Show("Lokasi harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbLokasi.Focus() : Kosong_DGVWorkCenter() : Exit Sub
        ElseIf CmbBulan.SelectedIndex = -1 Then
            MessageBox.Show("Bulan harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbBulan.Focus() : Kosong_DGVWorkCenter() : Exit Sub
        ElseIf CmbTahun.SelectedIndex = -1 Then
            MessageBox.Show("Tahun harus diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbTahun.Focus() : Kosong_DGVWorkCenter() : Exit Sub
        ElseIf arrSelectedRouting.Count = 0 Then
            MessageBox.Show("Harus Pilih Minimal 1 Routing", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            dgv_routing.Focus() : Kosong_DGVWorkCenter() : Exit Sub
        End If

        LoadData()
    End Sub


    Private Sub Get_Data_Routing()

        Dim row As Integer = 0
        SQL = "select Id_Routing, Keterangan, Kode_Routing, prefix_code, Id_Jenis_Produk from EMI_Master_Routing where Kode_Perusahaan = '" & KodePerusahaan & "'"
        Using Dr = OpenTrans(SQL)
            Do While Dr.Read
                dgv_routing.Rows.Add(1)
                dgv_routing.Rows(row).Cells(item_DgvRouting_IDRouting).Value = Dr("Id_Routing")
                dgv_routing.Rows(row).Cells(item_DgvRouting_Keterangan).Value = Dr("Keterangan")
                dgv_routing.Rows(row).Cells(item_DgvRouting_KodeRouting).Value = Dr("Kode_Routing")
                dgv_routing.Rows(row).Cells(item_DgvRouting_PrefixCode).Value = Dr("prefix_code")
                dgv_routing.Rows(row).Cells(item_DgvRouting_IDJenisProduk).Value = Dr("Id_Jenis_Produk")

                row += 1

            Loop
        End Using

    End Sub

    Private Sub dgv_routing_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_routing.CellEndEdit
        If dgv_routing.RowCount = 0 Then Exit Sub

        arrSelectedRouting.Clear()
        Kosong_DGVWorkCenter()
        dgv_workcenter.Rows.Clear()
        Btn_release.Enabled = False
        Btn_release.Visible = False

        For i As Integer = 0 To dgv_routing.RowCount - 1
            Get_Data_DGVRouting(i)

            If DgvRouting_CheckBox = "True" Then
                arrSelectedRouting.Add(DgvRouting_IDRouting)
            End If

        Next

    End Sub

    Private Sub LoadData()
        If arrSelectedRouting.Count = 0 Then Exit Sub

        get_jam()

        Try
            OpenConn()
            Cmd.Transaction = Cn.BeginTransaction

            'Reset Kolom
            Kosong_DGVWorkCenter()
            dgv_workcenter.Rows.Clear()

            '============================================
            '=     CEK APAKAH FAKTUR SUDAH RELEASE      =
            '============================================
            SQL = "select No_Faktur, Flag_Release, Lokasi from Emi_Budgeting_Work_Center where Kode_Perusahaan = '" & KodePerusahaan & "' and Bulan = '" & arrBulanMM.Item(CmbBulan.SelectedIndex) & "' and tahun = '" & CmbTahun.Text & "'  and status is null "
            Using Dr = OpenTrans(SQL)
                If Dr.Read Then

                    Txt_NoFak.Text = Dr("No_Faktur")

                    If General_Class.CekNULL(Dr("Flag_Release")) = "Y" Then
                        isDataRelease = True
                        Btn_release.Enabled = False
                        Btn_release.Visible = True
                        BtnSimpan.Enabled = False
                        CmbLokasi.Text = Dr("Lokasi")
                        CmbLokasi.Enabled = False
                    Else
                        isDataRelease = False
                        Btn_release.Enabled = True
                        Btn_release.Visible = True
                        BtnSimpan.Enabled = True
                        CmbLokasi.Enabled = True
                    End If
                Else
                    Dr.Close()
                    get_no_faktur(arrBulanMM(CmbBulan.SelectedIndex) & Strings.Right(CmbTahun.Text, 2))

                    isDataRelease = False
                    Btn_release.Enabled = False
                    Btn_release.Visible = False
                    BtnSimpan.Enabled = True
                    CmbLokasi.Enabled = True
                End If
            End Using

            '=========================================
            '=     GET JENIS BIAYA (ADD COLUMN)      =
            '=========================================
            Dim ColNum As Integer = ColDinamis
            SQL = "Select kode_jenis_biaya_produksi, Keterangan from emi_jenis_biaya_produksi where kode_perusahaan = '" & KodePerusahaan & "'"
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    dgv_workcenter.Columns.Add(dr("kode_jenis_biaya_produksi"), dr("kode_jenis_biaya_produksi"))
                    dgv_workcenter.Columns(ColNum).Width = 130
                    dgv_workcenter.Columns(ColNum).ReadOnly = False
                    dgv_workcenter.Columns(ColNum).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    ColNum += 1
                Loop
            End Using

            '========================================================================================================================================================================================

            Dim formatIdRouting As String = "'" & String.Join("', '", arrSelectedRouting.ToArray()) & "'"

            For a As Integer = 0 To arrSelectedRouting.Count - 1

                '=======================================
                '=     GET DATA MESIN PER ROUTING      =
                '=======================================
                SQL = "select a.No_Faktur, b.Id_Routing, b.Id_Work_Center, d.Keterangan as Routing, c.Keterangan as Mesin "
                SQL = SQL & "from Emi_Budgeting_Work_Center a, Emi_Budgeting_Work_Center_Detail b, EMI_Master_Work_Center c, emi_master_routing d, emi_master_routing_detail e "
                SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and b.Kode_Perusahaan = c.Kode_Perusahaan and b.Kode_Perusahaan = d.Kode_Perusahaan and d.Kode_Perusahaan = e.Kode_Perusahaan "
                SQL = SQL & "and a.No_Faktur = b.No_Faktur "
                SQL = SQL & "and b.Id_Work_Center = c.Id_Work_Center "
                SQL = SQL & "and b.Id_Routing = d.Id_Routing "
                SQL = SQL & "and d.Id_Routing = e.Id_Routing "
                SQL = SQL & "and b.Id_Work_Center = e.Id_Work_Center "
                SQL = SQL & "and a.Bulan = '" & arrBulanMM.Item(CmbBulan.SelectedIndex) & "' "
                SQL = SQL & "and a.Tahun = '" & CmbTahun.Text & "' "
                SQL = SQL & "and b.Id_Routing = '" & arrSelectedRouting(a) & "'  "
                SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' and a.status is null "
                SQL = SQL & "order by b.Id_Routing, b.Id_Work_Center "
                Using Ds = BindingTrans(SQL)
                    With Ds.Tables("MyTable")
                        If .Rows.Count <> 0 Then

                            Dim row As Integer = dgv_workcenter.Rows.Count

                            For i As Integer = 0 To .Rows.Count - 1

                                dgv_workcenter.Rows.Add(1)
                                dgv_workcenter.Rows(row).Cells(item_DGVWork_IDRouting).Value = .Rows(i).Item("Id_Routing")
                                dgv_workcenter.Rows(row).Cells(item_DGVWork_IDWorkCenter).Value = .Rows(i).Item("Id_Work_Center")
                                dgv_workcenter.Rows(row).Cells(item_DGVWork_Routing).Value = .Rows(i).Item("Routing")
                                dgv_workcenter.Rows(row).Cells(item_DGVWork_Mesin).Value = .Rows(i).Item("Mesin")

                                '======================================
                                '=     GET DATA DETAIL PER-MESIN      =
                                '======================================
                                SQL = "select b.Jenis_Biaya, b.Biaya "
                                SQL = SQL & "from Emi_Budgeting_Work_Center a, Emi_Budgeting_Work_Center_Det b "
                                SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan "
                                SQL = SQL & "and a.No_Faktur = b.No_Faktur "
                                SQL = SQL & "and a.Bulan = '" & arrBulanMM.Item(CmbBulan.SelectedIndex) & "' "
                                SQL = SQL & "and a.Tahun = '" & CmbTahun.Text & "' "
                                SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' "
                                SQL = SQL & "and b.Id_Routing = '" & .Rows(i).Item("Id_Routing") & "' "
                                SQL = SQL & "and b.Id_Work_Center = '" & .Rows(i).Item("Id_Work_Center") & "' and a.status is null "
                                SQL = SQL & "order by b.Id_Routing, b.Id_Work_Center"
                                Using Ds1 = BindingTrans(SQL)
                                    If Ds1.Tables("MyTable").Rows.Count <> 0 Then
                                        For j As Integer = 0 To Ds1.Tables("MyTable").Rows.Count - 1

                                            For k As Integer = ColDinamis To dgv_workcenter.Columns.Count - 1
                                                If Ds1.Tables("MyTable").Rows(j).Item("Jenis_Biaya") = dgv_workcenter.Columns(k).HeaderText Then
                                                    dgv_workcenter.Rows(row).Cells(k).Value = Format(Ds1.Tables("MyTable").Rows(j).Item("Biaya"), "N2")

                                                    If isDataRelease Then
                                                        dgv_workcenter.Rows(row).Cells(k).ReadOnly = True
                                                    Else
                                                        dgv_workcenter.Rows(row).Cells(k).ReadOnly = False
                                                    End If
                                                    Exit For
                                                End If
                                            Next

                                        Next
                                    Else

                                    End If
                                End Using

                                row += 1
                            Next
                        Else

                            Dim row As Integer = dgv_workcenter.Rows.Count
                            SQL = "select a.Id_Routing, b.Id_Work_Center, a.Keterangan as Routing, c.Keterangan as Mesin "
                            SQL = SQL & "from emi_master_routing a, emi_master_routing_detail b, EMI_Master_Work_Center c "
                            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and b.Kode_Perusahaan = c.Kode_Perusahaan "
                            SQL = SQL & "and a.Id_Routing = b.Id_Routing "
                            SQL = SQL & "and b.Id_Work_Center = c.Id_Work_Center "
                            SQL = SQL & "and a.Kode_Perusahaan = '" & KodePerusahaan & "' "
                            SQL = SQL & "and a.Id_Routing = '" & arrSelectedRouting(a) & "' "
                            SQL = SQL & "order by b.Id_Routing, b.Id_Work_Center"
                            Using Ds2 = BindingTrans(SQL)
                                If Ds2.Tables("MyTable").Rows.Count <> 0 Then
                                    For j As Integer = 0 To Ds2.Tables("MyTable").Rows.Count - 1
                                        dgv_workcenter.Rows.Add(1)
                                        dgv_workcenter.Rows(row).Cells(item_DGVWork_IDRouting).Value = Ds2.Tables("MyTable").Rows(j).Item("Id_Routing")
                                        dgv_workcenter.Rows(row).Cells(item_DGVWork_IDWorkCenter).Value = Ds2.Tables("MyTable").Rows(j).Item("Id_Work_Center")
                                        dgv_workcenter.Rows(row).Cells(item_DGVWork_Routing).Value = Ds2.Tables("MyTable").Rows(j).Item("Routing")
                                        dgv_workcenter.Rows(row).Cells(item_DGVWork_Mesin).Value = Ds2.Tables("MyTable").Rows(j).Item("Mesin")

                                        For k As Integer = ColDinamis To dgv_workcenter.Columns.Count - 1
                                            dgv_workcenter.Rows(row).Cells(k).Value = Format(0, "N2")
                                            If isDataRelease Then
                                                dgv_workcenter.Rows(row).Cells(k).ReadOnly = True
                                            Else
                                                dgv_workcenter.Rows(row).Cells(k).ReadOnly = False
                                            End If
                                        Next

                                        row += 1
                                    Next
                                End If
                            End Using

                        End If
                    End With
                End Using

            Next

            Cmd.Transaction.Commit()
            CloseTrans()
            CloseConn()
        Catch ex As Exception
            CloseTrans()
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub BtnSimpan_Click(sender As Object, e As EventArgs) Handles BtnSimpan.Click
        get_jam()
        If Txt_NoFak.Text.Trim.Length = 0 Then
            MessageBox.Show("No transaksi Harus diisi....!!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Txt_NoFak.Focus() : Exit Sub
        ElseIf CmbBulan.Text.Trim.Length = 0 Then
            MessageBox.Show("Bulan Harus diisi....!!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbBulan.Focus() : Exit Sub
        ElseIf CmbTahun.Text.Trim.Length = 0 Then
            MessageBox.Show("Tahun Harus diisi....!!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CmbTahun.Focus() : Exit Sub
        End If

        Try
            OpenConn()

            Cmd.Transaction = Cn.BeginTransaction

            '===============================
            '=     CEK APAKAH ADA DATA     =
            '===============================
            Dim hasData As Boolean = False
            SQL = "select No_Faktur from Emi_Budgeting_Work_Center where Kode_Perusahaan = '" & KodePerusahaan & "' and Bulan = '" & arrBulanMM.Item(CmbBulan.SelectedIndex) & "' "
            SQL = SQL & "and Tahun = '" & CmbTahun.Text & "'"
            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then
                        For j As Integer = 0 To .Rows.Count - 1
                            hasData = True

                            '=======================
                            '=     DELETE DATA     =
                            '=======================
                            For i As Integer = 0 To arrSelectedRouting.Count - 1

                                'DELETE Table Emi_Transaksi_Work_Center_Detail_Per_Mesin
                                SQL = "delete Emi_Budgeting_Work_Center_Det where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & Ds.Tables("MyTable").Rows(j).Item("No_Faktur") & "' "
                                SQL = SQL & "and Id_Routing = '" & arrSelectedRouting(i) & "' "
                                ExecuteTrans(SQL)

                                'DELETE Table Emi_Transaksi_Work_Center_Detail
                                SQL = "delete Emi_Budgeting_Work_Center_Detail where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & Ds.Tables("MyTable").Rows(j).Item("No_Faktur") & "' "
                                SQL = SQL & "and Id_Routing = '" & arrSelectedRouting(i) & "' "
                                ExecuteTrans(SQL)

                            Next

                            'DELETE Table Emi_Transaksi_Work_Center
                            SQL = "delete Emi_Budgeting_Work_Center where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & Ds.Tables("MyTable").Rows(j).Item("No_Faktur") & "' "
                            ExecuteTrans(SQL)
                        Next
                    End If
                End With
            End Using


            '=======================
            '=     INSERT DATA     =
            '=======================
            SQL = "INSERT INTO Emi_Budgeting_Work_Center(Kode_Perusahaan, No_Faktur, Lokasi, Bulan, Tahun, UserID, Tanggal, Jam) VALUES("
            SQL = SQL & "'" & KodePerusahaan & "', '" & Txt_NoFak.Text & "', '" & CmbLokasi.Text & "', '" & arrBulanMM.Item(CmbBulan.SelectedIndex) & "', "
            SQL = SQL & "'" & CmbTahun.Text & "', '" & UserID & "', '" & Format(tgl_skg, "yyyy-MM-dd") & "', '" & Format(tgl_skg, "HH:mm:ss") & "') "
            ExecuteTrans(SQL)

            'Emi_Transaksi_Work_Center_detail
            For i As Integer = 0 To dgv_workcenter.Rows.Count - 1
                Dim Total As Double = 0
                For j As Integer = ColDinamis To dgv_workcenter.Columns.Count - 1
                    Get_data_DGVWorkCenter(i)

                    Dim Biaya As Double = HilangkanTanda(dgv_workcenter.Rows(i).Cells(j).Value)
                    Total += Biaya


                    'Insert Emi_Budgeting_Work_Center_Det
                    SQL = "INSERT INTO Emi_Budgeting_Work_Center_Det(Kode_Perusahaan, No_Faktur, id_routing, Id_Work_Center, Jenis_Biaya, Biaya) "
                    SQL = SQL & "VALUES('" & KodePerusahaan & "', '" & Txt_NoFak.Text & "', '" & DgvWork_IDRouting & "', '" & DgvWork_IDWorkCenter & "', "
                    SQL = SQL & "'" & dgv_workcenter.Columns(j).HeaderText & "', '" & HilangkanTanda(Biaya) & "' )"
                    ExecuteTrans(SQL)
                Next

                Get_data_DGVWorkCenter(i)

                'Insert Emi_Budgeting_Work_Center_Detail
                SQL = "INSERT INTO Emi_Budgeting_Work_Center_Detail (kode_perusahaan, no_faktur, id_routing, id_work_center, Tot_Biaya)"
                SQL = SQL & "Values('" & KodePerusahaan & "', '" & Txt_NoFak.Text & "', "
                SQL = SQL & "'" & DgvWork_IDRouting & "', '" & DgvWork_IDWorkCenter & "', '" & HilangkanTanda(Total) & "')"
                ExecuteTrans(SQL)

            Next



            Cmd.Transaction.Commit()
            CloseConn()
            MessageBox.Show("Data berhasil disimpan", Judul, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

        BtnCari_Click(sender, e)

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

        If CheckBox1.Checked = True Then
            For i As Integer = 0 To dgv_routing.Rows.Count - 1
                Get_Data_DGVRouting(i)

                dgv_routing.Rows(i).Cells(item_DgvRouting_CheckBox).Value = True
                arrSelectedRouting.Add(DgvRouting_IDRouting)
            Next
        Else

            arrSelectedRouting.Clear()
            For i As Integer = 0 To dgv_routing.Rows.Count - 1
                dgv_routing.Rows(i).Cells(item_DgvRouting_CheckBox).Value = False
            Next
            Kosong_DGVWorkCenter()
            dgv_workcenter.Rows.Clear()
        End If
    End Sub


End Class