﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Display_Hutang_Biaya_Import

    Dim lv As New ListViewItem

    Dim Arr1, Arr2, Arr3, Arr4 As New ArrayList
    Dim arrSfA, arrSfB As New ArrayList
    Dim pertama As Integer = 1
    Dim T As Color = Color.Blue
    Dim KT As Color = Color.Red
    Dim KY As Color = Color.Green
    Dim Batal As Color = Color.Black


    Private Sub Laporan_Bahan_Tidak_Potong_Stock_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")


        Try
            OpenConn()
            Base_Language.Get_Languages(Bahasa_Pilihan, "GLOBAL")
            Base_Language.Get_Languages(Bahasa_Pilihan, "Display_Barang_Masuk")
            Base_Language.Get_Languages(Bahasa_Pilihan, "Pembelian_Barang_Masuk")
            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try



        'LvHutangBiaya.Columns.Add("Id Rencana", 100, HorizontalAlignment.Center)
        'LvHutangBiaya.Columns.Add("No Faktur", 120, HorizontalAlignment.Left)
        'LvHutangBiaya.Columns.Add("Tanggal HPP", 100, HorizontalAlignment.Center)
        'LvHutangBiaya.Columns.Add("Lokasi", 110, HorizontalAlignment.Left)
        'LvHutangBiaya.Columns.Add("Kode Perusahaan", 150, HorizontalAlignment.Left)
        'LvHutangBiaya.Columns.Add("Kode Supplier", 110, HorizontalAlignment.Left)
        'LvHutangBiaya.Columns.Add("Nama Supplier", 150, HorizontalAlignment.Left)
        'LvHutangBiaya.Columns.Add("Keterangan", 120, HorizontalAlignment.Left)
        'LvHutangBiaya.Columns.Add("Kode Kategori Biaya Import", 180, HorizontalAlignment.Left)
        'LvHutangBiaya.Columns.Add("Mata Uang", 80, HorizontalAlignment.Center)
        'LvHutangBiaya.Columns.Add("Total", 120, HorizontalAlignment.Right)
        'LvHutangBiaya.Columns.Add("Kurs", 120, HorizontalAlignment.Right)
        'LvHutangBiaya.Columns.Add("Nilai Idr", 120, HorizontalAlignment.Right)
        'LvHutangBiaya.Columns.Add("Total Hutang", 120, HorizontalAlignment.Right)
        'LvHutangBiaya.Columns.Add("Total Pelunasan", 120, HorizontalAlignment.Right)
        'LvHutangBiaya.Columns.Add("Selesai Pembelian", 120, HorizontalAlignment.Center)

        LvHutangBiaya.Columns.Add("No PO", 130, HorizontalAlignment.Left)
        LvHutangBiaya.Columns.Add("Tanggal PO", 120, HorizontalAlignment.Center)
        LvHutangBiaya.Columns.Add("Keterangan", 200, HorizontalAlignment.Left)
        LvHutangBiaya.Columns.Add("KdPerusahanBiayaImport", 0, HorizontalAlignment.Left)
        LvHutangBiaya.Columns.Add("Perusahaan", 180, HorizontalAlignment.Left)
        LvHutangBiaya.Columns.Add("KdKategori", 0, HorizontalAlignment.Left)
        LvHutangBiaya.Columns.Add("Kategori", 150, HorizontalAlignment.Left)
        LvHutangBiaya.Columns.Add("Mata Uang", 90, HorizontalAlignment.Center)
        LvHutangBiaya.Columns.Add("Total Hutang", 150, HorizontalAlignment.Right)
        LvHutangBiaya.Columns.Add("PPN", 90, HorizontalAlignment.Right)
        LvHutangBiaya.Columns.Add("PPH", 90, HorizontalAlignment.Right)
        LvHutangBiaya.Columns.Add("Dibayar", 150, HorizontalAlignment.Right)
        LvHutangBiaya.Columns.Add("Sisa", 150, HorizontalAlignment.Right)
        LvHutangBiaya.Columns.Add("Lokasi", 0, HorizontalAlignment.Right)


        LvHutangBiaya.View = View.Details

        ' get_lokasi()


        kosong()

    End Sub

    Private Sub kosong()


        Try
            OpenConn()


            ComboBox6.Items.Clear()
            ComboBox6.Items.Add(Base_Language.Lang_Global_SeluruhCombobox)

            'xSplit = CekKotaRole().Split(", ")

            SQL = "Select kode_stock_owner From "
            SQL = SQL & "stock_owner where kode_perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "order by kode_stock_owner"
            'ComboBox1.Items.Add("Seluruh")
            Using dr = OpenTrans(SQL)
                Do While dr.Read
                    ComboBox6.Items.Add(dr("kode_stock_owner"))
                Loop
            End Using

            ComboBox6.Text = Lokasi

            If CekButtonRole("Ganti_Lokasi_Display_Biaya_Import") = "T" Then
                ComboBox6.Enabled = False
            Else
                ComboBox6.Enabled = True
            End If

            'ComboBox3.Items.Add("Y") : Arr4.Add("Y")
            'ComboBox3.Items.Add("T") : Arr4.Add("T")
            'ComboBox3.SelectedIndex = 1

            ComboBox3.Items.Clear() : Arr1.Clear() : arrSfB.Clear()
            'ComboBox3.Items.Add("Tanggal") : Arr1.Add("a.tanggal")
            ComboBox3.Items.Add("Tanggal PO") : Arr1.Add("a.Tanggal_PO") : arrSfB.Add("Tanggal_PO")

            'TextBoxa.Text = "0" 
            ComboBox3.Enabled = False : ComboBox2.Enabled = False
            Tgl1.Enabled = False : Tgl2.Enabled = False
            TextBox4.Enabled = False
            Tgl1.Enabled = False : Tgl2.Enabled = False : ComboBox3.Enabled = False

            CheckBox5.Checked = False
            CheckBox1.Checked = False
            ComboBox3.Text = "" : ComboBox3.SelectedIndex = -1 : Tgl1.Value = DateTime.Now : Tgl2.Value = DateTime.Now

            CheckBox6.Checked = False
            ComboBox2.Text = "" : ComboBox2.SelectedIndex = -1 : TextBox4.Text = ""

            ComboBox2.Items.Clear() : ComboBox2.Text = "" : Arr2.Clear() : arrSfA.Clear()
            ComboBox2.Items.Add("No PO") : Arr2.Add("a.No_PO") : arrSfA.Add("No_PO")
            ComboBox2.Items.Add("Kode Perusahaan") : Arr2.Add("a.Kode_Perusahaan_Biaya_Import") : arrSfA.Add("Kode_Perusahaan_Biaya_Import")
            ComboBox2.Items.Add("Kode Supplier") : Arr2.Add("a.Kode_Perusahaan_Biaya_Import") : arrSfA.Add("Kode_Perusahaan_Biaya_Import")
            ComboBox2.Items.Add("Mata Uang") : Arr2.Add("a.Mata_Uang") : arrSfA.Add("Mata_Uang")
            ComboBox2.Items.Add("Keterangan") : Arr2.Add("a.Keterangan") : arrSfA.Add("Keterangan")

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try


        GetData()


    End Sub

    'Private Sub get_lokasi()
    '    Try
    '        OpenConn()
    '        CmbLokasi.Items.Clear() : CmbLokasi.Items.Add("---SELURUH---")
    '        xSplit = CekKotaRole().Split(",")
    '        SQL = "select kode_stock_owner from stock_owner where kode_perusahaan = '" & KodePerusahaan & "' and "
    '        SQL = SQL & "aktif = 'Y' and kode_kota in("
    '        For i As Integer = 0 To xSplit.Count - 1
    '            SQL = SQL & "'" & xSplit(i).Trim & "', "
    '        Next
    '        SQL = Strings.Left(SQL, Len(SQL) - 2)
    '        SQL = SQL & ") "
    '        SQL = SQL & "order by kode_stock_owner"
    '        Using Dr = OpenTrans(SQL)
    '            Do While Dr.Read
    '                CmbLokasi.Items.Add(Dr("kode_stock_owner"))
    '            Loop
    '        End Using
    '        CloseConn()
    '    Catch ex As Exception
    '        CmbLokasi.Items.Clear()
    '        CloseConn()
    '        MessageBox.Show(ex.Message)
    '        Exit Sub
    '    End Try
    '    CmbLokasi.SelectedIndex = 0
    'End Sub






    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked Then
            ComboBox2.Enabled = True : TextBox4.Enabled = True

        Else
            ComboBox2.Enabled = False : TextBox4.Enabled = False
            ComboBox2.SelectedIndex = -1 : TextBox4.Text = ""
        End If
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Btn_Refresh_Click(sender As Object, e As EventArgs) Handles Btn_Refresh.Click
        kosong()
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.SelectedIndex = -1 Then Exit Sub
        TextBox4.Text = ""
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            ComboBox3.Enabled = True : Tgl1.Enabled = True : Tgl2.Enabled = True
        Else
            ComboBox3.Enabled = False : Tgl1.Enabled = False : Tgl2.Enabled = False
            ComboBox3.SelectedIndex = -1
        End If
    End Sub



    Private Sub BtnCetak_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCetak.Click
        If CheckBox1.Checked = False And CheckBox5.Checked = False And CheckBox6.Checked = False Then
            MessageBox.Show(Base_Language.Lang_Global_Error_Paramater, Judul)
            CheckBox1.Focus() : Exit Sub
        End If

        If CheckBox1.Checked Then
            If ComboBox3.SelectedIndex = -1 Then
                MessageBox.Show(Base_Language.Lang_Global_Error_Paramater_Tgl, Judul)
                ComboBox3.Focus() : Exit Sub
            ElseIf Tgl1.Value > Tgl2.Value Then
                MessageBox.Show("Periode I " & Base_Language.Lang_Global_TidakBolehLebihDari & " periode II!", Judul)
                Tgl1.Value = Now.Date : Tgl2.Value = Now.Date
                Exit Sub
            End If
        ElseIf CheckBox6.Checked Then
            If ComboBox2.Text.Trim.Length = 0 And TextBox4.Text.Trim.Length = 0 Then
                MessageBox.Show("Parameter Lainnya harus di isi!")
                ComboBox2.Focus()

                Exit Sub
            End If
        End If

        Try
            OpenConn()

            Dim SF As String = ""

            '---------- SQL
            SQL = "select a.kode_Perusahaan, a.No_PO, a.Keterangan, a.Tanggal_PO, a.Kode_Perusahaan_Biaya_Import, a.nama as Perusahaan, a.Kode_Master_Kategori_Biaya_Import , a.Nama_Kategori,  "
            SQL = SQL & "a.Mata_uang, a.Nilai as TotalHutang, a.PPN, a.PPH, a.sudah_bayar, a.lokasi "
            SQL = SQL & "from View_EMI_Pelunasan a "
            SQL = SQL & "where a.kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.flag_lunas is null "

            '---------- SF
            SF = "{View_EMI_Pelunasan.Kode_Perusahaan} = '" & KodePerusahaan & "' and "
            SF = SF & "IsNull({View_EMI_Pelunasan.Status})  "

            'LOKASI
            If ComboBox6.SelectedIndex <> -1 Then
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & " a.lokasi = '" & ComboBox6.Text & "' "

                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SF = SF & "AND "

                SF = SF & "{View_EMI_Pelunasan.lokasi} = '" & ComboBox6.Text & "' "
            End If

            'TRANSAKSI HARI INI
            If CheckBox5.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "
                SQL = SQL & " a.Tanggal_PO between '"
                SQL = SQL & Format(Now, "yyyy-MM-dd") & "' and '" & Format(Now, "yyyy-MM-dd") & "' "

                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SF = SF & "AND "

                SF = SF & " {View_EMI_Pelunasan.Tanggal_PO} "
                SF = SF & " >=date('" & Format(Now, "yyyy-MM-dd") & "') "
                SF = SF & " and {View_EMI_Pelunasan.Tanggal_PO} "
                SF = SF & " <=date('" & Format(Now, "yyyy-MM-dd") & "') "
            End If

            'Tanggal
            If CheckBox1.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & Arr1.Item(ComboBox3.SelectedIndex) & " between '"
                SQL = SQL & Format(Tgl1.Value, "yyyy-MM-dd") & "' and '" & Format(Tgl2.Value, "yyyy-MM-dd") & "' "

                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SF = SF & "AND "

                SF = SF & " {View_EMI_Pelunasan." & arrSfB.Item(ComboBox3.SelectedIndex) & "} "
                SF = SF & " >=date('" & Format(Tgl1.Value, "yyyy-MM-dd") & "') "
                SF = SF & " and {View_EMI_Pelunasan." & arrSfB.Item(ComboBox3.SelectedIndex) & "} "
                SF = SF & " <=date('" & Format(Tgl2.Value, "yyyy-MM-dd") & "') "
            End If

            'Param Lain
            If CheckBox6.Checked Then
                'Pasang And
                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                SQL = SQL & Arr2.Item(ComboBox2.SelectedIndex) & " like '%" & Trim(TextBox4.Text) & "%' "

                If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SF = SF & "AND "

                SF = SF & " ToText({View_EMI_Pelunasan." & arrSfA.Item(ComboBox2.SelectedIndex) & "}) like '*" & Trim(TextBox4.Text) & "*' "
            End If

            Using Ds = BindingTrans(SQL)
                If Ds.Tables("MyTable").Rows.Count <> 0 Then
                    'Dim CrDoc = New Rpt_Laporan_Hutang_Biaya_Import_Rpt

                    'With A_Place_For_Printing2
                    '    CrDoc.SetDataSource(Ds)
                    '    CrDoc.SetDatabaseLogon(CUserId, CPassword, CServer, CDatabase)
                    '    CrDoc.RecordSelectionFormula = SF
                    '    .Text = "Laporan Perusahaan Biaya Import"
                    '    .CrystalReportViewer1.ReportSource = CrDoc

                    '    '.CrystalReportViewer1.DisplayGroupTree = False
                    '    .Refresh()
                    '    .Show()
                    'End With
                Else
                    MessageBox.Show("Data tidak ada . . ! !", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End Using




            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try



    End Sub

    Private Sub BtnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRefresh.Click


        If CheckBox1.Checked = False And CheckBox5.Checked = False And CheckBox6.Checked = False Then
            MessageBox.Show(Base_Language.Lang_Global_Error_Paramater, Judul)
            CheckBox1.Focus() : Exit Sub
        End If

        If CheckBox1.Checked Then
            If ComboBox3.SelectedIndex = -1 Then
                MessageBox.Show(Base_Language.Lang_Global_Error_Paramater_Tgl, Judul)
                ComboBox3.Focus() : Exit Sub
            ElseIf Tgl1.Value > Tgl2.Value Then
                MessageBox.Show("Periode I " & Base_Language.Lang_Global_TidakBolehLebihDari & " periode II!", Judul)
                Tgl1.Value = Now.Date : Tgl2.Value = Now.Date
                Exit Sub
            End If
        ElseIf CheckBox6.Checked Then
            If ComboBox2.Text.Trim.Length = 0 Then
                MessageBox.Show("Parameter Lainnya harus di isi!")
                ComboBox2.Focus() : TextBox4.Text = ""
                Exit Sub
            End If

            If TextBox4.Text.Trim.Length = 0 Then
                MessageBox.Show("Value Tidak Boleh Kosong!")
                TextBox4.Focus()
                Exit Sub
            End If
        End If

        GetData(True)

    End Sub


    Private Sub GetData(ByVal Optional Filter As Boolean = False)

        Try
            OpenConn()

            LvHutangBiaya.Items.Clear()
            SQL = "select a.kode_Perusahaan, a.No_PO, a.Keterangan, a.Tanggal_PO, a.Kode_Perusahaan_Biaya_Import, a.nama as Perusahaan, a.Kode_Master_Kategori_Biaya_Import , a.Nama_Kategori,  "
            SQL = SQL & "a.Mata_uang, a.Nilai as TotalHutang, a.PPN, a.PPH, a.sudah_bayar, a.lokasi "
            SQL = SQL & "from View_EMI_Pelunasan a "
            SQL = SQL & "where a.kode_Perusahaan = '" & KodePerusahaan & "' "
            SQL = SQL & "and a.flag_lunas is null "

            If Filter Then

                'LOKASI
                If ComboBox6.SelectedIndex <> -1 Then
                    If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                    SQL = SQL & " a.lokasi = '" & ComboBox6.Text & "' "
                End If

                'TRANSAKSI HARI INI
                If CheckBox5.Checked Then
                    'Pasang And
                    If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                    SQL = SQL & " a.Tanggal_PO between '"
                    SQL = SQL & Format(Now, "yyyy-MM-dd") & "' and '" & Format(Now, "yyyy-MM-dd") & "' "
                End If

                'Tanggal
                If CheckBox1.Checked Then
                    'Pasang And
                    If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                    SQL = SQL & Arr1.Item(ComboBox3.SelectedIndex) & " between '"
                    SQL = SQL & Format(Tgl1.Value, "yyyy-MM-dd") & "' and '" & Format(Tgl2.Value, "yyyy-MM-dd") & "' "
                End If

                'Param Lain
                If CheckBox6.Checked Then
                    'Pasang And
                    If Not Strings.Right(UCase(SQL), 6) = "WHERE " Then SQL = SQL & "AND "

                    SQL = SQL & Arr2.Item(ComboBox2.SelectedIndex) & " like '%" & Trim(TextBox4.Text) & "%' "
                End If


            End If

            SQL = SQL & "order by a.Tanggal_PO"

            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim lv As ListViewItem

                    lv = LvHutangBiaya.Items.Add(Dr("No_PO"))
                    lv.SubItems.Add(Format(Dr("Tanggal_PO"), "dd MMM yyyy"))
                    lv.SubItems.Add(Dr("Keterangan"))
                    lv.SubItems.Add(Dr("Kode_Perusahaan_Biaya_Import"))

                    lv.SubItems.Add(Dr("Perusahaan"))
                    lv.SubItems.Add(Dr("Kode_Master_Kategori_Biaya_Import"))
                    lv.SubItems.Add(Dr("Nama_Kategori"))
                    lv.SubItems.Add(Dr("Mata_uang"))
                    lv.SubItems.Add(Format(Dr("TotalHutang"), "N2"))
                    lv.SubItems.Add(Format(Dr("PPN"), "N2"))
                    lv.SubItems.Add(Format(Dr("PPH"), "N2"))
                    lv.SubItems.Add(Format(Dr("sudah_bayar"), "N2"))
                    Dim Sisa As Double = Val(HilangkanTanda(Dr("TotalHutang"))) - Val(HilangkanTanda(Dr("sudah_bayar")))
                    lv.SubItems.Add(Format(Sisa, "N2"))
                    lv.SubItems.Add(Dr("lokasi"))

                    If Sisa <> 0 Then
                        lv.BackColor = Color.LightYellow
                    ElseIf Sisa = 0 Then
                        lv.BackColor = Color.LightGreen
                    End If



                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

End Class