﻿Imports System.Net

Public Class Emi_Request_Material

    Dim arr_So As New ArrayList
    Dim Selected_SO, Selected_IdGroupJenis As String

    Dim LvDet_KdBarang, LvDet_NamaBarang, LvDet_JenisBarang, LvDet_IdJenis, LvDet_KdSO As String
    Dim Lv_KdSO, Lv_KdBarang, Lv_Nama, Lv_Jenis, Lv_Jumlah, Lv_Satuan As String


    Dim ItemDet_KdBarang As Integer = 0
    Dim ItemDet_NamaBarang As Integer = 1
    Dim ItemDet_Jenis As Integer = 2
    Dim ItemDet_IdJenis As Integer = 3
    Dim ItemDet_KdSO As Integer = 4

    Dim item_KdSO As Integer = 0
    Dim item_KdBarang As Integer = 1
    Dim item_Nama As Integer = 2
    Dim item_Jenis As Integer = 3
    Dim item_Jumlah As Integer = 4
    Dim item_Satuan As Integer = 5

    Private Sub Emi_Request_Material_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Initial_ListView()
        kosong()
    End Sub

    Private Sub kosong()

        Cmb_Satuan.Items.Clear()
        Cmb_So.Items.Clear()
        Cmb_FilterNama.Items.Clear()

        Lv_DetailBarang.Location = New Point(980, 146)
        Lv_DetailBarang.Visible = False

        Txt_KdBarang.Text = String.Empty
        Txt_NamaBarang.Text = String.Empty
        Txt_Jmlh.Text = String.Empty
        Txt_Filter.Text = String.Empty

        Selected_SO = ""
        Selected_IdGroupJenis = ""

        Lv_Data.Items.Clear()

        Load_All_Combo()
        Load_Lv_Data()

    End Sub

    Private Sub Load_All_Combo()
        Try
            OpenConn()

            'LOAD SO
            SQL = "select kode_stock_owner, keterangan from Stock_Owner_Gudang where kode_perusahaan='" & KodePerusahaan & "' and Kode_Stock_Owner='PRODUCTION'"
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Cmb_So.Items.Add(Dr("keterangan")) : arr_So.Add(Dr("kode_stock_owner"))
                Loop
                Cmb_So.SelectedIndex = 0
            End Using

            'LOAD SATUAN
            Cmb_Satuan.Items.Add("KG")
            Cmb_Satuan.SelectedIndex = 0

            'LOAD FILTER 
            Cmb_FilterNama.Items.Add("Nama")


            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub Initial_ListView()

        Lv_DetailBarang.Columns.Add("Kode Barang", 170, HorizontalAlignment.Left)
        Lv_DetailBarang.Columns.Add("Nama Barang", 250, HorizontalAlignment.Left)
        Lv_DetailBarang.Columns.Add("Jenis", 170, HorizontalAlignment.Left)
        'Hide
        Lv_DetailBarang.Columns.Add("idJenis", 0, HorizontalAlignment.Left)
        Lv_DetailBarang.Columns.Add("KdSO", 0, HorizontalAlignment.Left)
        Lv_DetailBarang.View = View.Details

        Lv_Data.Columns.Add("Kode SO", 150, HorizontalAlignment.Left)
        Lv_Data.Columns.Add("Kode Barang", 150, HorizontalAlignment.Left)
        Lv_Data.Columns.Add("Nama", 280, HorizontalAlignment.Left)
        Lv_Data.Columns.Add("Jenis", 150, HorizontalAlignment.Left)
        Lv_Data.Columns.Add("Jumlah", 100, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Satuan", 100, HorizontalAlignment.Center)
        Lv_Data.View = View.Details

    End Sub



    Private Sub Get_ListView_Barang_Data(ByVal index As Integer)

        LvDet_KdBarang = Lv_DetailBarang.Items(index).SubItems(ItemDet_KdBarang).Text
        LvDet_NamaBarang = Lv_DetailBarang.Items(index).SubItems(ItemDet_NamaBarang).Text
        LvDet_JenisBarang = Lv_DetailBarang.Items(index).SubItems(ItemDet_Jenis).Text
        'HIDE
        LvDet_IdJenis = Lv_DetailBarang.Items(index).SubItems(ItemDet_IdJenis).Text
        LvDet_KdSO = Lv_DetailBarang.Items(index).SubItems(ItemDet_KdSO).Text

    End Sub

    Private Sub Get_ListView_Data(ByVal index As Integer)

        Lv_KdSO = Lv_Data.Items(index).SubItems(item_KdSO).Text
        Lv_KdBarang = Lv_Data.Items(index).SubItems(item_KdBarang).Text
        Lv_Nama = Lv_Data.Items(index).SubItems(item_Nama).Text
        Lv_Jenis = Lv_Data.Items(index).SubItems(item_Jenis).Text
        Lv_Jumlah = Lv_Data.Items(index).SubItems(item_Jumlah).Text
        Lv_Satuan = Lv_Data.Items(index).SubItems(item_Satuan).Text

    End Sub


    Private Sub Load_Lv_Data()
        Try
            OpenConn()

            Lv_Data.Items.Clear()
            SQL = "select a.Kode_Stock_Owner, a.Kode_Barang, a.Nama, b.Kode_Group_Jenis, a.Jumlah, a.Satuan "
            SQL = SQL & "from Emi_Material_Requisition a, EMI_Group_Jenis b "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan "
            SQL = SQL & "and a.Id_Group_Jenis = b.Id_Group_Jenis "
            SQL = SQL & "and a.Kode_Perusahaan='" & KodePerusahaan & "' "
            SQL = SQL & "and a.Flag_Process = 'Y' "
            SQL = SQL & "order by a.Kode_Barang "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim lv As ListViewItem
                    lv = Lv_Data.Items.Add(Dr("Kode_Stock_Owner"))
                    lv.SubItems.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Dr("Kode_Group_Jenis"))
                    lv.SubItems.Add(Dr("Jumlah"))
                    lv.SubItems.Add(Dr("Satuan"))
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub



    '===== HANDLE FUNCTION =====
    Private Sub Txt_KdBarang_TextChanged(sender As Object, e As EventArgs) Handles Txt_KdBarang.TextChanged

        If Txt_KdBarang.Text.Trim.Length = 0 Then
            Lv_DetailBarang.Items.Clear()
            Txt_NamaBarang.Text = String.Empty
            Txt_Jmlh.Text = String.Empty

            Lv_DetailBarang.Location = New Point(980, 146)
            Lv_DetailBarang.Visible = False
            Exit Sub
        End If


        Try
            OpenConn()

            Lv_DetailBarang.Items.Clear()

            SQL = "select a.Kode_Barang, a.Nama, b.Kode_Group_Jenis, a.Id_Group_Jenis, a.Kode_Stock_Owner "
            SQL = SQL & "from barang a, EMI_Group_Jenis b "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan "
            SQL = SQL & "and a.Id_Group_Jenis = b.Id_Group_Jenis "
            SQL = SQL & "and a.Id_Group_Jenis in ('1', '5') and a.Kode_Stock_Owner='" & arr_So(Cmb_So.SelectedIndex) & "' "
            SQL = SQL & "and a.Kode_Perusahaan ='" & KodePerusahaan & "' "
            SQL = SQL & "and a.Nama like '" & Txt_KdBarang.Text & "%' "
            SQL = SQL & "group by a.Kode_Barang, a.Nama, b.Kode_Group_Jenis, a.Id_Group_Jenis, a.Kode_Stock_Owner "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim lv As ListViewItem
                    lv = Lv_DetailBarang.Items.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Dr("Kode_Group_Jenis"))
                    'HIDE
                    lv.SubItems.Add(Dr("Id_Group_Jenis"))
                    lv.SubItems.Add(Dr("Kode_Stock_Owner"))
                Loop
            End Using

            Lv_DetailBarang.Location = New Point(138, 146)
            Lv_DetailBarang.Visible = True

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Lv_DetailBarang_DoubleClick(sender As Object, e As EventArgs) Handles Lv_DetailBarang.DoubleClick

        If Lv_DetailBarang.Items.Count = 0 Or Txt_KdBarang.Text.Trim.Length = 0 Then Exit Sub

        Get_ListView_Barang_Data(Lv_DetailBarang.FocusedItem.Index)

        Txt_KdBarang.Text = LvDet_KdBarang
        Txt_NamaBarang.Text = LvDet_NamaBarang

        Selected_SO = ""
        Selected_IdGroupJenis = ""
        Selected_SO = LvDet_KdSO
        Selected_IdGroupJenis = LvDet_IdJenis

        Lv_DetailBarang.Items.Clear()
        Lv_DetailBarang.Location = New Point(980, 146)
        Lv_DetailBarang.Visible = False

        Txt_Jmlh.Focus()
    End Sub

    Private Sub Txt_Jmlh_Leave(sender As Object, e As EventArgs) Handles Txt_Jmlh.Leave
        If Not IsNumeric(Txt_Jmlh.Text) Then Txt_Jmlh.Text = "" : Exit Sub
    End Sub


    '===== HANDLE BUTTON =====
    Private Sub Btn_Simpan_Click(sender As Object, e As EventArgs) Handles Btn_Simpan.Click
        If Txt_NamaBarang.Text.Trim.Length = 0 Then
            MessageBox.Show("Pilih Dahulu Barang", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If
        If Txt_Jmlh.Text.Trim.Length = 0 Then
            MessageBox.Show("Jumlah Tidak Boleh Kosong!", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If
        If Selected_SO = "" Or Selected_IdGroupJenis = "" Then Exit Sub


        Try
            OpenConn()
            get_jam()

            '================================
            '=     CONVERT SATUAN KECIL     =
            '================================
            Dim nilai_kecil As Double = 0
            SQL = "select dbo.ubah_satuan('" & KodePerusahaan & "', 'masa','" & Txt_KdBarang.Text & "', '" & Cmb_Satuan.SelectedItem & "',"
            SQL = SQL & "'Gram', '" & HilangkanTanda(Txt_Jmlh.Text) & "' ) as hasil"
            Using Dr1 = OpenTrans(SQL)
                If Dr1.Read Then
                    If General_Class.CekNULL(Dr1("hasil")) = "" Then
                        Dr1.Close()
                        CloseTrans()
                        CloseConn()
                        MessageBox.Show("data konversi satuan kirim tidak ada ")
                        Exit Sub
                    End If

                    nilai_kecil = Dr1("hasil")
                Else
                    Dr1.Close()
                    CloseTrans()
                    CloseConn()
                    MessageBox.Show("data konversi satuan kirim tidak ada ")
                    Exit Sub
                End If
            End Using

            '===========================================
            '=     INSERT Emi_Material_Requisition     =
            '===========================================

            SQL = "insert into Emi_Material_Requisition (Kode_Perusahaan, Kode_Stock_Owner, Kode_Barang, Nama, "
            SQL = SQL & "Id_Group_Jenis, Tanggal, Jam, Jumlah, Satuan, Nilai_Barang, Satuan_Barang, Flag_Process, UserId) Values "
            SQL = SQL & "('" & KodePerusahaan & "', '" & Selected_SO & "', '" & Txt_KdBarang.Text & "', '" & Txt_NamaBarang.Text & "', "
            SQL = SQL & "'" & Selected_IdGroupJenis & "', '" & Format(tgl_skg, "yyyy-MM-dd") & "', '" & Format(tgl_skg, "HH:mm:ss") & "', "
            SQL = SQL & "'" & Txt_Jmlh.Text & "', '" & Cmb_Satuan.SelectedItem & "', '" & nilai_kecil & "', 'Gram', 'Y', '" & UserID & "') "
            ExecuteTrans(SQL)

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

        kosong()

    End Sub

    Private Sub Btn_Refresh_Click(sender As Object, e As EventArgs) Handles Btn_Refresh.Click
        kosong()
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        If Lv_Data.Items.Count = 0 Then Exit Sub

        Get_ListView_Data(Lv_Data.FocusedItem.Index)

        Dim Tanya As String = MessageBox.Show("Yakin Ingin Hapus?", Base_Language.Lang_Global_Perhatian, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If Tanya = vbYes Then
            Try
                OpenConn()

                SQL = "delete from Emi_Material_Requisition "
                SQL = SQL & "where Kode_Perusahaan='" & KodePerusahaan & "' and Kode_Stock_Owner='" & Lv_KdSO & "' "
                SQL = SQL & "and Kode_Barang='" & Lv_KdBarang & "' and Flag_Process = 'Y' "
                ExecuteTrans(SQL)

                CloseConn()
                kosong()
            Catch ex As Exception
                CloseConn()
                MessageBox.Show(ex.Message)
                Exit Sub
            End Try
        End If

    End Sub

    Private Sub Btn_Filter_Click(sender As Object, e As EventArgs) Handles Btn_Filter.Click

        If Cmb_FilterNama.SelectedIndex = -1 Or Txt_Filter.Text.Trim.Length = 0 Then Exit Sub

        Try
            OpenConn()

            Lv_Data.Items.Clear()
            SQL = "select a.Kode_Stock_Owner, a.Kode_Barang, a.Nama, b.Kode_Group_Jenis, a.Jumlah, a.Satuan "
            SQL = SQL & "from Emi_Material_Requisition a, EMI_Group_Jenis b "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan "
            SQL = SQL & "and a.Id_Group_Jenis = b.Id_Group_Jenis "
            SQL = SQL & "and a.Kode_Perusahaan='" & KodePerusahaan & "' "
            SQL = SQL & "and a.Nama like '" & Txt_Filter.Text & "%' "
            SQL = SQL & "and a.Flag_Process = 'Y' "
            SQL = SQL & "order by a.Kode_Barang "
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim lv As ListViewItem
                    lv = Lv_Data.Items.Add(Dr("Kode_Stock_Owner"))
                    lv.SubItems.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Dr("Kode_Group_Jenis"))
                    lv.SubItems.Add(Dr("Jumlah"))
                    lv.SubItems.Add(Dr("Satuan"))
                Loop
            End Using

            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub Btn_Clear_Click(sender As Object, e As EventArgs) Handles Btn_Clear.Click

        Lv_Data.Items.Clear()
        Cmb_FilterNama.SelectedIndex = -1
        Txt_Filter.Text = String.Empty

        Load_Lv_Data()
    End Sub



    '===== KEYPRESS =====
    Private Sub Txt_KdBarang_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txt_KdBarang.KeyPress
        If e.KeyChar = Chr(13) Then Txt_Jmlh.Focus()
    End Sub






End Class