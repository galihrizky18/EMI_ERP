﻿Public Class Emi_Display_Request_Material
    Private Sub Emi_Display_Request_Material_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Initial_Lv()
        Kosong()
        Load_Lv()
    End Sub

    Private Sub Kosong()
        Lv_Data.Items.Clear()
    End Sub

    Private Sub Initial_Lv()
        Lv_Data.Columns.Add("Kode Stock Owner", 130, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Kode Barang", 130, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Nama Barang", 250, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Jenis", 130, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Tanggal Permintaan", 130, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Jam Permintaan", 120, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Jumlah", 100, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("Satuan", 100, HorizontalAlignment.Center)
        Lv_Data.Columns.Add("User Input", 130, HorizontalAlignment.Center)

        Lv_Data.View = View.Details
    End Sub

    Private Sub Load_Lv()

        Try
            OpenConn()

            Lv_Data.Items.Clear()
            SQL = "select a.Kode_Stock_Owner, a.Kode_Barang, a.Nama, b.Kode_Group_Jenis, a.Tanggal, a.Jam, a.Jumlah, a.Satuan, a.UserId "
            SQL = SQL & "from Emi_Material_Requisition a, EMI_Group_Jenis b "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan "
            SQL = SQL & "and a.Id_Group_Jenis = b.Id_Group_Jenis "
            SQL = SQL & "and a.Kode_Perusahaan='" & KodePerusahaan & "' "
            SQL = SQL & "and a.Flag_Process = 'Y' "
            SQL = SQL & "and a.status is null"
            Using Dr = OpenTrans(SQL)
                Do While Dr.Read
                    Dim lv As ListViewItem
                    lv = Lv_Data.Items.Add(Dr("Kode_Stock_Owner"))
                    lv.SubItems.Add(Dr("Kode_Barang"))
                    lv.SubItems.Add(Dr("Nama"))
                    lv.SubItems.Add(Dr("Kode_Group_Jenis"))
                    lv.SubItems.Add(Dr("Tanggal"))
                    lv.SubItems.Add(Dr("Jam"))
                    lv.SubItems.Add(Dr("Jumlah"))
                    lv.SubItems.Add(Dr("Satuan"))
                    lv.SubItems.Add(Dr("UserId"))
                Loop
            End Using



            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub
End Class