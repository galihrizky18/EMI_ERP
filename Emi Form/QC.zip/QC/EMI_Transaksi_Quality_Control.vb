﻿Imports System.Reflection
Imports System.Windows.Forms.VisualStyles
Imports System.Xml


Public Class EMI_Transaksi_Quality_Control
    Dim arrcari, arrJenisQC As New ArrayList
    Dim arrCmbSwtich As New ArrayList
    Dim Jenis = "Master_Quality_Control"
    Dim id_qc As String

    Public noQc As String


    Dim LvIDUji As String
    Dim LvKodeUji As String
    Dim LvKet As String
    Dim LvSatuan As String
    Dim LvMinAwal As String
    Dim LvMaxAwal As String
    Dim LvMinHasil As String
    Dim LvMaxHasil As String
    Dim LvJenis As String
    Dim LvTampilMasuk As String
    Dim LvTampilBongkar As String

    Dim CellIDUji As Integer = 0
    Dim CellKodeUji As Integer = 1
    Dim CellKet As Integer = 2
    Dim CellSatuan As Integer = 3
    Dim CellMinAwal As Integer = 4
    Dim CellMaxAwal As Integer = 5
    Dim CellMinHasil As Integer = 6
    Dim CellMaxHasil As Integer = 7
    Dim CellJenis As Integer = 8
    Dim CellTampilMasuk As Integer = 9
    Dim CellTampilBongkar As Integer = 10

    Dim LvData_Kode As String
    Dim LvData_Ket As String
    Dim LvData_satuan As String
    Dim LvData_ID As String

    Dim cellData_Kode As Integer = 0
    Dim cellData_Ket As Integer = 1
    Dim cellData_satuan As Integer = 2
    Dim cellData_ID As Integer = 3


    Public Sub Get_Isi_Listview(ByVal No_Index As Integer)

        LvIDUji = DGV_Data_QC.Rows(No_Index).Cells(CellIDUji).Value.ToString
        LvKodeUji = DGV_Data_QC.Rows(No_Index).Cells(CellKodeUji).Value.ToString
        LvKet = DGV_Data_QC.Rows(No_Index).Cells(CellKet).Value.ToString
        LvSatuan = DGV_Data_QC.Rows(No_Index).Cells(CellSatuan).Value.ToString
        LvMinAwal = DGV_Data_QC.Rows(No_Index).Cells(CellMinAwal).Value.ToString
        LvMaxAwal = DGV_Data_QC.Rows(No_Index).Cells(CellMaxAwal).Value.ToString
        LvMinHasil = DGV_Data_QC.Rows(No_Index).Cells(CellMinHasil).Value.ToString
        LvMaxHasil = DGV_Data_QC.Rows(No_Index).Cells(CellMaxHasil).Value.ToString
        LvJenis = DGV_Data_QC.Rows(No_Index).Cells(CellJenis).Value.ToString
        LvTampilMasuk = DGV_Data_QC.Rows(No_Index).Cells(CellTampilMasuk).Value.ToString
        LvTampilBongkar = DGV_Data_QC.Rows(No_Index).Cells(CellTampilBongkar).Value.ToString
    End Sub



    Private Sub kosong()
        txtNoFaktur.Text = ""


        txtNoFaktur.Text = noQc

        txtNoFaktur.Focus()

        DGV_Data_QC.Rows.Clear()
        Dgv_QC_Lab.Rows.Clear()

        Btn_Simpan.Text = Base_Language.Lang_Global_Simpan
        Btn_Hapus.Text = Base_Language.Lang_Global_Hapus

        Btn_Refresh.Text = Base_Language.Lang_Global_Refresh
        Btn_Simpan.Tag = "&Simpan"
        Btn_Hapus.Enabled = False

        Load_QC("lapangan")
        Load_QC("lab")


    End Sub

    Private Sub Load_QC(ByVal filter As String)
        Try
            OpenConn()

            Base_Language.Get_Languages(Bahasa_Pilihan, "GLOBAL")
            Base_Language.Get_Languages(Bahasa_Pilihan, Jenis)

            Label1.Text = Base_Language.Lang_Quality_Control_Judul

            SQL = ";with cte_qc as ( "
            SQL = SQL & "select a.kode_perusahaan,a.No_Faktur,a.Id_Quality_Control,b.Kode_Uji,b.Keterangan as Keterangan_Kode_QC,b.Satuan,a.Value_Kode_Uji, "
            SQL = SQL & "isnull((select x.Keterangan from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and  "
            SQL = SQL & "x.Id_Switch = a.Value_Kode_Uji), null) as value_Qc, "

            SQL = SQL & "isnull((select x.id_switch from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and "
            SQL = SQL & "x.Id_Switch = a.Value_Kode_Uji), null) as Id_Switch, d.Step,d.Tanggal,d.Jam,b.Id_Kategori_Komponen, "
            SQL = SQL & "c.Keterangan,b.Flag_Tampil_Dekstop,a.No_Urut, d.flag_sudah_qc_dekstop "
            SQL = SQL & "from EMI_Hasil_Detail_Quality_Control a, EMI_Quality_Control b, EMI_Kategori_Komponen c, EMI_Hasil_Quality_Control d "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Id_Quality_Control = b.Id_QC_Formula and b.Kode_Perusahaan = c.Kode_Perusahaan "
            SQL = SQL & "and b.Id_Kategori_Komponen = c.Id_Kategori_Komponen  "
            SQL = SQL & "and a.Kode_Perusahaan = d.Kode_Perusahaan and a.No_Faktur = d.No_Faktur "

            SQL = SQL & "union all  "

            SQL = SQL & "select a.kode_perusahaan,a.no_faktur,a.Id_Quality_Control,b.Kode_Uji,b.Keterangan as Keterangan_Kode_QC,b.Satuan,a.Value_Kode_Uji, "

            SQL = SQL & "isnull((select x.Keterangan from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan "
            SQL = SQL & "and  x.Id_Switch = a.value_kode_uji ), null) as value_Qc, "

            SQL = SQL & "isnull((select x.Id_Switch from EMI_Switch x where x.Kode_Perusahaan = a.Kode_Perusahaan and "
            SQL = SQL & "x.Id_Switch = a.value_kode_uji ), null) as Id_Switch ,d.Step,d.Tanggal,d.Jam,b.Id_Kategori_Komponen, "

            SQL = SQL & "c.Keterangan,b.Flag_Tampil_Dekstop,a.No_Urut, d.flag_sudah_qc_dekstop "
            SQL = SQL & "from EMI_Hasil_Detail_Switch_QC a, EMI_Quality_Control b, EMI_Kategori_Komponen c, EMI_Hasil_Quality_Control d "
            SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Id_Quality_Control = b.Id_QC_Formula and b.Kode_Perusahaan = c.Kode_Perusahaan "
            SQL = SQL & "and b.Id_Kategori_Komponen = c.Id_Kategori_Komponen "
            SQL = SQL & "and a.Kode_Perusahaan = d.Kode_Perusahaan and a.No_Faktur = d.No_Faktur "
            SQL = SQL & ") select * from cte_qc where Kode_Perusahaan = '" & KodePerusahaan & "' and No_Faktur = '" & noQc & "' and flag_sudah_qc_dekstop is null "

            If filter = "lapangan" Then
                SQL = SQL & "And Flag_Tampil_Dekstop Is null "
            ElseIf filter = "lab" Then
                SQL = SQL & "And Flag_Tampil_Dekstop = 'Y' "
            End If

            SQL = SQL & "order by flag_tampil_dekstop,Keterangan_Kode_QC "
            Using Ds = BindingTrans(SQL)
                With Ds.Tables("MyTable")
                    If .Rows.Count <> 0 Then

                        If filter = "lapangan" Then
                            For i As Integer = 0 To .Rows.Count - 1
                                DGV_Data_QC.Rows.Add(1)

                                DGV_Data_QC.Rows(i).Cells(0).Value = .Rows(i).Item("id_quality_control")
                                DGV_Data_QC.Rows(i).Cells(1).Value = .Rows(i).Item("kode_uji")
                                DGV_Data_QC.Rows(i).Cells(2).Value = .Rows(i).Item("Keterangan_Kode_QC")
                                DGV_Data_QC.Rows(i).Cells(3).Value = .Rows(i).Item("satuan")


                                If General_Class.CekNULL(.Rows(i).Item("value_qc")) = "" Then
                                    DGV_Data_QC.Rows(i).Cells(4).Value = .Rows(i).Item("value_kode_uji")

                                    DGV_Data_QC.Rows(i).Cells(5).Value = ""
                                    DGV_Data_QC.Rows(i).Cells(4).ReadOnly = True
                                    DGV_Data_QC.Rows(i).Cells(5).ReadOnly = True
                                Else
                                    DGV_Data_QC.Rows(i).Cells(4).Value = ""

                                    Dim dgvCmbValueSwitch As DataGridViewComboBoxCell
                                    dgvCmbValueSwitch = DGV_Data_QC.Rows(i).Cells(5)
                                    dgvCmbValueSwitch.Items.Clear() : arrCmbSwtich.Clear()
                                    dgvCmbValueSwitch.Items.Add(.Rows(i).Item("value_Qc")) : arrCmbSwtich.Add(.Rows(i).Item("id_switch"))

                                    dgvCmbValueSwitch.Value = dgvCmbValueSwitch.Items(0)

                                    DGV_Data_QC.Rows(i).Cells(4).ReadOnly = True
                                    DGV_Data_QC.Rows(i).Cells(5).ReadOnly = True
                                End If
                                DGV_Data_QC.Rows(i).Cells(6).Value = .Rows(i).Item("step")
                                DGV_Data_QC.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow
                                DGV_Data_QC.Rows(i).Cells(8).Value = ""
                                DGV_Data_QC.Rows(i).Cells(9).Value = .Rows(i).Item("no_urut")

                            Next

                        Else
                            '===========================
                            For i As Integer = 0 To .Rows.Count - 1
                                Dgv_QC_Lab.Rows.Add(1)

                                Dgv_QC_Lab.Rows(i).Cells(0).Value = .Rows(i).Item("id_quality_control")
                                Dgv_QC_Lab.Rows(i).Cells(1).Value = .Rows(i).Item("kode_uji")
                                Dgv_QC_Lab.Rows(i).Cells(2).Value = .Rows(i).Item("Keterangan_Kode_QC")
                                Dgv_QC_Lab.Rows(i).Cells(3).Value = .Rows(i).Item("satuan")

                                If .Rows(i).Item("id_kategori_komponen") = 2 Then
                                    Dgv_QC_Lab.Rows(i).Cells(4).Value = ""

                                    Dim dgvCmbValueSwitch As DataGridViewComboBoxCell
                                    dgvCmbValueSwitch = Dgv_QC_Lab.Rows(i).Cells(5)
                                    dgvCmbValueSwitch.Items.Clear() : arrCmbSwtich.Clear()
                                    SQL = "select a.Id_Switch, a.Keterangan from EMI_Switch a, EMI_Hasil_Detail_Switch_QC b "
                                    SQL = SQL & "where a.Kode_Perusahaan = b.Kode_Perusahaan and a.Id_QC_Formula = b.Id_Quality_Control "
                                    SQL = SQL & "and a.id_qc_formula = '" & .Rows(i).Item("id_quality_control") & "' and b.no_faktur = '" & noQc & "' "
                                    Using dr2 = OpenTrans(SQL)
                                        Do While dr2.Read
                                            dgvCmbValueSwitch.Items.Add(dr2("Keterangan")) : arrCmbSwtich.Add(dr2("id_switch"))
                                        Loop
                                    End Using

                                    Dgv_QC_Lab.Rows(i).Cells(4).ReadOnly = True
                                    Dgv_QC_Lab.Rows(i).Cells(5).ReadOnly = False
                                Else
                                    Dgv_QC_Lab.Rows(i).Cells(4).Value = ""

                                    Dgv_QC_Lab.Rows(i).Cells(4).ReadOnly = False
                                    Dgv_QC_Lab.Rows(i).Cells(5).ReadOnly = True
                                End If

                                Dgv_QC_Lab.Rows(i).Cells(6).Value = .Rows(i).Item("step")


                                If .Rows(i).Item("id_kategori_komponen") <> 2 Then
                                    Dgv_QC_Lab.Rows(i).Cells(4).Style.BackColor = Color.LightGray
                                End If

                                Dgv_QC_Lab.Rows(i).Cells(8).Value = .Rows(i).Item("flag_tampil_dekstop")

                                Dgv_QC_Lab.Rows(i).Cells(9).Value = .Rows(i).Item("no_urut")

                            Next
                        End If




                    Else
                            CloseConn()
                        MessageBox.Show("Data QC tidak ada! ", Judul, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Exit Sub
                    End If
                End With
            End Using


            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try

    End Sub

    Private Sub Master_Jenis_Hewan_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")
    End Sub

    Private Sub Master_Jenis_Hewan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-us")
        My.Application.ChangeUICulture("en-us")


        kosong()
    End Sub



    Private Sub Btn_Refresh_Click(sender As Object, e As EventArgs) Handles Btn_Refresh.Click
        kosong()
    End Sub

    Private Sub Btn_Simpan_Click(sender As Object, e As EventArgs) Handles Btn_Simpan.Click
        If txtNoFaktur.Text.Trim.Length = 0 Then
            MessageBox.Show(Base_Language.Lang_Quality_Control_Error_Kode, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtNoFaktur.Focus() : Exit Sub

        ElseIf Dgv_QC_Lab.Rows.Count = 0 Then
            MessageBox.Show(Base_Language.Lang_Global_Data_Tdk_Ditemukan, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Dgv_QC_Lab.Focus() : Exit Sub
        End If

        Try
            OpenConn()
            Cmd.Transaction = Cn.BeginTransaction

            For i As Integer = 0 To Dgv_QC_Lab.Rows.Count - 1

                'cek apakah semua data sudah di isi
                If Dgv_QC_Lab.Rows(i).Cells(5).Value = "" And Dgv_QC_Lab.Rows(i).Cells(4).Value = "" Then
                    CloseTrans()
                    CloseConn()
                    MessageBox.Show("Kode Uji " & Dgv_QC_Lab.Rows(i).Cells(2).Value & " belum di isi!")
                    Exit Sub
                End If



                ' cek apakah dia switch apa bukan
                'kalauu switch update di EMI_Hasil_Detail_Switch_QC
                If Dgv_QC_Lab.Rows(i).Cells(5).Value <> "" Then
                    Dim comboBoxCell As DataGridViewComboBoxCell = CType(Dgv_QC_Lab.Rows(i).Cells(5), DataGridViewComboBoxCell)
                    Dim index As Integer = comboBoxCell.Items.IndexOf(comboBoxCell.Value)

                    'SQL = "update EMI_Hasil_Detail_Switch_QC set value_kode_uji = '" & Dgv_QC_Lab.Rows(i).Cells(5).Value & "' "
                    SQL = "update EMI_Hasil_Detail_Switch_QC set value_kode_uji = '" & arrCmbSwtich(index) & "' "
                    SQL = SQL & "where kode_perusahaan = '" & KodePerusahaan & "' "
                    SQL = SQL & "and no_urut = '" & Dgv_QC_Lab.Rows(i).Cells(9).Value & "' "
                    ExecuteTrans(SQL)
                Else
                    'update di EMI_Hasil_Detail_Quality_Control
                    SQL = "update EMI_Hasil_Detail_Quality_Control set value_kode_uji = '" & Dgv_QC_Lab.Rows(i).Cells(4).Value & "' "
                    SQL = SQL & "where kode_perusahaan = '" & KodePerusahaan & "' "
                    SQL = SQL & "and no_urut = '" & Dgv_QC_Lab.Rows(i).Cells(9).Value & "' "
                    ExecuteTrans(SQL)
                End If


            Next

            SQL = "update  EMI_Hasil_Quality_Control set Flag_Sudah_Qc_Dekstop = 'Y' where kode_perusahaan = '" & KodePerusahaan & "' and no_faktur = '" & noQc & "' "
            ExecuteTrans(SQL)



            Cmd.Transaction.Commit()
            MessageBox.Show("Data berhasil disimpan ", Judul, MessageBoxButtons.OK)
            CloseConn()
        Catch ex As Exception
            CloseConn()
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
        kosong()
    End Sub

    Private Sub DGV_Data_QC_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs)
        If Val(DGV_Data_QC.CurrentRow.Cells(4).Value) < 0 Or IsNumeric(DGV_Data_QC.CurrentRow.Cells(4).Value) = False Then
            DGV_Data_QC.CurrentRow.Cells(4).Value = 0
        End If
    End Sub

    Private Sub Btn_Hapus_Click(sender As Object, e As EventArgs) Handles Btn_Hapus.Click
        If txtNoFaktur.Text.Trim.Length = 0 Then
            MessageBox.Show(Base_Language.Lang_Quality_Control_Error_Kode, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtNoFaktur.Focus() : Exit Sub
        End If
        Dim Hapus1 As String = MessageBox.Show(Base_Language.Lang_Global_Tanya_Hapus, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If Hapus1 = vbYes Then
            Try
                OpenConn()
                Cmd.Transaction = Cn.BeginTransaction

                SQL = "delete from EMI_Quality_Control_PerBarang where "
                SQL = SQL & "Kode_Perusahaan ='" & KodePerusahaan & "' and "
                SQL = SQL & "Kode_Barang='" & txtNoFaktur.Text & "' "
                ExecuteTrans(SQL)

                Cmd.Transaction.Commit()
                CloseConn()
            Catch ex As Exception
                CloseConn()
                MessageBox.Show(ex.Message)
                Exit Sub
            End Try
        Else
            MessageBox.Show(Base_Language.Lang_Global_Hapus_No, Base_Language.Lang_Global_Perhatian, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If
        kosong()
    End Sub



    Private Sub DGV_Data_QC_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs)
        If e.RowIndex = 0 And e.ColumnIndex = 5 Then
            ' Melukis latar belakang default cell
            e.PaintBackground(e.ClipBounds, True)

            ' Menggunakan brush untuk mengganti warna latar belakang
            Using brush As New SolidBrush(Color.LightGreen) ' Pilih warna yang diinginkan
                e.Graphics.FillRectangle(brush, e.CellBounds)
            End Using

            ' Melukis konten cell (teks atau isi ComboBox)
            e.PaintContent(e.ClipBounds)

            ' Tandai bahwa cell sudah di-handle (tidak perlu di-render ulang oleh DataGridView)
            e.Handled = True
        End If
    End Sub



    'FUNCTION UTILITY
    Private Sub Dgv_QC_Lab_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_QC_Lab.CellClick
        If e.ColumnIndex = DataGridViewComboBoxColumn1.Index Then
            Dgv_QC_Lab.CurrentCell = Dgv_QC_Lab.Rows(e.RowIndex).Cells(e.ColumnIndex)
            Dgv_QC_Lab.BeginEdit(True)
        End If
    End Sub

    Private Sub Dgv_QC_Lab_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_QC_Lab.CellEndEdit
        If IsNumeric(Dgv_QC_Lab.CurrentRow.Cells(CellMinAwal).Value) = False Then
            Dgv_QC_Lab.CurrentRow.Cells(CellMinAwal).Value = ""
        End If
    End Sub

    'Private Sub Dgv_QC_Lab_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Dgv_QC_Lab.CellFormatting

    '    If Dgv_QC_Lab.Rows(e.RowIndex).Cells(4).ReadOnly Then
    '        Dgv_QC_Lab.Rows(e.RowIndex).Cells(5).Style.BackColor = Color.LightGray
    '    Else
    '        Dgv_QC_Lab.Rows(e.RowIndex).Cells(5).Style.BackColor = Color.White
    '    End If
    'End Sub



End Class