﻿Public Class Approval_HC

    Dim filePath As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            Tb_FilePath.Text = OpenFileDialog1.FileName
            filePath = OpenFileDialog1.FileName

        End If

    End Sub


End Class